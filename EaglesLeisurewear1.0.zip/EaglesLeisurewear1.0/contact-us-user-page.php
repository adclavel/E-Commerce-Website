<!DOCTYPE html>
<html lang="english">
  <head>
    <title>Contact-Us-User-Page - exported project</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="./contact-us-user-page.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/e0abea836f.js" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="contact-us-user-page-header">
      <img
        class="header-logo"
        src="public/external/thefraternalorderofeagles13712-cfl-200h.png"
        alt="TheFraternalOrderofEagles13712"
      />
      <span class="website-name">
        <span>Eagle’s Leisurewear</span>
      </span>
      <div class="contact-us-user-page-iconuser">
          <a href="my-account.php"><img src="public/external/user3812-jwm2-200h.png" ></a>
      </div>
      <div class="contact-us-user-page-icon-bag">
        <a href="add-to-cart-page.php"><img src="public/external/shoppingbagfull3812-ovvi-200h.png"/></a>
      </div>
      <div class="contact-us-user-page-search-bar">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" id="searchInput" placeholder="Search" onkeydown="handleSearch(event)">
      </div>
      <div class="contact-us-user-page-dashboard">
        <ul>
          <li> <a href="index.php">Home</a></li>
          <li> <a href="user-shop-page.php">Shop</a></li>
          <li> <a href="about-us-user-page.php">About Us</a></li>
          <li class="contact-us-tab"> <a href="contact-us-user-page.php">Contact Us</a></li>
        </ul>
      </div>
    </div>
      <div class="contact-us-user-page-body">
        <span class="contact-us-user-page-text">
          <h1>Contact Us</h1>
        </span>
          <span class="contact-us-user-page-body-info">
            <span>
              Feel free to reach out to us or give us a heads up if you plan
              on visiting. You can also contact us through Facebook
              Messenger.
            </span>
            <br />
            <span></span>
            <br />
            <span>Facebook Link Below:</span>
            <br />
            <span></span>
          </span>
          <span class="contact-us-user-page-text11">
            <a href="https://www.facebook.com/eaglesleisurewear" target="blank">Facebook</a>
            <br />
            <span></span>
          </span>
          </div>
      </div>
      <div class="contact-us-user-page-temp-footer">
        <div class="website-name-footer">
          <img class="footer-logo" src="public/external/thefraternalorderofeagles14032-c39-200h.png"/>
          <h1>Eagle’s Leisurewear</h1>
          <h4>At Eagle's Leisure, we're more than just a website; <br> we're a virtual for fraternity enthusiasts and like-minded <br> individuals. Dive into 
            a world where camaraderie, fun, <br> and the spirit of brotherhood together.</h4>
        </div>
        <div class="website-contact-info">
          <div class="info-list">
            <a href="contact-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>Contact Us</h3></a>
            <a href="about-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>About us</h3></a>
            <a href="user-shop-page.php" style="color: rgb(255, 255, 255);"><h3>Shop</h3></a>
            <a href="privacy-policy.php" style="color: rgb(255, 255, 255);"><h3>Privacy Policy</h3></a>
            <a href="terms-of-service.php" style="color: rgb(255, 255, 255);"><h3>Terms and Conditions</h3></a>
          </div>
        </div>
        <div class="links">
          <h1>Links</h1>
          <a href="https://www.facebook.com/eaglesleisurewear?mibextid=LQQJ4d" target="_blank"><img src="public/external/facebook4072-vhe-200h.png"/></a>
        </div>
        <div class="website-location">
          <h1>Our Location</h1>
            <img class="location-icon"src="public/external/location4112-y82-200h.png"/>
            <div class="address">
            <a href="https://maps.app.goo.gl/9u7YZqT3BBGyxHJv5" style="color: white;"><h4>1325 Malakas Street Pasig City</h4></a>
            <h4>National Capital Region</h4>
          </div>
        </div>
      </div>
      <script>
        function handleSearch(event) {
            if (event.key === 'Enter') {
                searchProducts();
            }
        }

        function searchProducts() {
            var searchInput = document.getElementById('searchInput').value.toLowerCase();

            // Redirect to the results page with the search query as a parameter
            window.location.href = 'user-shop-page.php?query=' + encodeURIComponent(searchInput);
        }
    </script>
  </body>
</html>
