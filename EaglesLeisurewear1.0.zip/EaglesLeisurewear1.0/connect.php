<?php
// Retrieve form data
$full_name = $_POST['full_name'];
$club_name = $_POST['club_name'];
$phone_number = $_POST['phone_number'];
$password = $_POST['password'];
$email = $_POST['email'];
$confirm_password = $_POST['confirm_password'];
$facebook_url = $_POST['facebook_url'];

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Connect to MySQL database
$conn = new mysqli('localhost', 'root', '', 'eagles');
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
} else {
    // Prepare and bind the INSERT statement
    $stmt = $conn->prepare("INSERT INTO registration (full_name, club_name, phone_number, password, email, confirm_password, facebook_url)
                            VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssissss", $full_name, $club_name, $phone_number, $hashed_password, $email, $confirm_password, $facebook_url);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Registration successful. Thank you!";
    } else {
        echo "Error: " . $conn->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>