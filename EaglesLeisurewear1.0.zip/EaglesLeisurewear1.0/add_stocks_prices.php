<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eagles";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$productID = $_POST['product_id'];
$size = $_POST['size'];
$stocks = $_POST['stocks'];
$price = $_POST['price'];

// Insert into sizes_stocks table
$sql = "INSERT INTO sizes_stocks (product_id, size, stocks, price) VALUES ($productID, '$size', $stocks, $price)";
if ($conn->query($sql) === TRUE) {
    echo "New record inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$conn->close();
?>
