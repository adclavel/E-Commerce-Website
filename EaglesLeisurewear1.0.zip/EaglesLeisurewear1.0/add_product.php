<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eagles";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$productName = $_POST['productName'];
$price = $_POST['price'];
$category = $_POST['category'];
$image = $_POST['image']; // Assuming you handle image upload separately
$size = $_POST['size'];
$stocks = $_POST['stocks'];

// Insert into products table
$sql = "INSERT INTO products (ProductName, price, category, image) VALUES ('$productName', $price, '$category', '$image')";
if ($conn->query($sql) === TRUE) {
    // Get the last inserted ID
    $lastProductId = $conn->insert_id;

    // Insert into sizes_stocks table
    $sql = "INSERT INTO sizes_stocks (product_id, size, stocks) VALUES ($lastProductId, '$size', $stocks)";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('New record inserted successfully');</script>";
    } else {
        echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
    }
} else {
    echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
}

// Close connection
$conn->close();
?>
