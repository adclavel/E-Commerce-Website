<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eagles";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve edited data from POST request
$id = $_POST['id'];
$productName = $_POST['productName'];
$size = $_POST['size'];
$stocks = $_POST['stocks'];

// Update product data in the database
$sql = "UPDATE products SET ProductName = '$productName' WHERE ID = '$id'";
$result = $conn->query($sql);

$sql = "UPDATE sizes_stocks SET Size = '$size', Stocks = '$stocks' WHERE ProductID = '$id'";
$result = $conn->query($sql);

// Check if the update was successful
if ($result) {
    echo json_encode(array("success" => true, "message" => "Product data updated successfully"));
} else {
    echo json_encode(array("success" => false, "message" => "Error updating product data: " . $conn->error));
}

// Close connection
$conn->close();
?>
