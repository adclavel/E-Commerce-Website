<?php
  include "db_connect.php";
  session_start();
?>

<!DOCTYPE html>
<html lang="english">
  <head>
    <title>DeliveryPaymentPage - exported project</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="./delivery-payment-page8.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/e0abea836f.js" crossorigin="anonymous"></script>
  </head>
  <?php
    // Fetch user data based on user ID stored in the session
    $user_id = $_SESSION['id'];

    // Prepare and execute a query to retrieve user data
    $sql = "SELECT * FROM registered_users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if user data was retrieved successfully
    if ($result->num_rows > 0) {
      // Fetch the user data
      $user_data = $result->fetch_assoc();

      // Close the statement
      $stmt->close();
    } else {
      // Handle error (user not found)
      echo "User data not found.";
      exit();
    }
  ?>
<?php
include "db_connect.php";

// Check if the "place order" button is clicked
if(isset($_POST['place-order-btn'])) {
    // Retrieve the session ID
    $userId = $_SESSION['id'];

    // Retrieve product information from the "cart_products" table
    $query = "SELECT cp.*, ss.stocks AS stocks
              FROM cart_products cp
              INNER JOIN sizes_stocks ss ON cp.product_id = ss.product_id AND cp.size = ss.size
              WHERE cp.user_id = '$userId'";
    $result = $conn->query($query);

    // Check for SQL query execution error
    if (!$result) {
        echo "Error executing query: " . $conn->error;
        exit; // Exit script if there's an error
    }

    // Check if there are products in the cart
    if ($result->num_rows > 0) {
        $currentDate = date('Y-m-d');
        // Loop through each product and insert into the "orders" table
        while ($product_data = $result->fetch_assoc()) {
            $product_id = $product_data['product_id'];
            $product_name = $product_data['ProductName'];
            $product_size = $product_data['size'];
            $product_price = $product_data['price'];
            $product_quantity = $product_data['quantity'];
            $product_image = $product_data['image']; // Assuming 'image' is the column name for the image data
            $stock_quantity = $product_data['stocks'];

            // Check if there is sufficient stock
            if ($stock_quantity >= $product_quantity) {
                // Check if the same size is available in sizes_stocks
                $size_query = "SELECT * FROM sizes_stocks WHERE product_id = '$product_id' AND size = '$product_size'";
                $size_result = $conn->query($size_query);

                if ($size_result->num_rows > 0) {
                    // Capture additional input data
                    $fullname = $_POST['fullname'];
                    $address = $_POST['address'];
                    $contactnumber = $_POST['contactnumber'];
                    $clubname = $_POST['clubname'];
                    $clubregion = $_POST['clubregion'];
                    $mode_of_payment = isset($_POST['mode_of_payment']) ? $_POST['mode_of_payment'] : ''; // Check if mode_of_payment key exists
                    $mode_of_delivery = isset($_POST['mode_of_delivery']) ? $_POST['mode_of_delivery'] : ''; // Check if mode_of_delivery key exists
                    $subtotal = $_GET['subtotal'];
                    $total = $subtotal + 40;

                    // Check if mode of payment and mode of delivery are chosen
                    if (!empty($mode_of_payment) && !empty($mode_of_delivery)) {
                        // Check if eagles_id file is uploaded
                        if (isset($_FILES['upload-id']) && $_FILES['upload-id']['error'] === UPLOAD_ERR_OK) {
                            // Upload file data
                            $eagles_id = $_FILES['upload-id']['name'];
                            $gcash_receipt = isset($_FILES['upload-receipt']['name']) ? $_FILES['upload-receipt']['name'] : '';

                            // Specify the directory to store uploaded files

                            // Decrease stock quantity in the "size_stocks" table
                            $update_query = "UPDATE sizes_stocks 
                                             SET stocks = stocks - $product_quantity 
                                             WHERE product_id = '$product_id' 
                                             AND size = '$product_size'";
                            if ($conn->query($update_query) === TRUE) {
                                // Insert product details into the "orders" table
                                $insert_query = "INSERT INTO orders (user_id, product_id, product_name, size, price, quantity, image, fullname, address, contact_number, club_name, club_region, eagles_id, gcash_receipt, mode_of_payment, mode_of_delivery, order_date, status) 
                                                 VALUES ('$userId', '$product_id', '$product_name', '$product_size', '$total', '$product_quantity', '$product_image', '$fullname', '$address', '$contactnumber', '$clubname', '$clubregion', '$eagles_id', '$gcash_receipt', '$mode_of_payment', '$mode_of_delivery', '$currentDate', 'Pending')";
                                if ($conn->query($insert_query) === TRUE) {
                                    // Remove product from cart after successful order placement
                                    $delete_query = "DELETE FROM cart_products WHERE user_id = '$userId' AND product_id = '$product_id' AND size = '$product_size'";
                                    $conn->query($delete_query);
                                } else {
                                    echo "Error inserting order: " . $conn->error;
                                }
                            } else {
                                echo "Error updating stock quantity: " . $conn->error;
                            }
                        } else {
                            echo "<script>alert('Please upload your Eagles ID.');</script>";
                        }
                    } else {
                        echo "<script>alert('Please select mode of payment and mode of delivery.');</script>";
                    }
                } else {
                    echo "<script>alert('Size $product_size is not available for product: $product_name');</script>";
                }
            } else {
                echo "<script>alert('Insufficient stock for product: $product_name (Size: $product_size)')</script>";
            }
        }
        // Redirect after processing all products
        echo "<script>alert('Thank you for shopping with us! Your order is being processed.');</script>";
        echo "<script>window.location.href = 'add-to-cart-page.php';</script>";
        exit; // Exit after redirecting
    } else {
        // Display a message if there are no products in the cart
        echo "<script>alert('Your cart is empty.')</script>";
    }
}
?>

<?php

// // Check if the product ID is provided in the URL
// if(isset($_GET['id']) && is_numeric($_GET['id'])) {
//     $productId = $_GET['id'];
//     // Retrieve product information based on the provided product ID
//     $sql = "SELECT * FROM products WHERE id = $productId";
//     $result = $conn->query($sql);

//     if ($result && $result->num_rows > 0) {
//         $product_data = $result->fetch_assoc();
//         $imageData = base64_encode($product_data["image"]);
//     } else {
//         echo "Product not found.";
//     }
// } else {
//     echo "Invalid product ID.";
// }
?>
<?php
    // $selectedSize = $_GET['selectedSize'];
    // $selectedQty = $_GET['selectedQty'];
?>


  <body id="body">
    <div class="home-page-header">
      <img
        class="header-logo"
        src="public/external/thefraternalorderofeagles13712-cfl-200h.png"
        alt="TheFraternalOrderofEagles13712"
      />
      <span class="website-name">
        <span>Eagle’s Leisurewear</span>
      </span>
      <div class="home-page-iconuser">
        <a href="my-account.php"><img src="public/external/user3812-jwm2-200h.png" ></a>
      </div>
      <div class="home-page-icon-bag">
        <a href="add-to-cart-page.php"><img src="public/external/shoppingbagfull3812-ovvi-200h.png"/></a>
      </div>
    </div>
    <div class="delivery-payment-page-body">
      <div class="delivery-payment-info">
        <div class="delivery-payment-info-container">
          <span class="delivery-label">
            <h1>Delivery</h1>
          </span>
          <form method="post" enctype="multipart/form-data">
          <span class="inputbox-firstname">
            <input type="text" name="fullname" placeholder="Full Name" value="<?php echo $user_data['full_name']; ?>" required>
          </span>
          <div class="inputbox-address">
          <input type="text" name="address" placeholder="Address" value="<?php echo $user_data['streetname_building_housenum'] . ', ' . $user_data['region_province_city_barangay'] . ', ' . $user_data['postal']; ?>" required>
          </div>
          <div class="inputbox-contactnumber">
            <input type="text" name="contactnumber" class="inputbox-contactnumber" placeholder="Contact Number" value="<?php echo $user_data['phone_number']; ?>" required>
          </div>
          <div class="inputbox-clubname">
            <input type="text" name="clubname" placeholder="Club Name" value="<?php echo $user_data['club_name']; ?>" required>
          </div>
          <div class="inputbox-clubregion">
            <input type="text" name="clubregion"  placeholder="Club Region" required>
          </div>
          <div class="inputbox-eaglesID">
            <span><input class="id-filename" id="selected-id-filename" placeholder="Upload Eagle's ID" readonly><i class="fa-solid fa-paperclip" id="upload-id-button" style="color: #000000;"></i></span>
            <input name="upload-id" type="file" id="upload-id" style="display: none;"> 
          </div>
          <span class="payment-label">
            <h1>Payment</h1>
          </span>
          <div class="payment-method-button">
          <input type="hidden" name="mode_of_payment" id="mode_of_payment">
            <span class="delivery-payment-mode-gcash-button">
                <button name="mode_of_payment" id="gcash-button" value="Gcash">G-cash</button>
            </span>
            <span class="delivery-payment-mode-cashondelivery-button">
                <button name="mode_of_payment" id="cod-button" value="Cash on Delivery">Cash on Delivery</button>
            </span>
        </div>
          <div class="gcash-method" id="gcash-method">
            <div class="inputbox-gcash-uploadreceipt">
              <span><input class="receipt-filename" id="selected-receipt-filename" placeholder="Please Upload G-Cash Receipt" readonly></input><i class="fa-solid fa-paperclip" id="upload-receipt-button" style="color: #000000;"></i></span>
              <input name="upload-receipt" type="file" id="upload-receipt" style="display: none;"> 
            </div>
            <div class="delivery-payment-gcash">
              <div class="delivery-payment-gcash-number">
                <span class="gcashno">G-Cash No:</span>
                <span>+63 312 2123 231</span>
              </div>
              <span class="delivery-payment-gcash-qrcode">
                <span class="gcashqr">G-Cash QR Code:</span>
                <span>         
                  <img src="https://aheioqhobo.cloudimg.io/v7/_playground-bucket-v2.teleporthq.io_/52314f84-2079-4a73-baed-8f886e45a146/2be5a66a-a0c1-418b-8e13-63ea936e3055?org_if_sml=12401&amp;force_format=original"/>
                </span>
              </span>
            </div>
          </div>
          <div class="delivery-payment-page-modeofdelivery">
            <h1>Mode of Delivery</h1>
          </div>
          <div class="deliver-options" id="deliver-options">
          <div class="delivery-payment-page-option1">
            <input name="mode_of_delivery" class="JNT" type="radio" id="JNT" name="delivery" value="JNT" name="mode">
            <label>JNT Express</label>
          </div>
          <div class="delivery-payment-page-option2">
            <input name="mode_of_delivery" type="radio" id="Lalamove" name="delivery" value="Lalamove">
            <label>Lalamove</label>
          </div>
          <div class="delivery-payment-page-option3">
            <input name="mode_of_delivery" type="radio" id="LBC" name="delivery" value="LBC">
            <label>LBC</label>
          </div>
          </div>
          <div class="modeofdelivery-footer">
            <div class="modeofdelivery-footer-container">
            <span class="delivery-payment-page-refund">
              <span id="refund"></span>
            </span>
            <span class="delivery-payment-page-privacy">
              <span id="privacy"></span>
            </span>
            <span class="delivery-payment-page-terms">
              <span id="terms"></span>
            </span>
            </div>
          </div>
        </div>
        <div class="delivery-items">
          <div class="item" id="cartProductsContainer">
            <?php
              // echo "<div class='item'>";
              //     // Display product image
              //     echo "<img src='data:image/png;base64, $imageData '/>";
              //     // Display other product information
              //     echo "<label class='product-name'>Name: " . $product_data['ProductName'] . "</label>";
              //     echo "<label class='product-size'>Size: " . $selectedSize . "</label>";
              //     echo "<label class='product-quantity'>Price: " . $product_data['price'] . "</label>";
              //     echo "<label class='product-price'>Quantity: " . $selectedQty . "</label>";
              //     // You can calculate total price for each product here if needed
              //     echo "</div>";
            ?>
          <?php
          // Check if user is logged in or any other method you use to identify the user
          if (!isset($_SESSION['id'])) {
              // Redirect the user to login page or handle unauthorized access
              header("Location: login.php");
              exit();
          }

          // Fetch product information from the database based on user's session
          $user_id = $_SESSION['id'];
          $query = "SELECT * FROM cart_products WHERE user_id = $user_id";
          $result = mysqli_query($conn, $query);

          // Check if there are products in the cart
          if (mysqli_num_rows($result) > 0) {
              // Loop through each product and display its information
              while ($product_data = mysqli_fetch_assoc($result)) {
                  echo "<div class='item'>";
                  // Display product image
                  echo "<img src='data:image/png;base64," . $product_data['image'] . "' alt='Product Image' />";
                  // Display other product information
                  echo "<label class='product-name'>Name: " . $product_data['ProductName'] . "</label>";
                  echo "<label class='product-size'>Size: " . $product_data['size'] . "</label>";
                  echo "<label class='product-quantity'>Price: " . $product_data['price'] . "</label>";
                  echo "<label class='product-price'>Quantity: " . $product_data['quantity'] . "</label>";
                  // You can calculate total price for each product here if needed
                  echo "</div>";
              }
          } else {
              // Display a message if there are no products in the cart
              echo "<p>Your cart is empty.</p>";
          }
          ?>
          </div>
        </div>
        <div class="shipping-and-buttons">
          <div class="subtotal-shipping-total">
          <?php
          // Retrieve the subtotal value from the URL parameter
          if(isset($_GET['subtotal'])) {
              $subtotal = $_GET['subtotal'];
              // Calculate the total by adding 40 to the subtotal
              $total = $subtotal + 40;
              // Display the subtotal and total
              echo "<label class='subtotal'>Subtotal: ₱" . number_format($subtotal, 2) . "</label>";
              echo "<label class='shipping'>Shipping: ₱40.00</label>";
              echo "<label class='total'>Total: ₱" . number_format($total, 2) . "</label>";
          } else {
              echo "<label class='subtotal'>Subtotal: ₱0.00</label>"; // Display default value if subtotal parameter is not set
              echo "<label class='total'>Total: ₱0.00</label>"; // Display default value for total
          }
          ?>
          </div>
          <div class="back-placeorder-buttons">
            <button class="back" onclick="backtocart()">Back</button>
            <button class="placeorder" id="place-order-btn" name="place-order-btn">Place Order</button>
          </div>
          </form>
        </div>
      </div>
    </div>
    <div class="popup" id="popup-blur">
      <div class="privacy-policy" id="privacyy-popup">
        <div class="privacy-policy-header">
          <span>
          <h1>Privacy Policy<i class="fa-solid fa-xmark" id="privacy-close"></i></h1>
  
          </span>
        </div>
        <div class="privacy-policy-body">
          <span class="privacy-policy-contents">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Lorem donec massa sapien faucibus et molestie ac feugiat. Diam
            donec adipiscing tristique risus nec feugiat in fermentum
            posuere. Eu scelerisque felis imperdiet proin fermentum leo vel
            orci porta. Eget mi proin sed libero. Integer quis auctor elit
            sed vulputate mi sit amet mauris. Congue mauris rhoncus aenean
            vel elit scelerisque. Sit amet volutpat consequat mauris nunc
            congue nisi. Vulputate dignissim suspendisse in est ante in nibh
            mauris. Dapibus ultrices in iaculis nunc. Nisi lacus sed viverra
            tellus. Sed augue lacus viverra vitae congue eu consequat ac.
            Diam sollicitudin tempor id eu nisl nunc. Molestie at elementum
            eu facilisis sed odio morbi. Vestibulum sed arcu non odio.
          </span>
          <br />
          <span></span>
          <br />
          <span>
            Elementum pulvinar etiam non quam lacus. Et malesuada fames ac
            turpis egestas integer. Nunc congue nisi vitae suscipit tellus
            mauris. Malesuada fames ac turpis egestas integer eget.
            Tincidunt ornare massa eget egestas. Gravida neque convallis a
            cras semper auctor neque. Dui accumsan sit amet nulla facilisi
            morbi tempus iaculis urna. Aliquet nibh praesent tristique magna
            sit amet. Nulla facilisi etiam dignissim diam. Sit amet mattis
            vulputate enim nulla aliquet porttitor. Donec ultrices tincidunt
            arcu non sodales neque sodales ut etiam. Amet venenatis urna
            cursus eget nunc scelerisque viverra mauris. Sit amet aliquam id
            diam maecenas. Est velit egestas dui id ornare. Tellus
            pellentesque eu tincidunt tortor aliquam nulla facilisi cras
            fermentum. Cursus eget nunc scelerisque viverra mauris in. A
            pellentesque sit amet porttitor.
          </span>
        </div>
      </div>
      <div class="refund-policy" id="refund-popup">
        <div class="refund-policy-header">
          <h1>Refund Policy<i class="fa-solid fa-xmark" id="refund-close"></i></h1>
        </div>
        <div class="refund-policy-body">
          <span class="refund-policy-contents">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Lorem donec massa sapien faucibus et molestie ac feugiat. Diam
            donec adipiscing tristique risus nec feugiat in fermentum
            posuere. Eu scelerisque felis imperdiet proin fermentum leo vel
            orci porta. Eget mi proin sed libero. Integer quis auctor elit
            sed vulputate mi sit amet mauris. Congue mauris rhoncus aenean
            vel elit scelerisque. Sit amet volutpat consequat mauris nunc
            congue nisi. Vulputate dignissim suspendisse in est ante in nibh
            mauris. Dapibus ultrices in iaculis nunc. Nisi lacus sed viverra
            tellus. Sed augue lacus viverra vitae congue eu consequat ac.
            Diam sollicitudin tempor id eu nisl nunc. Molestie at elementum
            eu facilisis sed odio morbi. Vestibulum sed arcu non odio.
          </span>
          <br />
          <span></span>
          <br />
          <span>
            Elementum pulvinar etiam non quam lacus. Et malesuada fames ac
            turpis egestas integer. Nunc congue nisi vitae suscipit tellus
            mauris. Malesuada fames ac turpis egestas integer eget.
            Tincidunt ornare massa eget egestas. Gravida neque convallis a
            cras semper auctor neque. Dui accumsan sit amet nulla facilisi
            morbi tempus iaculis urna. Aliquet nibh praesent tristique magna
            sit amet. Nulla facilisi etiam dignissim diam. Sit amet mattis
            vulputate enim nulla aliquet porttitor. Donec ultrices tincidunt
            arcu non sodales neque sodales ut etiam. Amet venenatis urna
            cursus eget nunc scelerisque viverra mauris. Sit amet aliquam id
            diam maecenas. Est velit egestas dui id ornare. Tellus
            pellentesque eu tincidunt tortor aliquam nulla facilisi cras
            fermentum. Cursus eget nunc scelerisque viverra mauris in. A
            pellentesque sit amet porttitor.
          </span>
        </div>
      </div>
      <div class="terms-of-service" id="terms-popup">
        <div class="terms-of-service-header">
          <h1>Terms of Service<i class="fa-solid fa-xmark" id="terms-close"></i></h1>
        </div>
        <div class="terms-of-service-body">
          <span class="terms-of-service-contents">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Lorem donec massa sapien faucibus et molestie ac feugiat. Diam
            donec adipiscing tristique risus nec feugiat in fermentum
            posuere. Eu scelerisque felis imperdiet proin fermentum leo vel
            orci porta. Eget mi proin sed libero. Integer quis auctor elit
            sed vulputate mi sit amet mauris. Congue mauris rhoncus aenean
            vel elit scelerisque. Sit amet volutpat consequat mauris nunc
            congue nisi. Vulputate dignissim suspendisse in est ante in nibh
            mauris. Dapibus ultrices in iaculis nunc. Nisi lacus sed viverra
            tellus. Sed augue lacus viverra vitae congue eu consequat ac.
            Diam sollicitudin tempor id eu nisl nunc. Molestie at elementum
            eu facilisis sed odio morbi. Vestibulum sed arcu non odio.
          </span>
          <br />
          <span></span>
          <br />
          <span>
            Elementum pulvinar etiam non quam lacus. Et malesuada fames ac
            turpis egestas integer. Nunc congue nisi vitae suscipit tellus
            mauris. Malesuada fames ac turpis egestas integer eget.
            Tincidunt ornare massa eget egestas. Gravida neque convallis a
            cras semper auctor neque. Dui accumsan sit amet nulla facilisi
            morbi tempus iaculis urna. Aliquet nibh praesent tristique magna
            sit amet. Nulla facilisi etiam dignissim diam. Sit amet mattis
            vulputate enim nulla aliquet porttitor. Donec ultrices tincidunt
            arcu non sodales neque sodales ut etiam. Amet venenatis urna
            cursus eget nunc scelerisque viverra mauris. Sit amet aliquam id
            diam maecenas. Est velit egestas dui id ornare. Tellus
            pellentesque eu tincidunt tortor aliquam nulla facilisi cras
            fermentum. Cursus eget nunc scelerisque viverra mauris in. A
            pellentesque sit amet porttitor.
          </span>
        </div>
      </div>
    </div>
    <script>
    document.getElementById('upload-id').addEventListener('change', function() {
    var filename = this.value.split('\\').pop(); // Get the filename from the path
    var placeholder = document.getElementById('selected-id-filename');
    placeholder.placeholder = filename; // Update placeholder with filename
    });
    // Function to update placeholder with filename when receipt file is uploaded
    document.getElementById('upload-receipt').addEventListener('change', function() {
        var filename = this.value.split('\\').pop(); // Get the filename from the path
        var placeholder = document.getElementById('selected-receipt-filename');
        placeholder.placeholder = filename; // Update placeholder with filename
    });
    </script>
    <script>
      const popuprefund = document.getElementById("refund");
      const popupprivacy = document.getElementById("privacy");
      const popupterms = document.getElementById("terms");
      const refunddisplay = document.getElementById("refund-popup");
      const refunddisplayclose = document.getElementById("refund-close");
      const privacydisplay = document.getElementById("privacyy-popup");
      const privacydisplayclose = document.getElementById("privacy-close");
      const termsdisplay = document.getElementById("terms-popup");
      const termsdisplayclose = document.getElementById("terms-close");
      const uploadbuttonid = document.getElementById("upload-id-button")
      const uploadid = document.getElementById("upload-id")
      const SelectedIDFilename = document.getElementById("selected-id-filename");
      const uploadbuttonreceipt = document.getElementById("upload-receipt-button")
      const uploadreceipt = document.getElementById("upload-receipt")
      const SelectedReceiptFilename = document.getElementById("selected-receipt-filename");

      popuprefund.addEventListener("click", () => {
        refunddisplay.style.display = "block";
        popupblur.style.display = "block";
      });
      
      refunddisplayclose.addEventListener("click", () => {
        refunddisplay.style.display = "none";
        popupblur.style.display = "none";
      });

      popupprivacy.addEventListener("click", () => {
        privacydisplay.style.display = "block";
        popupblur.style.display = "block";
      });
      
      privacydisplayclose.addEventListener("click", () => {
        privacydisplay.style.display = "none";
        popupblur.style.display = "none";
      });

      popupterms.addEventListener("click", () => {
        termsdisplay.style.display = "block";
        popupblur.style.display = "block";
      });
      
      termsdisplayclose.addEventListener("click", () => {
        termsdisplay.style.display = "none";
        popupblur.style.display = "none";
      });

      uploadbuttonid.addEventListener("click", () => {
        uploadid.click();
      })

      function handleIdFileUpload(files) {
      if (files.length > 0) {
        const selectedFile = files[0];
        SelectedIDFilename.value = selectedFile.name;
        console.log("File selected:", files[0]);
      } else {
        SelectedIDFilename.value = "";
        console.log("File selected:", files[0]);
      }
      }

      uploadbuttonreceipt.addEventListener("click", () => {
        uploadreceipt.click();
      })

      function handleReceiptFileUpload(files) {
      if (files.length > 0) {
        const selectedFile = files[0];
        SelectedReceiptFilename.value = selectedFile.name;
        console.log("File selected:", files[0]);
      } else {
        SelectedReceiptFilename.value = "";
        console.log("File selected:", files[0]);
      }
      }
      
      const gcashbutton = document.getElementById("gcash-button");
      const modeOfPaymentInput = document.getElementById("mode_of_payment");
      const codbutton = document.getElementById("cod-button");
      const gcashmethod =document.getElementById("gcash-method");
      const deliveroptions =document.getElementById("deliver-options");
      const receipt =document.getElementById("upload-receipt");

      gcashbutton.addEventListener("click", () => {
        modeOfPaymentInput.value = "Gcash";
        event.preventDefault();
        gcashbutton.style.backgroundColor = "#505050";
        gcashbutton.style.color = "#FFFFFF";
        codbutton.style.backgroundColor = "";
        codbutton.style.color = "";
        gcashmethod.style.display = "block";
        deliveroptions.style.marginBottom = "20px"
      });

      codbutton.addEventListener("click", () => {
        modeOfPaymentInput.value = "Cash on Delivery";
        event.preventDefault();
        codbutton.style.backgroundColor = "#505050";
        codbutton.style.color = "#FFFFFF";
        gcashbutton.style.backgroundColor = "";
        gcashbutton.style.color = "";
        gcashmethod.style.display = "";
        deliveroptions.style.marginBottom = ""

      });

      function backtocart() {
      window.location.href = "add-to-cart-page.php";
      }

      if (gcashbutton) {
        gcashbutton.addEventListener('click', function() { // or any other value you want to assign
        console.log('Button clicked!');
    });
        } else {
            // The button with the specified ID was not found
            console.log('Button not found.');
        }
      
      function clearCart() {
      localStorage.removeItem('cartProducts');
      }
      
      const item = document.getElementById('item1');
        if (window.getComputedStyle(item).display === 'block') {
      // Set display to none if it's currently block
      item.style.display = 'none';
      }
    </script>
  </body>
</html>
