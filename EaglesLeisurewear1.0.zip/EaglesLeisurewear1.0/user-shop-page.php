<?php
  include "db_connect.php";
?>

<!DOCTYPE html>
<html lang="english">
  <head>
    <title>User-Shop-Page - exported project</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="./user-shop-page.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/e0abea836f.js" crossorigin="anonymous"></script>
  </head>
  <?php
    session_start();
  // Step 2: Retrieve product information
  $sql = "SELECT id, image, ProductName, price FROM products";
  $result = $conn->query($sql);

  if (!$result) {
    die("Error executing the query: " . $conn->error);
  }

  // Step 3: Display data in HTML with a new element for every ID
  if ($result->num_rows > 0) {
      while($product_data = $result->fetch_assoc()) {
          echo "<a href='user-order-product-page.php?id=" . $product_data['id'] . "'>";
          $imageData = base64_encode($product_data["image"]);
          echo "<div class='product'>";
          echo "<img src='data:image/png;base64, $imageData'>";
          echo "<h3><strong></strong> " . $product_data["ProductName"] . "</h3>";
          echo "<h4><strong></strong> ₱" . $product_data["price"] . "</h4>";
          echo "</a>";
          echo "</div>";
      }
  } else {
      echo "0 results";
  }
  $conn->close();
  ?>
  <body>
    <div class="home-page-header">
      <img
        class="header-logo"
        src="public/external/thefraternalorderofeagles13712-cfl-200h.png"
        alt="TheFraternalOrderofEagles13712"
      />
      <span class="website-name">
        <span>Eagle’s Leisurewear</span>
      </span>
      <div class="home-page-iconuser">
        <a href="my-account.php"><img src="public/external/user3812-jwm2-200h.png" ></a>
      </div>
      <div class="home-page-icon-bag">
        <a href="add-to-cart-page.php"><img src="public/external/shoppingbagfull3812-ovvi-200h.png"/></a>
      </div>
      <div class="home-page-search-bar">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" id="searchInput" placeholder="Search" onkeydown="handleSearch(event)">
      </div>
      <div class="home-page-dashboard">
        <ul>
          <li> <a href="index.php">Home</a></li>
          <li> <a href="user-shop-page.php">Shop</a></li>
          <li> <a href="about-us-user-page.php">About Us</a></li>
          <li> <a href="contact-us-user-page.php">Contact Us</a></li>
        </ul>
      </div>
    </div>
    <div class="user-shop-page-text"><span>ALL PRODUCTS</span></div>
    <div class="user-shop-page-body">
      <div class="dropdown-buttons">
      <div class="dropdown">
    <button class="dropbtn-category" onclick="myFunctionCategory()">Category
        <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content-category" id="myDropdownCategory">
        <a href="#" onclick="loadData('All')">All</a>
        <a href="#" onclick="loadData('Jacket')">Jacket</a>
        <a href="#" onclick="loadData('Cap')">Cap</a>
        <a href="#" onclick="loadData('Umbrella')">Umbrella</a>
    </div>
</div>

<div class="dropdown">
    <button class="dropbtn-price" onclick="myFunctionPrice()">Price
        <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content-price" id="myDropdownPrice">
        <a href="#" onclick="loadPrice('Low to High')">Price: Low to High</a>
        <a href="#" onclick="loadPrice('High to Low')">Price: High to Low</a>
    </div>
</div>

<div class="dropdown">
    <button class="dropbtn-sort" onclick="myFunctionSort()">Sort
        <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content-sort" id="myDropdownSort">
        <a href="#" onclick="loadSort('A-Z')">A-Z</a>
        <a href="#" onclick="loadSort('Z-A')">Z-A</a>
    </div>
</div>
      </div> 
      <div class="user-shop-page-products" id="user-shop-page-products">
      <div class="product">

      </div>
      </div>
    </div>
    <div class="home-page-temp-footer">
      <div class="website-name-footer">
        <img class="footer-logo" src="public/external/thefraternalorderofeagles14032-c39-200h.png"/>
        <h1>Eagle’s Leisurewear</h1>
        <h4>At Eagle's Leisure, we're more than just a website; <br> we're a virtual for fraternity enthusiasts and like-minded <br> individuals. Dive into 
          a world where camaraderie, fun, <br> and the spirit of brotherhood together.</h4>
      </div>
      <div class="website-contact-info">
        <div class="info-list">
          <a href="contact-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>Contact Us</h3></a>
          <a href="about-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>About us</h3></a>
          <a href="user-shop-page.php" style="color: rgb(255, 255, 255);"><h3>Shop</h3></a>
          <a href="privacy-policy.php" style="color: rgb(255, 255, 255);"><h3>Privacy Policy</h3></a>
          <a href="terms-of-service.php" style="color: rgb(255, 255, 255);"><h3>Terms and Conditions</h3></a>
        </div>
      </div>
      <div class="links">
        <h1>Links</h1>
        <a href="https://www.facebook.com/eaglesleisurewear?mibextid=LQQJ4d" target="_blank"><img src="public/external/facebook4072-vhe-200h.png"/></a>
      </div>
      <div class="website-location">
        <h1>Our Location</h1>
          <img class="location-icon"src="public/external/location4112-y82-200h.png"/>
          <div class="address">
          <a href="https://maps.app.goo.gl/9u7YZqT3BBGyxHJv5" style="color: white;"><h4>1325 Malakas Street Pasig City</h4></a>
          <h4>National Capital Region</h4>
        </div>
      </div>
    </div>
    <script>
    function loadPrice(sortType) {
    // Example using fetch API
    fetch('process_sort_price.php?sort=' + sortType)
        .then(response => response.text())
        .then(data => {
            // Update the product list with the sorted data
            document.getElementById('user-shop-page-products').innerHTML = data;
        })
        .catch(error => console.error('Error:', error));
}

    document.addEventListener("DOMContentLoaded", function() {
        var productContainer = document.getElementById("user-shop-page-products");
        var productElements = document.querySelectorAll(".product");
        
        productElements.forEach(function(element) {
            productContainer.appendChild(element);
        });
    });
    </script>
    <script>
    function loadData(category) {
    // Example using fetch API
    fetch('process_sort_category.php?sort=' + category)
        .then(response => response.text())
        .then(data => {
            // Update the product list with the sorted data
            document.getElementById('user-shop-page-products').innerHTML = data;
        })
        .catch(error => console.error('Error:', error));
}  
    function loadSort(sortType) {

    // Example using fetch API
    fetch('process_sort.php?sort=' + sortType)
        .then(response => response.text())
        .then(data => {
            // Update the product list with the sorted data
            document.getElementById('user-shop-page-products').innerHTML = data;
        })
        .catch(error => console.error('Error:', error));
    }

    </script>
    <script> 
  function myFunctionCategory() {
      document.getElementById("myDropdownCategory").classList.toggle("show");
  }

  // Price dropdown
  function myFunctionPrice() {
    document.getElementById("myDropdownPrice").classList.toggle("show");
  }

  // Sort dropdown
  function myFunctionSort() {
      document.getElementById("myDropdownSort").classList.toggle("show");
  }

  window.onclick = function (event) {
      if (!event.target.matches('.dropbtn-category')) {
          var dropdowns = document.getElementsByClassName("dropdown-content-category");
          for (var i = 0; i < dropdowns.length; i++) {
              var openDropdown = dropdowns[i];
              if (openDropdown.classList.contains('show')) {
                  openDropdown.classList.remove('show');
              }
          }
      }

      if (!event.target.matches('.dropbtn-price')) {
          var priceDropdown = document.getElementById("myDropdownPrice");
          if (priceDropdown.classList.contains('show')) {
              priceDropdown.classList.remove('show');
          }
      }

      // Close sort dropdown if the click is outside the dropdown content
      if (!event.target.matches('.dropbtn-sort')) {
          var sortDropdown = document.getElementById("myDropdownSort");
          if (sortDropdown.classList.contains('show')) {
              sortDropdown.classList.remove('show');
          }
      }
  }

  function handleSearch() {
    // Get the search input value
    var searchInput = document.getElementById('searchInput').value.trim().toLowerCase();

    // Get all product elements
    var products = document.querySelectorAll('.product');

    // If the search input is empty, display all products
    if (searchInput === '') {
        products.forEach(function(product) {
            product.style.display = 'inline-block'; // Show the product
        });
        return; // Exit the function early
    }

    // Loop through each product to check if it matches the search criteria
    products.forEach(function(product) {
        var productName = product.querySelector('h3').innerText.toLowerCase();
        var productPrice = product.querySelector('h4').innerText.toLowerCase();
        
        // Check if the product name or price contains the search input
        if (productName.includes(searchInput) || productPrice.includes(searchInput)) {
            // Show the product if it matches the search criteria
            product.style.display = 'inline-block';
        } else {
            // Hide the product if it doesn't match the search criteria
            product.style.display = 'none';
        }
    });
}
</script>
  </body>
</html>
