<!DOCTYPE html>
<html lang="english">
  <head>
    <title>Terms-of-Service - exported project</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="./privacy-policy.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/e0abea836f.js" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="home-page-header">
      <img
        class="header-logo"
        src="public/external/thefraternalorderofeagles13712-cfl-200h.png"
        alt="TheFraternalOrderofEagles13712"
      />
      <span class="website-name">
        <span>Eagle’s Leisurewear</span>
      </span>
      <div class="home-page-iconuser">
          <a href="my-account.php"><img src="public/external/user3812-jwm2-200h.png" ></a>
      </div>
      <div class="home-page-icon-bag">
        <a href="add-to-cart-page.php"><img src="public/external/shoppingbagfull3812-ovvi-200h.png"/></a>
      </div>
      <div class="home-page-search-bar">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" id="searchInput" placeholder="Search" onkeydown="handleSearch(event)">
      </div>
      <div class="home-page-dashboard">
        <ul>
          <li> <a href="index.php">Home</a></li>
          <li> <a href="user-shop-page.php">Shop</a></li>
          <li> <a href="about-us-user-page.php">About Us</a></li>
          <li> <a href="contact-us-user-page.php">Contact Us</a></li>
        </ul>
      </div>
    </div>
    <div class="privacy-policy-container">
    <div class="privacy-policy-title">
        <span class="privacy-policy-text28">
            <span>Privacy Policy</span>
        </span>
    </div>
    <span class="privacy-policy-text">
        <span>
            <span></span>
            <br />
            <span>
                Welcome to Eagles Leisurewear's Privacy Policy. Your privacy is important to us. This Privacy Policy ("Policy") explains how Eagles Leisurewear collects, uses, and discloses your personal information when you use our website (the "Site") and the choices you have associated with that information.
                By accessing or using the Site, you agree to the terms of this Policy. If you do not agree with the terms of this Policy, please do not use the Site.
            </span>
            <br />
            <span></span>
            <br />

            <h3>1. Information We Collect</h3>
            <span>
                We collect information you provide directly to us when you use the Site. This may include your name, email address, mailing address, phone number, payment information, and any other information you choose to provide.
            </span>
            <span></span>
            <br/>
            <br>
            <h3>2. How We Use Your Information</h3>
            <span>
                We may use the information we collect for various purposes, including to:
                <ul style="padding-left: 69px;"> <!-- Adjusted padding -->
                    <li>Provide, operate, and maintain the Site;</li>
                    <li>Process and complete transactions;</li>
                    <li>Send you promotional communications;</li>
                    <li>Respond to your inquiries, comments, and requests;</li>
                    <li>Improve and personalize your experience on the Site;</li>
                    <li>Monitor and analyze trends, usage, and activities on the Site; and</li>
                    <li>Comply with legal obligations.</li>
                </ul>
            </span>
            <br />
            <span></span>
            <br />
            <span>3. Information Sharing</span>
            <span>
                We may share your information with third parties as necessary to provide the services you request, comply with legal obligations, protect and defend our rights and property, prevent fraud, and enforce our agreements.
            </span>
            <br />
            <span></span>
            <br />
            <span>4. Security</span>
            <span>
                We take reasonable measures to protect your information from unauthorized access, use, alteration, or destruction. However, no method of transmission over the internet or electronic storage is completely secure, so we cannot guarantee absolute security.
            </span>
            <br />
            <span></span>
            <br />
            <span>5. Changes to This Policy</span>
            <span>
                Eagles Leisurewear reserves the right to update or change this Policy at any time. We will notify you of any changes by posting the new Policy on this page. You are advised to review this Policy periodically for any changes.
            </span>
            <br />
            <span></span>
            <br />
            <span>6. Contact Us</span>
            <span>
                If you have any questions or concerns about this Policy, please contact us at [Contact Email].
                Last updated: March 17,2024
            </span>
        </span>
    </span>
</div>
    <div class="home-page-temp-footer">
      <div class="website-name-footer">
        <img class="footer-logo" src="public/external/thefraternalorderofeagles14032-c39-200h.png"/>
        <h1>Eagle’s Leisurewear</h1>
        <h4>At Eagle's Leisure, we're more than just a website; <br> we're a virtual for fraternity enthusiasts and like-minded <br> individuals. Dive into 
            a world where camaraderie, fun, <br> and the spirit of brotherhood together.</h4>
      </div>
      <div class="website-contact-info">
        <div class="info-list">
          <a href="contact-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>Contact Us</h3></a>
          <a href="about-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>About us</h3></a>
          <a href="user-shop-page.php" style="color: rgb(255, 255, 255);"><h3>Shop</h3></a>
          <a href="privacy-policy.php" style="color: rgb(255, 255, 255);"><h3>Privacy Policy</h3></a>
          <a href="terms-of-service.php" style="color: rgb(255, 255, 255);"><h3>Terms and Conditions</h3></a>
        </div>
      </div>
      <div class="links">
        <h1>Links</h1>
        <a href="https://www.facebook.com/eaglesleisurewear?mibextid=LQQJ4d" target="_blank"><img src="public/external/facebook4072-vhe-200h.png"/></a>
      </div>
      <div class="website-location">
        <h1>Our Location</h1>
          <img class="location-icon"src="public/external/location4112-y82-200h.png"/>
          <div class="address">
          <a href="https://maps.app.goo.gl/9u7YZqT3BBGyxHJv5" style="color: white;"><h4>1325 Malakas Street Pasig City</h4></a>
          <h4>National Capital Region</h4>
        </div>
      </div>
    </div>
    <script>
      function handleSearch(event) {
          if (event.key === 'Enter') {
              searchProducts();
          }
      }

      function searchProducts() {
          var searchInput = document.getElementById('searchInput').value.toLowerCase();

          // Redirect to the results page with the search query as a parameter
          window.location.href = 'user-shop-page.php?query=' + encodeURIComponent(searchInput);
      }
  </script>
  </body>
</html>
