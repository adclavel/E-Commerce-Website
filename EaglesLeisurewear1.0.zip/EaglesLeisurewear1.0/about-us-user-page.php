<!DOCTYPE html>
<html lang="english">
  <head>
    <title>About-Us-User-Page - exported project</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="./about-us-user-page.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/e0abea836f.js" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="home-page-header">
      <img
        class="header-logo"
        src="public/external/thefraternalorderofeagles13712-cfl-200h.png"
        alt="TheFraternalOrderofEagles13712"
      />
      <span class="website-name">
        <span>Eagle’s Leisurewear</span>
      </span>
      <div class="home-page-iconuser">
        <a href="my-account.php"><img src="public/external/user3812-jwm2-200h.png" ></a>
      </div>
      <div class="home-page-icon-bag">
        <a href="add-to-cart-page.php"><img src="public/external/shoppingbagfull3812-ovvi-200h.png"/></a>
      </div>
      <div class="home-page-search-bar">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" id="searchInput" placeholder="Search" onkeydown="handleSearch(event)">
      </div>
      <div class="home-page-dashboard">
        <ul>
          <li> <a href="index.php">Home</a></li>
          <li> <a href="user-shop-page.php">Shop</a></li>
          <li> <a href="about-us-user-page.php">About Us</a></li>
          <li> <a href="contact-us-user-page.php">Contact Us</a></li>
        </ul>
      </div>
    </div>
      <div class="about-us-user-page">
        <div class="about-us-user-page-image">
          <img src="https://aheioqhobo.cloudimg.io/v7/_playground-bucket-v2.teleporthq.io_/1e9f0276-52a5-4270-bcd4-1ce4cbc19522/088cdd3d-ab6f-4ef1-809e-41b0b8cada43?org_if_sml=1198069&amp;force_format=original"/>
        </div>
        <div class="container-info">
        <div class="about-us-user-page-info">
          <h1>About Us</h1>
          <br>
          <span>
            Welcome to Eagle's Leisurewear, where brotherhood meets style!
            Founded on the principles of camaraderie and shared values,
            our fraternity is more than just a group – it's a lifestyle.
            At Eagle's Leisurewear, we've crafted a collection of premium
            t-shirts and merchandise that embody the spirit of our
            fraternity.
          </span>
          <br />
          <span></span>
          <br />
          <span>
            From iconic symbols to timeless designs, our apparel reflects
            the rich traditions and unique bonds that define us. Each
            piece is not just a garment; it's a statement of belonging, a
            representation of the pride we take in our fraternity.
          </span>
          <br />
          <span></span>
          <br />
          <span>
            Embrace the spirit of unity and express your allegiance with
            our exclusive range of Eagle's Leisurewear. Whether you're a
            proud member, an alum, or a supporter, our collection is
            designed to resonate with the essence of our brotherhood.
          </span>
          <br />
          <span>
            Join us in celebrating the values that bind us together –
            strength, loyalty, and a commitment to excellence. Explore
            Eagle's Leisurewear and wear your fraternity with pride.
          </span>
          <br />
          <span></span>
          <br />
          <span></span>
        </div>
        </div>
      </div>
      </div>
      <div class="home-page-temp-footer">
        <div class="website-name-footer">
          <img class="footer-logo" src="public/external/thefraternalorderofeagles14032-c39-200h.png"/>
          <h1>Eagle’s Leisurewear</h1>
          <h4>At Eagle's Leisure, we're more than just a website; <br> we're a virtual for fraternity enthusiasts and like-minded <br> individuals. Dive into 
            a world where camaraderie, fun, <br> and the spirit of brotherhood together.</h4>
        </div>
        <div class="website-contact-info">
          <div class="info-list">
            <a href="contact-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>Contact Us</h3></a>
            <a href="about-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>About us</h3></a>
            <a href="user-shop-page.php" style="color: rgb(255, 255, 255);"><h3>Shop</h3></a>
            <a href="privacy-policy.php" style="color: rgb(255, 255, 255);"><h3>Privacy Policy</h3></a>
            <a href="terms-of-service.php" style="color: rgb(255, 255, 255);"><h3>Terms and Conditions</h3></a>
          </div>
        </div>
        <div class="links">
          <h1>Links</h1>
          <a href="https://www.facebook.com/eaglesleisurewear?mibextid=LQQJ4d" target="_blank"><img src="public/external/facebook4072-vhe-200h.png"/></a>
        </div>
        <div class="website-location">
          <h1>Our Location</h1>
            <img class="location-icon"src="public/external/location4112-y82-200h.png"/>
            <div class="address">
            <a href="https://maps.app.goo.gl/9u7YZqT3BBGyxHJv5" style="color: white;"><h4>1325 Malakas Street Pasig City</h4></a>
            <h4>National Capital Region</h4>
          </div>
        </div>
      </div>
      <script>
        function handleSearch(event) {
            if (event.key === 'Enter') {
                searchProducts();
            }
        }

        function searchProducts() {
            var searchInput = document.getElementById('searchInput').value.toLowerCase();

            // Redirect to the results page with the search query as a parameter
            window.location.href = 'user-shop-page.php?query=' + encodeURIComponent(searchInput);
        }
    </script>
  </body>
</html>
