<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Metadata for character set and viewport -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Title of the document -->
    <title>User Registration - Eagle's Leisurewear Admin Portal</title>

    <!-- External stylesheets for Font Awesome icons and Roboto font -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300;400;700&display=swap">

    <!-- Internal styles for the document -->
    <style>
        /* Reset default margin and padding for the body */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif; /* Use Arial or sans-serif as fallback font */
        }

        /* Header styles */
        header {
            background: linear-gradient(45deg, #292929, #1a1a1a); /* Gradient background */
            color: #fff;
            padding: 5px;
            border-bottom: 7px solid #FCB900;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            display: flex;
            align-items: center;
        }

        /* Header logo styles */
        .header-logo {
            height: auto;
            width: 90px;
            margin-right: 15px;
        }

        /* Title styles */
        .title {
            font-size: 24px; /* Font size */
            font-weight: bold; /* Bold font weight */
            color: #FCB900; /* Gold color for the title */
            margin-left: 15px; /* Left margin for spacing */
            font-family: 'Roboto Condensed', sans-serif; /* Use Roboto Condensed font */
        }

        /* Navigation categories container styles */
        .nav-categories {
            background: linear-gradient(45deg, #696969, #1a1a1a); /* Gradient background */
            display: flex;
            flex-direction: column; /* Align categories vertically */
            padding: 10px 0;
            position: absolute;
            left: 0;
            top: 100px; /* Adjust top value as needed */
            width: 180px; /* Set a fixed width for the left side */
            border-right: 4px solid #FCB900; /* Add a right border */
            height: calc(100vh - 120px); /* Set the height to fill the remaining viewport height */
        }

        /* Navigation category links styles */
        .nav-categories a {
            text-decoration: none;
            color: #fff;
            font-size: 20px;
            margin: 10px 20px;
            position: relative;
            transition: color 0.3s;
        }

        /* Navigation category link hover styles */
        .nav-categories a:hover {
            color: yellow;
        }

        /* Navigation category link underline styles */
        .nav-categories a::after {
            content: '';
            display: block;
            width: 0;
            height: 2px;
            background-color: yellow;
            position: absolute;
            bottom: 0;
            left: 50%;
            transition: width 0.3s ease;
            transform: translateX(-50%);
        }

        /* Navigation category link hover underline styles */
        .nav-categories a:hover::after {
            width: 100%;
        }

        /* Sub-categories list styles */
        .sub-categories {
            display: none;
            list-style-type: none;
            padding-left: 20px;
        }

        /* Sub-category item styles */
        .nav-categories:hover .sub-categories {
            display: block;
        }

        /* Sub-category item hover styles */
        .sub-categories li {
            font-size: 14px;
            margin: 5px 0;
            color: #fff;
            cursor: pointer;
        }

        /* Sub-category item hover underline styles */
        .sub-categories li:hover {
            text-decoration: underline;
        }

        /* Footer styles */
        footer {
            background-color: #FFFFFF;
            color: #292929;
            padding: 0px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
            border-top: 1px solid #848484;
            font-size: 10px;
        }

      /* Main Content section */
        .main-content {
            margin-left: 200px;
            padding: 20px;
            z-index: 2;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        /* Updated styles for the <hr> element */
        .main-content hr {
            border: none;
            height: 2px;
            background-color: #FCB900; /* Dark yellow color */
            margin: 20px 0; /* Adjusted margin for spacing */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3); /* Added box shadow */
        }

        /* Outer frame styles */
        .outer-table-frame {
            border: 2px solid #ddd; /* Set border properties as needed */
            border-radius: 15px; /* Add border-radius for a rounded appearance */
            overflow: hidden;
            margin-bottom: 20px;
            width: 90%; /* Adjusted maximum width, including border width */
            margin: 0 auto; /* Centered the outer frame */
            background-color: #f0f0f0; /* Light grey background color */
            padding: 20px; /* Added padding */
        }

        /* Search, Sort by, and Period container styles */
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        /* Search bar styles */
        .search-bar {
            width: 20%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 25px; /* Added border-radius for a rounded look */
            position: relative;
            display: flex;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Added a subtle box shadow for depth */
            transition: background-color 0.3s; /* Added transition effect for background color */
        }

        /* Input styles */
        .search-bar input {
            flex: 1;
            width: 60%;
            border: none;
            outline: none;
            padding-left: 10px;
            font-size: 14px;
            background-color: #f5f5f5; /* Set background color to a light grey */
            border-radius: 20px; /* Added border-radius for a rounded look */
        }

        /* Adjust background color on hover for a stylish effect */
        .search-bar:hover {
            background-color: #e0e0e0; /* Set a slightly darker grey on hover */
        }

        /* Search icon styles */
        .search-bar i {
            margin-right: 10px;
        }
        /* Sort container styles */
        .sort-container {
            display: flex;
            align-items: center;
            margin-right: 20px; /* Adjusted margin for spacing */
        }

        /* Label for sort options */
        .sort-container label {
            margin-right: 10px;
            font-size: 14px;
            color: #333; /* Adjust text color as needed */
        }

        /* Sort options dropdown styles */
        #sortOptions {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
        }

        .sort-button {
            background-color: #FCB900; /* Yellow color */
            color: #fff;
            border: 1px solid #FCB900; /* Border color matching the background */
            padding: 8px 16px;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        /* Hover effect for the sort button */
        .sort-button:hover {
            background-color: #2980b9; /* Darker blue on hover */
        }

        /* New button for managing pending registrations */
        .manage-pending-button {
            text-align: center;
            margin-top: 10px; /* Adjusted margin-top to move it closer to the sort button */
            margin-bottom: 20px; /* Adjusted margin-bottom for spacing */
        }

        .pending-btn {
            background-color: #FCB900; /* Blue color */
            color: #000000;
            border: 1px solid #000000;
            padding: 4px 12px; /* Increased padding for a better look */
            cursor: pointer;
            border-radius: 5px;
            font-size: 12px; /* Slightly larger font size */
            font-weight: bold;
            transition: background-color 0.3s;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Added a subtle box shadow */
        }

        .pending-btn:hover {
            background-color: #B8860B; /* Darker blue on hover */
        }

        /* Table frame styles */
        .table-frame {
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
            background-color: #f9f9f9;
            margin-bottom: 20px;

            /* Adjust the size of the outer frame here */
            width: 100%; /* Set the width as a percentage or a specific value */
            margin: 5px; /* Adjust the margin as needed */
        }

        /* Main table container styles */
        .table-container {
            background: #f9f9f9;
            padding: 15px; /* Increase or decrease the padding as needed */
        }

        /* Table header styles */
        .table-header {
            display: flex;
            margin-left: 0; /* Adjust the left margin to 0 to move it to the left */
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #FCB900;
            padding-bottom: 10px;
            margin-bottom: 10px;
            font-weight: bold;
        }

        /* Table column styles */
        .table-column {
            flex: 1;
            text-align: left;
            padding: 6px;
        }

        /* Table row styles */
        .table-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
            margin-bottom: 10px;
            font-size: 8; /* Adjust the font size as needed */
        }

        /* Table cell styles */
        .table-cell {
            flex: 1;
            text-align: left;
            padding: 10px;
            font-size: 12px;
            font-weight: normal; /* Set font-weight to normal */
            color: #000000; /* Set text color to #E9ECEF */
        }

        /* Edit and Delete button styles */
        .edit-btn,
        .delete-btn,
        .view-btn {
            color: #A9A9A9;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        /* Edit button hover styles */
        .edit-btn:hover {
            background-color: #FFD700;
        }

        /* Delete button hover styles */
        .delete-btn:hover {
            background-color: #FF4500;
        }

        /* View button hover styles */
        .view-btn:hover {
            background-color: #3498db; /* Blue */
        }

      /* Pagination styles */
.pagination {
    display: flex;
    justify-content: center;
    margin-top: 20px;
    margin-bottom: 40px; /* Adjusted margin-bottom for increased spacing */
}
        /* Pagination button styles */
        .pagination-button {
            background-color: #D3D3D3; /* Change to your preferred color */
            color: #000000;
            border: 1px solid #A9A9A9; /* Adjust border color */
            padding: 8px 16px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            transition: background-color 0.3s;
            margin: 0 5px;
        }

        /* Pagination button hover styles */
        .pagination-button:hover {
            background-color: #A9A9A9; /* Change to your preferred hover color */
        }

        /* Highlight current page */
        .pagination-button.active {
            background-color: #A9A9A9; /* Change to your preferred active color */
            color: #000000;
        }

        @media screen and (max-width: 768px) {
            .nav-categories {
                display: none;
            }

            .main-content {
                margin-left: 10px;
            }

            .outer-table-frame,
            .table-frame,
            .table-container {
                width: 100%;
            }

            .search-bar {
                width: 100%;
            }

            .pagination {
                flex-direction: column;
            }
        }


        /* Modal styles */
/* Modal styles */
.modal {
    display: none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
}

/* Modified Modal content styles */
.modal-content {
    background-color: #fefefe;
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-height: 80vh; /* Set a maximum height for the content */
    overflow-y: auto; /* Enable vertical scrolling if content exceeds max height */
    border-radius: 10px; /* Rounded corners for a softer look */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle box shadow for depth */
}

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        /* Table styles for pending registrations inside the modal */
        .pending-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px; /* Adjusted margin for spacing */
        }

        .pending-table th,
        .pending-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd; /* Border between table cells */
        }

        .pending-table th {
            background-color: #f2f2f2; /* Light grey background for table header */
        }

        /* Button styles for Accept and Reject */
        .accept-btn,
        .reject-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 5px; /* Adjust as needed */
        }

        .accept-btn {
            background-color: #4CAF50; /* Green color for Accept */
            color: #fff; /* White text */
        }

        .reject-btn {
            background-color: #FF5733; /* Red color for Reject */
            color: #fff; /* White text */
        }

        .accept-btn:hover {
            background-color: #45a049; /* Darker green on hover */
        }

        .reject-btn:hover {
            background-color: #e74c3c; /* Darker red on hover */
        }

        /* Table frame styles */
        .table-frame {
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
            background-color: #f9f9f9;
            margin-bottom: 20px;
            width: 100%;
            margin: 5px;
        }

        /* Table container styles */
        .table-container {
            background: #f9f9f9;
            padding: 15px;
        }

        /* Table header styles */
        .table-header {
            display: flex;
            margin-left: 0;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #FCB900;
            padding-bottom: 10px;
            margin-bottom: 10px;
            font-weight: bold;
        }

        /* Table column styles */
        .table-column {
            flex: 1;
            text-align: left;
            padding: 10px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
        }

        /* Table row styles */
        .table-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
            margin-bottom: 10px;
            font-size: 14px;
        }

        /* Table cell styles */
        .table-cell {
            flex: 1;
            text-align: left;
            padding: 10px;
            font-size: 12px;
            font-weight: normal;
            color: #000000;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
        }
                

        
    </style>
</head>

<body>
    <!-- Header section -->
    <header>
        <img src="public/external/EaglesLogo.png" class="header-logo">       
        <h1 class="title">Eagle's Leisurewear Admin Portal </h1>
    </header>

        <!-- Navigation Categories section -->
        <div class="nav-categories">
        <a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
        <a href="admin_users.php"><i class="fas fa-user"></i> User Registration</a>
        <a href="admin_stocks.php"><i class="fas fa-box"></i> Products </a>
        <a href="admin_order_process.php"><i class="fas fa-money-bill"></i> Orders </a>
        <a href="log-in-page.php"><i class="fas fa-sign-out-alt"></i> Log Out</a>
        </div>


    <!-- Main content section -->
    <div class="main-content">
        <h2>User Registrations</h2>
        
        <hr>
        <!-- Outer frame for table -->
        <div class="outer-table-frame">
          <!-- Search, Sort by, and Period container -->
          <div class="action-bar">
    <!-- Search bar -->
    <div class="search-bar">
        <i class="fas fa-search"></i>
        <input type="text" id="searchInput" oninput="filterTable()" placeholder="Search...">
    </div>

                <!-- Sort container -->
                <div class="sort-container" id="sortContainer">
                    <label for="sortOptions">Sort by:</label>
                    <select id="sortOptions" onchange="sortTable()">
                        <option value="AscID">Ascending ID</option>
                        <option value="DescID">Descending ID</option>
                        <option value="AZ">A-Z</option>
                        <option value="ZA">Z-A</option>
                    </select>
                </div>
            </div>

            <div class="table-frame">
                <!-- Table header -->
                <div class="table-header">
                    <div class="table-column id-column">ID</div>
                    <div class="table-column name-column">Name</div>
                    <div class="table-column phone-column">Phone Number</div>
                    <div class="table-column email-column">Email</div>
                    <div class="table-column club-column">Club Name</div>
                    <div class="table-column url-column">Facebook URL</div>
                    <div class="table-column action-column">Actions</div>
                </div>

                <!-- Table body -->
                <div class="table-body">
                    <?php
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $database = "eagles";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $database);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Select all data from the registration table
                    $sql = "SELECT * FROM registered_users";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            echo "<div class='table-row'>";
                            echo "<div class='table-column id-column'>" . $row["id"] . "</div>";
                            echo "<div class='table-column name-column'>" . $row["full_name"] . "</div>";
                            echo "<div class='table-column phone-column'>" . $row["phone_number"] . "</div>";
                            echo "<div class='table-column email-column'>" . $row["email"] . "</div>";
                            echo "<div class='table-column club-column'>" . $row["club_name"] . "</div>";
                            echo "<div class='table-column url-column'>" . $row["facebook_url"] . "</div>";
                            echo "<div class='table-column action-column'>";
                            // View Details button
                            echo "<div class='button-container'>";
                            echo "<button class='view-details-button' onclick='openModal(" . $row["id"] . ")'>View Details</button>";
                            echo "</div>";
                            // Delete Account button
                            echo "<div class='button-container'>";
                            echo "<button class='delete-account-button' onclick='deleteAccount(" . $row["id"] . ")'>Delete Account</button>";
                            echo "</div>";
                            echo "</div>";
                            echo "</div>";
                        }
                    } else {
                        echo "<div class='table-row'><div class='table-column' colspan='7'>No data found</div></div>";
                    }

                    $conn->close();
                    ?>
                </div>
            </div>
               <!-- Button for managing pending registrations -->
    <div class="manage-pending-button">
        <button class="pending-btn" onclick="openPendingRegistrationsModal()">
            Pending Registrations
        </button>
    </div>
        </div>
        
    </div>

<!-- Modal for displaying user details -->
<div id="myModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <div id="modal-body">
            <!-- User details will be displayed here -->
        </div>
    </div>
</div>



    <!-- Modal container -->
    <div id="pendingRegistrationsModal" class="modal">
        <div class="modal-content">
            <!-- Add content for the table of pending registrations here -->
            <!-- Include a close button or icon to close the modal -->
            <span class="close" onclick="closePendingRegistrationsModal()">&times;</span>
            <h2>Pending Registrations</h2>
            <!-- Table for pending registrations -->
            <table id="userRegistrationsTable" class="pending-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Club Name</th>
                        <th>Phone Number</th>
                        <th>Email</th>
                        <th>Facebook URL</th>
                        <th>Actions</th>                        
                    </tr>
                </thead>
                <tbody>
               
                <?php
                // Database connection parameters
                $servername = "localhost";
                $username = "root";
                $password = "";
                $database = "eagles";
                
                // Create connection
                $conn = new mysqli($servername, $username, $password, $database);
                
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                
                // Retrieve user registrations
                $sql = "SELECT id, full_name, club_name, phone_number, email, facebook_url FROM registration";
                $result = $conn->query($sql);
                
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["id"] . "</td>";
                        echo "<td>" . $row["full_name"] . "</td>";
                        echo "<td>" . $row["club_name"] . "</td>";
                        echo "<td>" . $row["phone_number"] . "</td>";
                        echo "<td>" . $row["email"] . "</td>";
                        echo "<td>" . $row["facebook_url"] . "</td>";
                        echo "<td>";
                        echo "<form method='post' action='accept_user.php'>";
                        echo "<input type='hidden' name='id' value='" . $row["id"] . "'>";
                        echo "<button type='submit' name='accept_user'>Accept</button>";
                        echo "</form>";
                        echo "<form method='post' action='accept_user.php'>";
                        echo "<input type='hidden' name='id' value='" . $row["id"] . "'>";
                        echo "<button type='submit' name='reject_user'>Reject</button>";
                        echo "</form>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No registrations found</td></tr>";
                }
                
                // Close connection
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</div>
                </div>
            </div>

    <!-- Footer section -->
    <footer>
        <p>&copy; 2024 Admin Dashboard. All rights reserved.</p>
    </footer>

    <!-- SCRIPT -->

    <script>


function filterTable() {
            var input, filter, table, tr, i;
            input = document.getElementById("searchInput");
            filter = input.value.toUpperCase();
            table = document.querySelector(".table-body");
            tr = table.querySelectorAll(".table-row");

            for (i = 0; i < tr.length; i++) {
                var tdList = tr[i].querySelectorAll(".table-column");
                var found = false;
                for (var j = 0; j < tdList.length; j++) {
                    var td = tdList[j];
                    if (td) {
                        var txtValue = td.textContent || td.innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            found = true;
                            break;
                        }
                    }
                }
                if (found) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }

        function sortTable() {
            var sortOptions = document.getElementById("sortOptions");
            var selectedOption = sortOptions.value;
            var table = document.querySelector(".table-body");
            var rows = Array.from(table.querySelectorAll(".table-row"));

            // Perform sorting based on selected option
            switch (selectedOption) {
                case "AscID":
                    sortRows(rows, 0, true);
                    break;
                case "DescID":
                    sortRows(rows, 0, false);
                    break;
                case "AZ":
                    sortRows(rows, 1, true);
                    break;
                case "ZA":
                    sortRows(rows, 1, false);
                    break;
                default:
                    return; // No sorting needed
            }

            // Reorder rows in the table
            rows.forEach(function(row) {
                table.appendChild(row);
            });
        }

        function sortRows(rows, columnIndex, ascending) {
            rows.sort(function(a, b) {
                var x = columnIndex === 0 ? parseInt(a.querySelectorAll(".table-column")[columnIndex].textContent) : a.querySelectorAll(".table-column")[columnIndex].textContent.toLowerCase();
                var y = columnIndex === 0 ? parseInt(b.querySelectorAll(".table-column")[columnIndex].textContent) : b.querySelectorAll(".table-column")[columnIndex].textContent.toLowerCase();

                if (ascending) {
                    return x < y ? -1 : x > y ? 1 : 0;
                } else {
                    return x > y ? -1 : x < y ? 1 : 0;
                }
            });
        }



        
   // Function to open the modal and display user details
   function openModal(id) {
        // Send AJAX request to get user details
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Parse the JSON response
                var userDetails = JSON.parse(this.responseText);
                // Populate the modal with user details
                document.getElementById("modal-body").innerHTML = `
                    <p>ID: ${userDetails.id}</p>
                    <p>Name: ${userDetails.full_name}</p>
                    <p>Phone Number: ${userDetails.phone_number}</p>
                    <p>Email: ${userDetails.email}</p>
                    <p>Club Name: ${userDetails.club_name}</p>
                    <p>Facebook URL: ${userDetails.facebook_url}</p>
                `;
                // Display the modal
                modal.style.display = "block";
            }
        };
        xhttp.open("GET", "get_details.php?id=" + id, true);
        xhttp.send();
    }

    // Get the modal
    var modal = document.getElementById("myModal");

    // Get the button that opens the modal
    var buttons = document.querySelectorAll('.view-details-button');

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal
    buttons.forEach(function(button) {
        button.addEventListener('click', function() {
            var id = this.dataset.id;
            openModal(id);
        });
    });

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    };

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    };

    // Function to delete account
    function deleteAccount(id) {
        if (confirm("Are you sure you want to delete this account?")) {
            // Send AJAX request to delete account
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    // Handle success or error response (optional)
                    alert("Account deleted successfully.");
                    // Reload the page or update the table (optional)
                    location.reload();
                }
            };
            xhttp.open("GET", "delete_account.php?id=" + id, true);
            xhttp.send();
        }
    }

      // Function to open the pending registrations modal and fetch data
      function openPendingRegistrationsModal() {
        // Show the modal
        document.getElementById('pendingRegistrationsModal').style.display = 'block';

        // Fetch user registrations
        $.ajax({
            url: 'user_registrations.php', // URL to your PHP script
            type: 'GET',
            success: function(response) {
                // Populate the table with the retrieved data
                $('#userRegistrationsTable tbody').html(response);
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
    }

    // Function to accept a user and reject
    function rejectUser(email) {
    $.ajax({
        url: 'accept_user.php',
        type: 'POST',
        data: { email: email },
        success: function(response) {
            // Refresh the modal content after rejecting
            openPendingRegistrationsModal();
        },
        error: function(xhr, status, error) {
            console.error(xhr.responseText);
        }
    });
}

    // Function to close the pending registrations modal
    function closePendingRegistrationsModal() {
        document.getElementById('pendingRegistrationsModal').style.display = 'none';
    }
    </script>
    
</body>

</html>
