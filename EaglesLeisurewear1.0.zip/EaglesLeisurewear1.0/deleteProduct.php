<?php
include "db_connect.php"; // Include database connection

// Get the product ID to delete
$product_id = $_POST['product_id'];

// Delete the product from the database
$sql = "DELETE FROM cart_products WHERE id = $product_id";

if ($conn->query($sql) === TRUE) {
    echo "Product deleted successfully";
} else {
    echo "Error deleting product: " . $conn->error;
}

// Close the database connection
$conn->close();
?>