<?php
// Include your database connection file
include "db_connect.php";

// Initialize the search query
$searchQuery = "";

// Check if search input is provided
if (isset($_GET['searchInput'])) {
    // Sanitize the search input
    $searchInput = mysqli_real_escape_string($conn, $_GET['searchInput']);
    // Construct the search query to match product name
    $searchQuery .= " WHERE ProductName LIKE '%$searchInput%'";
}

// Check if price range is provided
if (isset($_GET['minPrice']) && isset($_GET['maxPrice'])) {
    // Sanitize and validate the price range
    $minPrice = (float)$_GET['minPrice'];
    $maxPrice = (float)$_GET['maxPrice'];
    if ($minPrice >= 0 && $maxPrice >= $minPrice) {
        // Add price condition to the search query
        $priceCondition = " AND price BETWEEN $minPrice AND $maxPrice";
        $searchQuery .= $searchQuery ? $priceCondition : " WHERE" . $priceCondition;
    }
}

// Check if category is provided
if (isset($_GET['category']) && $_GET['category'] !== 'All') {
    // Sanitize the category
    $category = mysqli_real_escape_string($conn, $_GET['category']);
    // Add category condition to the search query
    $categoryCondition = " AND LOWER(category) = LOWER('$category')";
    $searchQuery .= $searchQuery ? $categoryCondition : " WHERE" . $categoryCondition;
}

// Query to fetch filtered products
$query = "SELECT * FROM products$searchQuery";

// Debugging: Echo the constructed SQL query
// echo $query;

$result = mysqli_query($conn, $query);

// Check if products are found
if ($result && mysqli_num_rows($result) > 0) {
    $filteredProducts = array();
    while ($row = mysqli_fetch_assoc($result)) {
        // Add each product to the filtered products array
        $filteredProducts[] = $row;
    }
    // Return the filtered products as JSON
    echo json_encode($filteredProducts);
} else {
    // If no products are found, return an empty array as JSON
    echo json_encode(array());
}
?>
