<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "eagles";


try {
    // Create connection
    $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    // Set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Data to insert
    $customer = "Steve Johnson";
    $product = "Logo T-Shirt";
    $price = "25.00";
    $paymentReceipt = "Payment #12345";
    $status = "Validating";

    // SQL query to insert data
    $sql = "INSERT INTO payments (Customer, Product, Price, Payment_receipt, Status) 
            VALUES (:customer, :product, :price, :paymentReceipt, :status)";

    // Prepare the statement
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':customer', $customer);
    $stmt->bindParam(':product', $product);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':paymentReceipt', $paymentReceipt);
    $stmt->bindParam(':status', $status);

    // Execute the statement
    $stmt->execute();

    echo "New record inserted successfully";
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

// Close connection
$conn = null;