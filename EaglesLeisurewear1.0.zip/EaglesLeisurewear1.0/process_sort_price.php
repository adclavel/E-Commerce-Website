<?php
// Include your database connection file
include "db_connect.php";

// Default sorting
$orderBy = "";

// Check the sorting type
if ($_GET['sort'] === 'Low to High') {
    $orderBy = "price ASC";
} elseif ($_GET['sort'] === 'High to Low') {
    $orderBy = "price DESC";
}

// Query to fetch sorted products from the database with price sorting
$query = "SELECT id, ProductName, price, image FROM products ORDER BY $orderBy";
$result = mysqli_query($conn, $query);

// Display sorted product list
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $imageData = base64_encode($row["image"]);
        echo "<a href='user-order-product-page.php?id=" . $row['id'] . "'>";
        echo "<div class='product'>";
        echo "<img src='data:image/png;base64, $imageData'>";
        echo "<h3><strong></strong> " . $row['ProductName'] . "</h3>";
        echo "<h4><strong></strong> ₱" . $row["price"] . "</h4>";
        echo "</div>";
        echo "</a>";
        // Display other product details as needed
    }
} else {
    echo "No products found.";
}
?>
