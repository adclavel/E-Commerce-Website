<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "eagles";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if ID parameter is provided
if(isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare SQL statement to select specific fields based on ID
    $sql = "SELECT id, full_name, phone_number, email, club_name, facebook_url FROM registered_users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    // Execute SQL statement
    $stmt->execute();

    // Get result
    $result = $stmt->get_result();

    // Check if any rows are returned
    if ($result->num_rows > 0) {
        // Fetch row
        $row = $result->fetch_assoc();
        
        // Convert row to JSON format and return
        echo json_encode($row);
    } else {
        // No user found with the provided ID
        echo "No user found with the provided ID.";
    }
} else {
    // ID parameter is missing
    echo "ID parameter is missing.";
}

// Close connection
$stmt->close();
$conn->close();
?>
