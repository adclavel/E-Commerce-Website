<?php
include "db_connect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['product_id']) && isset($_POST['new_quantity'])) {
    $product_id = $_POST['product_id'];
    $new_quantity = $_POST['new_quantity'];

    // Update the quantity in the database
    $query = "UPDATE cart_products SET quantity = $new_quantity WHERE id = $product_id";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "Quantity updated successfully";
    } else {
        echo "Error updating quantity: " . mysqli_error($conn);
    }
} else {
    echo "Invalid request";
}
?>
