<?php
require 'C:\xampp2\htdocs\EaglesFinal\Mail\phpmailer\class.phpmailer.php';
require 'C:\xampp2\htdocs\EaglesFinal\Mail\phpmailer\class.smtp.php';
require 'C:\xampp2\htdocs\EaglesFinal\Mail\phpmailer\PHPMailerAutoload.php';

// SMTP configuration for Gmail
$smtp_server = 'smtp.gmail.com';
$smtp_port = 587; // Use 465 for SSL
$smtp_username = 'adrianpaulodonesclavel@gmail.com'; // Your Gmail email address
$smtp_password = 'htqj fwdi shbj jipl'; // Your Gmail password

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "eagles";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Accept user function
if (isset($_POST['accept_user'])) {
    // Retrieve ID from the form
    $id = $_POST['id'];

    // Check if the ID already exists in the users table
    $check_sql = "SELECT * FROM registered_users WHERE id = $id";
    $check_result = $conn->query($check_sql);
    if ($check_result->num_rows > 0) {
        echo "<script>alert('Error: Record with ID $id already exists in users table.');</script>";
        exit(); // Stop further execution
    }

     // Move data to another table (users)
     $sql = "INSERT INTO registered_users (id, full_name, club_name, phone_number, password, email, confirm_password, facebook_url) 
     SELECT id, full_name, club_name, phone_number, password, email, confirm_password, facebook_url 
     FROM registration 
     WHERE id = $id";
     

    if ($conn->query($sql) === TRUE) {
        // Get user's email and password from the users table
        $user_sql = "SELECT email, confirm_password FROM registered_users WHERE id = $id";
        $user_result = $conn->query($user_sql);
        if ($user_result->num_rows > 0) {
            $user_row = $user_result->fetch_assoc();
            $to_email = $user_row['email'];
            $password = $user_row['confirm_password'];
            
            $subject = "Registration Approved";
            $message = "Subject: Registration Approved - Log In to Your Account\n\n";
            $message .= "Dear User,\n\n";
            $message .= "We are pleased to inform you that your registration has been successfully approved. ";
            $message .= "You can now log in to your account using the following credentials:\n\n";
            $message .= "Email: $to_email\n";
            $message .= "Password: $password\n\n";
            $message .= "Please ensure to keep your login credentials confidential to maintain the security of your account.\n\n";
            $message .= "If you have any questions or encounter any issues, feel free to reach out to our support team at [Support Email] or visit our website for assistance.\n\n";
            $message .= "Thank you for choosing Eagles Leisurewear!\n\n";
            $message .= "Best regards,\n";
            $message .= "Eagles Leisurewear Team";

            // Create PHPMailer instance
            $mail = new PHPMailer;

            // Configure PHPMailer
            $mail->isSMTP();
            $mail->Host = $smtp_server;
            $mail->Port = $smtp_port;
            $mail->SMTPAuth = true;
            $mail->Username = $smtp_username;
            $mail->Password = $smtp_password;
            $mail->setFrom($smtp_username, 'Eagles Leisurewear');
            $mail->addAddress($to_email);

            // Email content
            $mail->isHTML(false);
            $mail->Subject = $subject;
            $mail->Body = $message;

            // Send email
            if ($mail->send()) {
                echo "<script>alert('Email sent successfully to $to_email.');</script>";
                echo "<script>window.location.reload();</script>"; // Refresh the page
            } else {
                echo "<script>alert('Error sending email to $to_email: " . $mail->ErrorInfo . "');</script>";
            }
        } else {
            echo "<script>alert('Error: Could not find email address for the user.');</script>";
        }
        
        // Delete the user from the registration table
        $delete_sql = "DELETE FROM registration WHERE id = $id";
        if ($conn->query($delete_sql) !== TRUE) {
            echo "<script>alert('Error deleting user data from registration table: " . $conn->error . "');</script>";
        }
    } else {
        echo "<script>alert('Error moving user data: " . $conn->error . "');</script>";
    }
}

// Reject user function
if (isset($_POST['reject_user'])) {
    // Retrieve ID from the form
    $id = $_POST['id'];

    // Get user's email from the registration table
    $to_email_sql = "SELECT email FROM registration WHERE id = $id";
    $to_email_result = $conn->query($to_email_sql);
    if ($to_email_result->num_rows > 0) {
        $to_email_row = $to_email_result->fetch_assoc();
        $to_email = $to_email_row['email'];
        
        $subject = "Registration Rejected";
        $message = "Subject: Registration Rejected\n\n";
        $message .= "Dear User,\n\n";
        $message .= "We regret to inform you that your registration request has been rejected.\n\n";
        $message .= "If you have any questions or require further information, please feel free to contact us at [Support Email].\n\n";
        $message .= "Thank you.\n\n";
        $message .= "Best regards,\n";
        $message .= "Eagles Leisurewear Team";

        // Create PHPMailer instance
        $mail = new PHPMailer;

        // Configure PHPMailer
        $mail->isSMTP();
        $mail->Host = $smtp_server;
        $mail->Port = $smtp_port;
        $mail->SMTPAuth = true;
        $mail->Username = $smtp_username;
        $mail->Password = $smtp_password;
        $mail->setFrom($smtp_username, 'Eagles Leisurewear');
        $mail->addAddress($to_email);

        // Email content
        $mail->isHTML(false);
        $mail->Subject = $subject;
        $mail->Body = $message;

        // Send email
        if ($mail->send()) {
            echo "<script>alert('Email sent successfully to $to_email.');</script>";
        } else {
            echo "<script>alert('Error sending email to $to_email: " . $mail->ErrorInfo . "');</script>";
        }
    } else {
        echo "<script>alert('Error: Could not find email address for the user.');</script>";
    }
    
    // Delete the user from the registration table
    $delete_sql = "DELETE FROM registration WHERE id = $id";
    if ($conn->query($delete_sql) !== TRUE) {
        echo "<script>alert('Error deleting user data from registration table: " . $conn->error . "');</script>";
    }
}

// Close connection
$conn->close();
?>