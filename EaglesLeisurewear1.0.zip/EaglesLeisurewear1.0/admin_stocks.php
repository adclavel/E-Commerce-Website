
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Metadata for character set and viewport -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Title of the document -->
    <title>Admin Dashboard - Stocks Management</title>

    <!-- External stylesheets for Font Awesome icons and Roboto font -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300;400;700&display=swap">

    <!-- Internal styles for the document -->
    <style>
        /* Reset default margin and padding for the body */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif; /* Use Arial or sans-serif as fallback font */
        }

        /* Header styles */
        header {
            background: linear-gradient(45deg, #292929, #1a1a1a); /* Gradient background */
            color: #fff;
            padding: 5px;
            border-bottom: 7px solid #FCB900;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            display: flex;
            align-items: center;
        }

        /* Header logo styles */
        .header-logo {
            height: auto;
            width: 90px;
            margin-right: 15px;
        }

        /* Title styles */
        .title {
            font-size: 24px; /* Font size */
            font-weight: bold; /* Bold font weight */
            color: #FCB900; /* Gold color for the title */
            margin-left: 15px; /* Left margin for spacing */
            font-family: 'Roboto Condensed', sans-serif; /* Use Roboto Condensed font */
        }

        /* Navigation categories container styles */
        .nav-categories {
            background: linear-gradient(45deg, #696969, #1a1a1a); /* Gradient background */
            display: flex;
            flex-direction: column; /* Align categories vertically */
            padding: 10px 0;
            position: absolute;
            left: 0;
            top: 100px; /* Adjust top value as needed */
            width: 180px; /* Set a fixed width for the left side */
            border-right: 4px solid #FCB900; /* Add a right border */
            height: calc(100vh - 120px); /* Set the height to fill the remaining viewport height */
        }

        /* Navigation category links styles */
        .nav-categories a {
            text-decoration: none;
            color: #fff;
            font-size: 20px;
            margin: 10px 20px;
            position: relative;
            transition: color 0.3s;
        }

        /* Navigation category link hover styles */
        .nav-categories a:hover {
            color: yellow;
        }

        /* Navigation category link underline styles */
        .nav-categories a::after {
            content: '';
            display: block;
            width: 0;
            height: 2px;
            background-color: yellow;
            position: absolute;
            bottom: 0;
            left: 50%;
            transition: width 0.3s ease;
            transform: translateX(-50%);
        }

        /* Navigation category link hover underline styles */
        .nav-categories a:hover::after {
            width: 100%;
        }
/* Fixed navigation styles */
.nav-categories.fixed {
    position: fixed;
    top: 0;
    left: 0;
    width: 180px;
    z-index: 1;
    margin-top: 0;
    height: 100vh; /* Set the fixed height to cover the entire viewport */
    overflow-y: auto; /* Add overflow-y: auto to enable scrolling within the fixed container if needed */
}      /* Sub-categories list styles */
        .sub-categories {
            display: none;
            list-style-type: none;
            padding-left: 20px;
        }

        /* Sub-category item styles */
        .nav-categories:hover .sub-categories {
            display: block;
        }

        /* Sub-category item hover styles */
        .sub-categories li {
            font-size: 14px;
            margin: 5px 0;
            color: #fff;
            cursor: pointer;
        }

        /* Sub-category item hover underline styles */
        .sub-categories li:hover {
            text-decoration: underline;
        }

        /* Footer styles */
        footer {
            background-color: #FFFFFF;
            color: #292929;
            padding: 0px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
            border-top: 1px solid #848484;
            font-size: 10px;
        }

        /* Main content container styles */
     /* Main Content section */
.main-content {
    margin-left: 200px;
    padding: 20px;
    z-index: 2;
    background: white;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Updated styles for the <hr> element */
.main-content hr {
    border: none;
    height: 2px;
    background-color: #FCB900; /* Dark yellow color */
    margin: 20px 0; /* Adjusted margin for spacing */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3); /* Added box shadow */
}
        /* Outer frame styles */
        .outer-table-frame {
            border: 2px solid #ddd; /* Set border properties as needed */
            border-radius: 15px; /* Add border-radius for a rounded appearance */
            overflow: hidden;
            margin-bottom: 20px;
            width: 90%; /* Adjusted maximum width, including border width */
            margin: 0 auto; /* Centered the outer frame */
            background-color: #f0f0f0; /* Light grey background color */
            padding: 20px; /* Added padding */
        }

        /* Search, Add Product, Add Size, Add Price, and Sort by container styles */
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
/* Updated styles for modern buttons */
.add-btn {
    background-color: #DAA520;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

.add-btn:hover {
    background-color: #FFD700;
}

/* Additional styling for the buttons */
.add-btn:focus {
    outline: none;
    box-shadow: 0 0 5px rgba(52, 152, 219, 0.8);
}
      /* Updated styles for the search bar */
.search-bar {
    width: 30%;
    position: relative;
    display: flex;
    align-items: center;
}

/* Input styles */
.search-bar input {
    flex: 1;
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 25px; /* Rounded corners */
    outline: none;
    font-size: 14px;
    transition: border-color 0.3s, box-shadow 0.3s;
}

/* Adjust background color on hover for a stylish effect */
.search-bar:hover input {
    border-color: #555; /* Highlight border on hover */
}

/* Search icon styles */
.search-bar i {
    margin-right: 10px;
    color: #555;
}

  /* Table frame styles */
        .table-frame {
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
            background-color: #f9f9f9;
            margin-bottom: 20px;

            /* Adjust the size of the outer frame here */
            width: 100%; /* Set the width as a percentage or a specific value */
            margin: 5px; /* Adjust the margin as needed */
        }

        /* Main table container styles */
        .table-container {
            background: #f9f9f9;
            padding: 15px; /* Increase or decrease the padding as needed */
        }

        /* Table header styles */
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #FCB900;
            padding-bottom: 10px;
            margin-bottom: 10px;
            font-weight: bold; /* Added font-weight: bold; */
        }

        /* Table column styles */
        .table-column {
            flex: 1;
            text-align: center;
            padding: 10px;
        }

        /* Table row styles */
        .table-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
            margin-bottom: 10px;
        }
  /* Table cell styles */
  .table-cell {
            flex: 1;
            text-align: center;
            padding: 10px;
            font-size: 12px; /* Adjust the font size as needed */
        }
/* Updated styles for the action buttons in the "Actions" column */
.table-cell > .edit-btn,
.table-cell > .delete-btn {
    color: #A9A9A9 !important;
    cursor: pointer;
    font-size: 14px;
    transition: background-color 0.3s;
}

/* Edit button hover styles */
.table-cell > .edit-btn:hover {
    background-color: #FFD700 !important;
}

/* Delete button hover styles */
.table-cell > .delete-btn:hover {
    background-color: #FF4500 !important;
}
    

        /* Add a mobile-first responsive design */
/* Adjustments for smaller screens */
@media only screen and (max-width: 600px) {
    /* Adjust the header logo size for smaller screens */
    .header-logo {
        width: 60px;
    }

    /* Adjust the title font size for smaller screens */
    .title {
        font-size: 18px;
    }

    /* Adjust the navigation categories width for smaller screens */
    .nav-categories {
        width: 100%;
    }

    /* Adjust the margin-left for the main content for smaller screens */
    .main-content {
        margin-left: 0;
    }

    /* Adjust the width of the outer table frame for smaller screens */
    .outer-table-frame {
        width: 100%;
    }

    /* Adjust the width of the search bar for smaller screens */
    .search-bar {
        width: 100%;
    }

    /* Adjust the margin-left for the sort buttons for smaller screens */
    .sort-buttons {
        margin-left: 0;
    }

    /* Adjust the width of the table frame for smaller screens */
    .table-frame {
        width: 100%;
    }
}

/* Add styles for tablets */
@media only screen and (min-width: 601px) and (max-width: 768px) {
    /* Add tablet-specific styles here */
}

/* Add styles for larger screens (desktops) */
@media only screen and (min-width: 769px) {
    /* Add desktop-specific styles here */
}

/* Updated styles for the Add Size modal container */
#addSizeStocksModal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
}

/* Updated styles for the Add Size modal content with gradient background */
#addSizeStocksModal .modal-content {
    background: linear-gradient(to right, #C0C0C0, #FFF5EE); /* Adjust the colors as needed */
    margin: 10% auto;
    padding: 20px;
    border: none;
    width: 20%;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    border-radius: 10px;
}

/* Updated styles for the close button in the Add Size modal */
#addSizeStocksModal .close {
    color: #333;
    float: right;
    font-size: 24px;
    font-weight: bold;
}

#addSizeStocksModal .close:hover,
#addSizeStocksModal .close:focus {
    color: #555;
    text-decoration: none;
    cursor: pointer;
}

/* Updated styles for the form elements in the Add Size modal */
#addSizeStocksModal label {
    display: block;
    margin: 10px 0;
    font-size: 16px;
    color: #333;
}

#addSizeStocksModal input[type="text"],
#addSizeStocksModal input[type="number"],
#addSizeStocksModal select {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
}

#addSizeStocksModal button {
    background-color: #3498db;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

#addSizeStocksModal button:hover {
    background-color: #1c88c7;
}
/* Modal for adding product details */
#addProductModal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
}

/* Modal content with gradient background */
#addProductModal .modal-content {
    background: linear-gradient(to right, #C0C0C0, #FFF5EE); /* Adjust the colors as needed */
    margin: 10% auto;
    padding: 20px;
    border: none;
    width: 50%; /* Adjust width as needed */
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    border-radius: 10px;
}

/* Close button */
#addProductModal .close {
    color: #333;
    float: right;
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
}

#addProductModal .close:hover,
#addProductModal .close:focus {
    color: #555;
}

/* Form styling */
#addProductModal form {
    display: grid;
    gap: 15px;
}

/* Input and label styles */
#addProductModal label {
    font-size: 16px;
    color: #333;
}

#addProductModal input[type="text"],
#addProductModal input[type="number"],
#addProductModal select {
    width: calc(100% - 20px); /* Adjust width and padding */
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
}

/* Button styling */
#addProductModal button {
    background-color: #3498db;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

#addProductModal button:hover {
    background-color: #1c88c7;
}
/* Modal styles */
.modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0,0,0,0.4);
    }

    .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 50%;
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }

    </style>
<body>
    <!-- Header section -->
    <header>
        <img src="public/external/EaglesLogo.png" class="header-logo">       
         <h1 class="title">Eagle's Leisurewear Admin Portal </h1>
    </header>

      <!-- Navigation Categories section -->
      <div class="nav-categories">
        <a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
        <a href="admin_users.php"><i class="fas fa-user"></i> User Registration</a>
        <a href="admin_stocks.php"><i class="fas fa-box"></i> Products </a>
        <a href="admin_order_process.php"><i class="fas fa-money-bill"></i> Orders </a>
        <a href="log-in-page.php"><i class="fas fa-sign-out-alt"></i> Log Out</a>
        </div>


    <!-- Main Content section -->
    <div class="main-content">
        <h2>Stocks Management</h2>
        <hr>


<!-- Outer table frame with adjusted size -->
<div class="outer-table-frame">
    <!-- Action bar with search, add product, add size, add price, and sort by -->
    <div class="action-bar">
     <!-- Search bar -->
        <div class="search-bar">
            <i class="fas fa-search"></i>
            <input type="text" id="searchInput" placeholder="Search Product">
        </div>


        <!-- Button to open the modal -->
        <button class="add-btn" onclick="openAddProductModal()">Add Product</button>
        





    </div>
    
    <!-- Table frame with adjusted size -->
    <!-- Table header -->
    <div class="table-container">
    <div class="table-header">
        <div class="table-column">Product ID</div>
        <div class="table-column">Product</div>
        <div class="table-column">Price</div>
        <div class="table-column">Sizes</div>
        <div class="table-column">Stocks</div>
        <div class="table-column">Actions</div>
    </div>
    <!-- PHP code to fetch and display product data from separate tables -->
    <?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eagles";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch product details along with sizes, stocks, and price using JOIN, sorted by product name
$sql = "SELECT p.ID, p.ProductName, p.price, s.size AS Sizes, s.stocks AS Stocks 
    FROM products p 
    JOIN sizes_stocks s ON p.ID = s.product_id
    ORDER BY p.ProductName";
$result = $conn->query($sql);

// Check if there are any results
if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<div class='table-row'>";
        echo "<div class='table-column'>" . $row["ID"]. "</div>";
        echo "<div class='table-column product-name' contenteditable='false'>" . $row["ProductName"]. "</div>";
        echo "<div class='table-column price' contenteditable='false'>" . $row["price"]. "</div>";
        echo "<div class='table-column size' contenteditable='false'>" . $row["Sizes"]. "</div>";
        echo "<div class='table-column stocks' contenteditable='false'>" . $row["Stocks"]. "</div>";
        echo "<div class='table-column'>";
        echo "<button class='edit-btn' data-id='" . $row["ID"] . "' onclick='addStocks(" . $row["ID"] . ")'>Edit</button>";
        echo "<button class='delete-btn' data-id='" . $row["ID"] . "'>Delete</button>";
        echo "</div>";
        echo "</div>";
    }
} else {
    echo "<div class='table-row'><div class='table-column' colspan='6'>No products found.</div></div>";
}

// Close connection
$conn->close();
?>
</div>

<!-- Modal for adding product details -->
<div id="addProductModal" class="modal">
  <!-- Modal content -->
  <div class="modal-content">
    <span class="close" onclick="closeAddProductModal()">&times;</span>
    <form id="addProductForm" enctype="multipart/form-data">
      <label for="productName">Product Name:</label>
      <input type="text" id="productName" name="productName" required><br>
      <label for="price">Price:</label>
      <input type="number" id="price" name="price" min="0" step="0.01" required><br>
      <label for="category">Category:</label>
      <input type="text" id="category" name="category" required><br>
      <label for="image">Image:</label>
      <input type="file" id="image" name="image" accept="image/*" required><br>
      <label for="size">Size:</label>
      <select id="size" name="size" required>
        <option value="SMALL">Small</option>
        <option value="MEDIUM">MEDIUM</option>
        <option value="LARGE">LARGE</option>
      </select><br>
      <label for="stocks">Stocks:</label>
      <input type="number" id="stocks" name="stocks" required><br>
      <input type="submit" class="add-btn" value="Add Product">
    </form>
  </div>
</div>






    <!-- Footer section -->
    <footer>
        &copy; 2024 Eagle's Leisurewear. All rights reserved.
    </footer>

    <!-- JavaScript code for adding interactivity -->
  <script>
// Get the modal
var addProductModal = document.getElementById("addProductModal");

// Get the button that opens the modal
var addProductBtn = document.getElementsByClassName("add-btn")[0];

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Get the modal element
var addProductModal = document.getElementById("addProductModal");

// Get the close button for the modal
var closeBtn = document.getElementsByClassName("close")[0];

// Function to open the add product modal
function openAddProductModal() {
    addProductModal.style.display = "block";
}

// Function to close the add product modal
function closeAddProductModal() {
    addProductModal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == addProductModal) {
        closeAddProductModal();
    }
}

// When the user clicks on the close button, close the modal
closeBtn.onclick = function() {
    closeAddProductModal();
}

// When the user presses the escape key, close the modal
window.onkeydown = function(event) {
    if (event.key === "Escape") {
        closeAddProductModal();
    }
}
// Function to open add products modal
function openAddProductModal() {
    var addProductModal = document.getElementById("addProductModal");
    addProductModal.style.display = "block";
}

// Function to open add sizes and stocks modal
function openAddSizeStocksModal() {
    var addSizeStocksModal = document.getElementById("addSizeStocksModal");
    addSizeStocksModal.style.display = "block";
}

// Function to close modals
function closeModals() {
    var modals = document.querySelectorAll(".modal");
    modals.forEach(function(modal) {
        modal.style.display = "none";
    });
}

// Close modals when clicking anywhere outside the modal content
window.onclick = function(event) {
    var modals = document.querySelectorAll(".modal");
    modals.forEach(function(modal) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    });
}

// Close modals when pressing the escape key
window.onkeydown = function(event) {
    if (event.key === "Escape") {
        closeModals();
    }
}


// Submit form via AJAX
document.getElementById("addProductForm").addEventListener("submit", function(event){
  event.preventDefault();
  
  var formData = new FormData(this);
  
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "add_product.php", true);
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      // Handle response here
      console.log(xhr.responseText);
      // Close modal after successful submission
      closeAddProductModal();
    }
  };
  xhr.send(formData);
});


document.addEventListener('DOMContentLoaded', function() {
    // Get the modal
    var modal = document.getElementById("editModal");

    // Get the button that opens the modal
    var editButtons = document.querySelectorAll('.edit-btn');

    // Get the <span> element that closes the modal
    var closeBtn = document.querySelector(".close");

    // When the user clicks on the button, open the modal
    editButtons.forEach(function(editButton) {
        editButton.addEventListener('click', function() {
            var row = this.closest('.table-row');
            var id = this.getAttribute('data-id');
            var productName = row.querySelector('.product-name').textContent;
            var size = row.querySelector('.size').textContent;
            var stocks = row.querySelector('.stocks').textContent;

            document.getElementById("editProductId").value = id;
            document.getElementById("editProductName").value = productName;
            document.getElementById("editSize").value = size;
            document.getElementById("editStocks").value = stocks;

            modal.style.display = "block";
        });
    });

    // When the user clicks on <span> (x), close the modal
    closeBtn.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Add an event listener for the "Save Changes" button
    document.getElementById("saveChangesBtn").addEventListener('click', function() {
        // Gather the edited data
        var id = document.getElementById("editProductId").value;
        var productName = document.getElementById("editProductName").value;
        var size = document.getElementById("editSize").value;
        var stocks = document.getElementById("editStocks").value;

        // Send the edited data to the server using AJAX
        var xhr = new XMLHttpRequest();
        var url = "update_product.php";
        var params = "id=" + id + "&productName=" + productName + "&size=" + size + "&stocks=" + stocks;
        xhr.open("POST", url, true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                var response = JSON.parse(xhr.responseText);
                if (response.success) {
                    alert(response.message);
                    // Optionally, you can reload the page or update the product data displayed on the page
                    location.reload();
                } else {
                    alert(response.message);
                }
                modal.style.display = "none";
            }
        };

        xhr.send(params);
    });
});


document.addEventListener('DOMContentLoaded', function() {
    // Get all delete buttons
    var deleteButtons = document.querySelectorAll('.delete-btn');

    // Add click event listener to each delete button
    deleteButtons.forEach(function(deleteButton) {
        deleteButton.addEventListener('click', function() {
            var productId = this.getAttribute('data-id');
            
            // Ask for confirmation before deleting
            if (confirm("Are you sure you want to delete this product?")) {
                // Send AJAX request to delete_product.php
                var xhr = new XMLHttpRequest();
                var url = "delete_product.php";
                var params = "id=" + productId;
                xhr.open("POST", url, true);
                xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function() {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        var response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            // Reload the page to reflect the updated data
                            location.reload();
                        } else {
                            alert(response.message);
                        }
                    }
                };
                xhr.send(params);
            }
        });
    });
});


   // Function to filter products based on search input
   function filterProducts() {
        var input, filter, table, tr, td, i, j, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toUpperCase();
        table = document.querySelector(".table-container");
        tr = table.querySelectorAll(".table-row");

        // Loop through all table rows
        for (i = 0; i < tr.length; i++) {
            td = tr[i].querySelectorAll(".table-column"); // Get all columns in the row
            // Loop through all columns in the row
            for (j = 0; j < td.length; j++) {
                txtValue = td[j].textContent || td[j].innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = ""; // Show the row if the search query matches any column
                    break; // Exit the inner loop since a match is found
                } else {
                    tr[i].style.display = "none"; // Hide the row if no match is found in any column
                }
            }
        }
    }

    // Add event listener to search input
    document.getElementById("searchInput").addEventListener("keyup", filterProducts);

    function addStocks(productId) {
    var additionalStocks = prompt('Enter additional stocks:');
    if (additionalStocks !== null) {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "update_stocks.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                if (xhr.responseText === 'success') {
                    location.reload(); // Refresh the page if update is successful
                } else {
                    alert('Failed to add stocks. Please try again.');
                }
            }
        };
        xhr.send("id=" + productId + "&additionalStocks=" + encodeURIComponent(additionalStocks));
    }
}

</script>

</body>