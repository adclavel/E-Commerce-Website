<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eagles";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['id']) && isset($_POST['additionalStocks'])) {
    $productId = $_POST['id'];
    $additionalStocks = intval($_POST['additionalStocks']); // Convert to integer

    // Update the stocks in the database for the specified product ID
    $sql = "UPDATE sizes_stocks SET stocks = stocks + $additionalStocks WHERE product_id = $productId LIMIT 1";

    if ($conn->query($sql) === TRUE) {
        echo "success";
    } else {
        echo "error";
    }
}

$conn->close();
?>
