<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eagles";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the order ID from the AJAX request
$order_id = $_GET['id'];

// Query to fetch order details based on the order ID
$sql = "SELECT * FROM orders WHERE id = $order_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetch order details
    $row = $result->fetch_assoc();
    
    // Prepare order details as an associative array
    $orderDetails = array(
        'product_name' => $row["product_name"],
        'price' => $row["price"],
        'size' => $row["size"],
        'quantity' => $row["quantity"],
        'status' => $row["status"],
        'fullname' => $row["fullname"],
        'address' => $row["address"],
        'contact_number' => $row["contact_number"],
        'club_name' => $row["club_name"],
        'club_region' => $row["club_region"],
        'eagles_id' => $row["eagles_id"],
        'mode_of_payment' => $row["mode_of_payment"],
        'gcash_receipt' => $row["gcash_receipt"],
        'mode_of_delivery' => $row["mode_of_delivery"],
        'order_date' => $row["order_date"]
    );

    // Send order details as JSON response
    echo json_encode($orderDetails);
} else {
    // If no order found with the provided ID
    echo json_encode(array('error' => 'Order not found'));
}

// Close connection
$conn->close();
?>
