<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign-up Page</title>
<style>
          *{
            padding: 0%;
            margin: 0%;
            text-decoration: none;
            box-sizing: border-box;
          }

          body {
            font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            }

          /*header*/
          .home-page-header{
            border-bottom: 2px solid rgb(184, 184, 184);
            background-color: rgb(255, 255, 255);
            width: 100%;
            height: 85px;
          }

          .header-logo{
            padding-top: 10px;
            padding-left: 10px;
            padding-right: .5%;
            float: left;
          }

          .website-name{
            float: left;
            font-weight: bold;
            font-size: 35px;
            padding-top: 10px;
          }

          .home-page-dashboard ul{
            display: grid;
            padding-left: 20px;
            padding-right: 20px;
            grid-template-columns: 2.5fr 3fr 2fr 3fr;
            text-align: center;
            font-size: 20px;
          }

          .home-page-dashboard ul li{
            display: inline-block;
            line-height: 75px;
          }

          .home-page-dashboard ul li a{
            color: black;
          }

          .home-page-search-bar{
            border-width: 240px;
            border: 1px solid rgb(0, 0, 0);
            border-radius: 10px;
            padding-right: 20px;
            margin-right: 30px;
            margin-top: 20px ;
            float: right;
          }

          .home-page-search-bar i{
            margin-left: 10px;
            color:rgb(119, 119, 119);
          }

          .home-page-search-bar input{
            border: none;
            outline: none;
            font-size: 18px;
            width: 180px;
            height: 35px;
            border-width: 0px;
          }

          .home-page-icon-bag{
            margin-right: 15px;
            margin-top: 13px;
            float: right;
          }

          .home-page-icon-bag img{
            width: 43px;
          }

          .home-page-iconuser{
            float: right;
            margin-right: 30px;
            margin-top: 13px;
          }

/* BODY */
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #F4F4F4;
            border-radius: 8px;
            border: 1px solid #686767;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            
        }
        .form-group {
            margin-bottom: 10px;
            overflow:auto
            
        }
        .form-group label {
    display: block;
    width: 100%; /* Set the width of the label to 100% */
    margin-bottom: 5px; /* Add some bottom margin for spacing */
    text-align: left; /* Center-align the text */
    padding-left: 70px; /* Adjust the padding on the left side */
}

    .form-group input {
        width: 150px; /* Set the width of the input to 100% */
        height: 25px;
        padding: 10px;
        border: 1px solid #292929;
        border-radius: 5px;
        box-sizing: border-box;
        display: block;
        margin: 0 auto;
    }

        .column {
            width: 50%;
            float: right;
        }
        
input[type="submit"] {
  clear: both;
  width: 95px;
  height: 35px;
  padding: 10px;
  background-color: #292929;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  margin: 0 auto;
  display: block;
        }
input[type="submit"]:hover {
 background-color: #FCB900;
        }

.Main-page_logo {
  height: 100px;
  filter: drop-shadow(0px 0px 10px rgba(0, 0, 0, 0.5));
        } 
.form-group.left-side {
  width: 50%; /* Set the width of the left-side form group to 50% */
   float: left; /* Float the left-side form group to the left */
}

h4{
  text-align: center;
  margin-top: 20px;
  font-weight:500;
}

p {
  text-align: center;
  font-weight: 300;
}

.form-group_URL {
  margin-bottom: 10px;
  overflow:auto
}

.form-group_URL label {
  display: block;
  width: 100%; /* Set the width of the label to 100% */
  margin-bottom: 5px; /* Add some bottom margin for spacing */
  text-align: center; /* Center-align the text */

}

.form-group_URL input {
        width: 150px; /* Set the width of the input to 100% */
        height: 25px;
        padding: 10px;
        border: 1px solid #292929;
        border-radius: 5px;
        box-sizing: border-box;
        display: block;
        margin: 0 auto;
    }


/* FOOTER */

.home-page-temp-footer{
  padding-left: 30px;
  display:grid;
  grid-template-columns: 2fr 1fr .6fr 1fr;
  grid-gap: 20px;
  color: white;
  width: 100%;
  background-color: rgb(29, 29, 29);
}

.website-name-footer{
  margin-top: 20px;
}

.footer-logo{
  position: absolute;
}

.website-name-footer h1{
  margin-left: 80px;
}
.website-name-footer h4{
  margin-left: 10px;
  margin-top: 20px;
}

.links{
  margin-top: 20px;
  margin-bottom: 3%;
}

.links h1{
  margin-bottom: 20px;
}

.website-contact-info{
  margin-top: 20px;
  margin-bottom: 20px;
}

.website-contact-info h3{
  margin-bottom: 15px;
}

.website-location{
  margin-bottom: 3%;
  margin-top: 20px;
}

.location-icon{
  position: absolute;
}

.website-location h1{
  margin-bottom: 20px;
}
.website-location h4{
  margin-left: 50px;
  text-align: left;
}

.footer_quote {
  text-align: left;
}

.checkbox-container {
  display: flex;
  justify-content: center; /* Center horizontally */
  align-items: center; /* Center vertically */
  margin-top: 20px; /* Adjust as needed */
}

.checkbox {
  display: flex;
  align-items: center; /* Align checkbox and label vertically */
}



/* FOOTER */


</style>

</head>
<body>
  <header class="header">
  <div class="home-page-header">
    <img
      class="header-logo"
      src="public/external/thefraternalorderofeagles13712-cfl-200h.png"
      alt="TheFraternalOrderofEagles13712"
    />
    <span class="website-name">
      <span>Eagle’s Leisurewear</span>  
    </span>
    <div class="home-page-iconuser">
        <a href="my-account.php"><img src="public/external/user3812-jwm2-200h.png" ></a>
    </div>
    <div class="home-page-icon-bag">
      <a href="add-to-cart-page.php"><img src="public/external/shoppingbagfull3812-ovvi-200h.png"/></a>
    </div>
    <div class="home-page-search-bar">
      <i class="fa-solid fa-magnifying-glass"></i>
      <input type="text" placeholder="Search">
    </div>
    <div class="home-page-dashboard">
      <ul>
        <li> <a href="index.php">Home</a></li>
        <li> <a href="user-shop-page.php">Shop</a></li>
        <li> <a href="about-us-user-page.php">About Us</a></li>
        <li> <a href="contact-us-user-page.php">Contact Us</a></li>
      </ul>
    </div>
  </div>
</header>

<!-- MAIN -->

<main>
  <section>
    <div class="container">
      <img 
      src="public/external/EaglesLogo.png"
      alt="Logo"
      style="display: block; margin: 0 auto;"
      class="Main-page_logo">

      <h2>Sign-Up</h2>
      <form action="connect.php" method="post" onsubmit="return validateForm()">
    <div class="form-group left-side">
      <label for="full_name">Full Name:</label>
      <input type="text" id="full_name" name="full_name" required>
    </div>
    
    <div class="form-group">
      <label for="club_name">Club Name:</label>
      <input type="text" id="club_name" name="club_name" required>
    </div>
    
    <div class="form-group left-side">
      <label for="phone_number">Phone Number:</label>
      <input type="text" id="phone_number" name="phone_number" required>
    </div>
    
    <div class="form-group">
      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required>
    </div>
    
    <div class="form-group left-side">
      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required>
    </div>
    
    <div class="form-group">
      <label for="confirm_password">Confirm Password:</label>
      <input type="password" id="confirm_password" name="confirm_password" required>
    </div>
    
    <div class="form-group_URL">
      <label for="facebook_url" class="FB_URL">Facebook URL:</label>
      <input type="text" id="facebook_url" name="facebook_url" class="FB_URL">
    </div>
    
    <div class="checkbox-container">
      <input type="checkbox" id="terms_conditions" name="terms_conditions" required>
      <label id="agree" for="terms_conditions">I agree to the <a href="terms-of-service.php" target="_blank">Terms and Conditions</a></label>
    </div>

    <br>
    
    <input type="submit" value="Submit">
  </form>


      <h4>About Us:</h4>
      <p>At Eagle's Leisure, we're more th an just a website;
         we're a virtual haven for fraternity enthusiasts and like-minded individuals. 
         Dive into a world where camaraderie, fun, and the spirit of brotherhood come together.
      </p>
  </div>

  </section>  
</main>
<!-- MAIN -->

<!--FOOTER -->
<footer>

  <div class="home-page-temp-footer">
    <div class="website-name-footer">
      <img class="footer-logo" src="public/external/thefraternalorderofeagles14032-c39-200h.png"/>
      <h1>Eagle’s Leisurewear</h1>
      <h4 class="footer_quote">At Eagle's Leisure, we're more than just a website; <br> we're a virtual for fraternity enthusiasts and like-minded <br> individuals. Dive into 
        a world where camaraderie, fun, <br> and the spirit of brotherhood together.</h4>
    </div>
    <div class="website-contact-info">
      <div class="info-list">
        <a href="contact-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>Contact Us</h3></a>
        <a href="about-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>About us</h3></a>
        <a href="user-shop-page.php" style="color: rgb(255, 255, 255);"><h3>Shop</h3></a>
        <a href="privacy-policy.php" style="color: rgb(255, 255, 255);"><h3>Privacy Policy</h3></a>
        <a href="terms-of-service.php" style="color: rgb(255, 255, 255);"><h3>Terms and Conditions</h3></a>
      </div>
    </div>
    <div class="links">
      <h1>Links</h1>
      <a href="https://www.facebook.com/eaglesleisurewear?mibextid=LQQJ4d" target="_blank"><img src="public/external/facebook4072-vhe-200h.png"/></a>
    </div>
    <div class="website-location">
      <h1>Our Location</h1>
        <img class="location-icon"src="public/external/location4112-y82-200h.png"/>
        <div class="address">
        <a href="https://maps.app.goo.gl/9u7YZqT3BBGyxHJv5" style="color: white;"><h4>1325 Malakas Street Pasig City</h4></a>
        <h4>National Capital Region</h4>
      </div>
    </div>
  </div>
</footer>
<!--FOOTER-->

<script>
    function validateForm() {
        var password = document.getElementById("password").value;
        var confirmPassword = document.getElementById("confirm_password").value;

        if (password !== confirmPassword) {
            alert("Passwords do not match.");
            return false; // Prevent form submission
        } else {
            return true; // Allow form submission
        }
    }
</script>


  
</body>
</html>