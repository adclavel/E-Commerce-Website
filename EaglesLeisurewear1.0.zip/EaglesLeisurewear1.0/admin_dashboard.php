<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300;400;700&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300;400;700&display=swap">

    <style>
        /* CSS styles for your dashboard */
        
        /* Responsive styles for smaller screens */
        @media only screen and (max-width: 768px) {
            header {
                flex-direction: column;
                text-align: center;
            }

            .header-logo {
                margin-bottom: 10px;
            }

            .dashboard-wrapper {
                flex-direction: column;
            }

            .dashboard-container {
                width: 100%;
                margin: 10px 0;
            }

            main {
                padding: 10px;
            }

            h1 {
                left: 0;
                margin-bottom: 10px;
            }
        }
        body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #f3f3f3 0%, #e0e0e0 100%); /* Gradient background */
}
.title {
    font-size: 24px; /* Font size */
    font-weight: bold; /* Bold font weight */
    color: #FCB900; /* Gold color for the title */
    margin-left: 15px; /* Left margin for spacing */
    font-family: 'Roboto Condensed', sans-serif; /* Use Roboto Condensed font */
}
        header {
            background: linear-gradient(90deg, #292929 0%, #1a1a1a 100%); /* Header gradient effect */
            color: #fff;
            padding: 10px;
            border-bottom: 7px solid #FCB900;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            display: flex;
            justify-content: flex-start;
            align-items: center;
        }

        .header-logo {
            height: auto;
            width: 90px;
            position: relative;
            left: 15px;
        }

        footer {
            background-color: #FFFFFF;
            color: #292929;
            padding: 10px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
            border-top: 1px solid #848484;
            font-size: 12px;
        }

        .container {
            padding: 20px;
        }

        main {
            padding: 20px;
        }

        h1 {
    font-weight: bold; /* Bold font weight */
    font-size: 32; /* Font size */
    color: #FCB900; /* Gold color for the title */
    margin-left: 20px; /* Left margin for spacing */
    font-family: 'Roboto Condensed', sans-serif; /* Use Roboto Condensed font */
}


        .dashboard-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap; /* Allow dashboard items to wrap to the next line */
        }

        /* Updated CSS for cooler dashboard containers */
        .dashboard-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            width: 300px;
            height: 140px;
            background: #FCB900; /* Background color */
            margin: 20px;
            border-radius: 15px; /* Increased border-radius for a rounded appearance */
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.3); /* More prominent box shadow */
            overflow: hidden;
            position: relative;
            transition: transform 0.3s ease, background-color 0.3s ease;
        }

        .dashboard-container:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.1); /* Slight overlay for depth effect */
            z-index: 1;
        }

        .dashboard-container:hover {
            transform: translateY(-5px);
            background-color: #FFD700; /* Highlight color on hover */
        }

        .icon {
            font-size: 40px;
            margin-bottom: 10px;
            color: #fff;
        }

        .title {
            font-size: 20px;
            font-weight: bold;
            color: #fff;
            z-index: 2;
        }

        .dashboard-wrapper a {
            text-decoration: none;
            color: inherit;
        }
    </style>
</head>
<body>
    <header>
        <img src="public/external/EaglesLogo.png" class="header-logo">
        <h1>Eagle's Leisurewear Admin Portal</h1>
    </header>

    <main class="container">
        <h2>Welcome to the Admin Dashboard!</h2>
        <p>This is where you can manage all your admin tasks.</p>
        <hr>

        <div class="dashboard-wrapper">

        <a href="admin_users.php" class="admin-dasgboard-link">
                <div class="dashboard-container">
                    <div class="icon">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="title">User Registration</div>
                </div>
            </a>

            <a href="admin_stocks.php" class="admin-dasgboard-link">
                <div class="dashboard-container">
                    <div class="icon">
                        <i class="fas fa-box"></i>
                    </div>
                    <div class="title">Products</div>
                </div>
            </a>

            <a href="admin_order_process.php" class="admin-dasgboard-link">
                <div class="dashboard-container">
                    <div class="icon">
                        <i class="fas fa-money-bill"></i>
                    </div>
                    <div class="title">Orders</div>
                </div>
            </a>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Admin Dashboard. All rights reserved.</p>
    </footer>
</body>
</html>