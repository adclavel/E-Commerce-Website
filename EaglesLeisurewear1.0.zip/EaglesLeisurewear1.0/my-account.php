<?php
  include "db_connect.php";
?>

<!DOCTYPE html>
<html lang="english">
  <head>
    <title>My-Account - exported project</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="./my-account1.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/e0abea836f.js" crossorigin="anonymous"></script>
  </head>
  <body>
  <?php
        session_start();

        // Check if the user is logged in
        if (!isset($_SESSION['id'])) {
            // Redirect the user to the login page if not logged in
            header("Location: log-in-page.php");
            exit();
        }

        // Fetch user data based on user ID stored in the session
        $user_id = $_SESSION['id'];

        // Prepare and execute a query to retrieve user data
        $sql = "SELECT * FROM registered_users WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if user data was retrieved successfully
        if ($result->num_rows > 0) {
            // Fetch the user data
            $user_data = $result->fetch_assoc();

            // Close the statement
            $stmt->close();
        } else {
            // Handle error (user not found)
            echo "User data not found.";
            exit();
        }
      ?>
      <!-- update -->
      <?php
      // Check if form is submitted and save button is clicked
      if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save_changes'])) {

          // Get data from form
          $full_name = $_POST['full_name'];
          $phone_number = $_POST['phone_number'];
          $club_name = $_POST['club_name'];
          $email = $_POST['email'];
          $facebook_url = $_POST['facebook_url'];

          // Get user ID
          $user_id = $_SESSION['id']; // Adjust this according to your login mechanism

          // SQL query to update database
          $sql = "UPDATE registered_users SET full_name = '$full_name', phone_number = '$phone_number', club_name = '$club_name', email = '$email', facebook_url = '$facebook_url' WHERE id = $user_id";

          if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Information Updated Successfully!')</script>";
            header("Location: my-account.php");
            exit(); 
          } else {
              echo $conn->error; // Echo the error message if the query fails
          }

          $conn->close();
      }
      ?>
      <!-- update -->
      <?php
      // Check if form is submitted and save button is clicked
      if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit-submit'])) {

          // Get data from form
          $full_name = $_POST['edit-fullname'];
          $phone_number = $_POST['edit-phonenumber'];
          $region_province_city_barangay = $_POST['edit-rpcb'];
          $postal = $_POST['edit-postal'];
          $streetname_building_housenum = $_POST['edit-sbh'];

          // Get user ID
          $user_id = $_SESSION['id']; // Adjust this according to your login mechanism

          // SQL query to update database
          $sql = "UPDATE registered_users SET full_name = '$full_name', phone_number = '$phone_number', region_province_city_barangay = '$region_province_city_barangay', postal = '$postal', streetname_building_housenum = '$streetname_building_housenum' WHERE id = $user_id";

          if ($conn->query($sql) === TRUE) {
              header("Location: my-account.php");
              exit();
          } else {
              echo $conn->error; // Echo the error message if the query fails
          }

          $conn->close();
      }
      ?>
    <div class="home-page-header">
      <img
        class="header-logo"
        src="public/external/thefraternalorderofeagles13712-cfl-200h.png"
        alt="TheFraternalOrderofEagles13712"
      />
      <span class="website-name">
        <span>Eagle’s Leisurewear</span>
      </span>
      <div class="home-page-iconuser">
        <a href="my-account.php"><img src="public/external/user3812-jwm2-200h.png" ></a>
      </div>
      <div class="home-page-icon-bag">
        <a href="add-to-cart-page.php"><img src="public/external/shoppingbagfull3812-ovvi-200h.png"/></a>
      </div>
      <div class="home-page-search-bar">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" id="searchInput" placeholder="Search" onkeydown="handleSearch(event)">
      </div>
      <div class="home-page-dashboard">
        <ul>
          <li> <a href="index.php">Home</a></li>
          <li> <a href="user-shop-page.php">Shop</a></li>
          <li> <a href="about-us-user-page.php">About Us</a></li>
          <li> <a href="contact-us-user-page.php">Contact Us</a></li>
        </ul>
      </div>
    </div>
      <div class="my-account-container">
        <div class="my-account">
          <div class="my-account-body">
            <div class="my-account-contents">
              <h1 class="my-account-text">My Account</h1>
              <span class="my-account-tabs">
                <h2 class="my-details" id="details-tab"><span><i class="fa-solid fa-user"></i></i>Account Details</span></h2>
                <h2 class="my-address" id="address-tab"><span><i class="fa-solid fa-location-dot"></i>My Addresses</span></h2>
                <h2 class="my-orders" id="orders-tab"><span><i class="fa-solid fa-bag-shopping"></i></i>My Orders</span></h2>
                <h2 class="log-out-text" id="log-out" ><i class="fa-solid fa-right-from-bracket"></i>Logout</h2>
              </span>
            </div>
            <div class="account-details" id="detailscontainer">
            <div id="alert-container"></div>
              <h1 class="my-account-details-text"><span>Account Details</span></h1>
              <h3 class="personal-information-text"><span>Personal Information</span></h3>
              <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
              <div class="account-details-input-box">
                <input class="full-name" id="fullname-personal-info" type="text" name="full_name" placeholder="Full Name" value="<?php echo $user_data['full_name']; ?>">   
                <input class="phone-number" id="phonenumber-personal-info" type="text" name="phone_number" placeholder="Phone Number" value="<?php echo $user_data['phone_number']; ?>">
                <input class="club-name" id="clubname-personal-info" type="text" name="club_name" placeholder="Club Name" value="<?php echo $user_data['club_name']; ?>">
                <input class="email" id="email-personal-info" type="text" name="email" placeholder="Email" value="<?php echo $user_data['email']; ?>">
                <input class="facebook-url" id="facebookurl-personal-info" type="text" name="facebook_url" placeholder="Facebook URL" value="<?php echo $user_data['facebook_url']; ?>">
              </div>
              <div class="account-details-buttons">
                <button class="save-button" id="save-personal-info" name="save_changes">Save</button>
                <button class="edit-button" id="edit-personal-info">Edit</button>
              </div>
              </form>
            </div>
            <div class="address-container" id="addresscontainer">
              <h1 class="my-address-text"><span>My Addresses</span></h1>
              <div class="address-header">
                <span class="address-text"><span>Address</span></span>
                <!-- <span class="add-new-address" id="add-new-address-button"><span><i class="fa-solid fa-plus"></i>Add New Address</span></span> -->
              </div>
              <div class="address-card">
                <div class="address-card-radio-button-container">
                  <input class="address-radio-button" type="radio">
                </div>
                <div class="address-card-details">
                  <b class="fullname"><?php echo $user_data['full_name']; ?> | </b>
                  <span class="phonenumber"><?php echo $user_data['phone_number']; ?></span>
                  <br>
                  <span class="rpcb"><?php echo $user_data['region_province_city_barangay']; ?></span>
                  <br>
                  <span class="sbh"><?php echo $user_data['streetname_building_housenum']; ?></span>
                  <br>
                  <span class="postal"><?php echo $user_data['postal']; ?></span>
                </div>
                <span class="edit-adress-card" id="edit-address">Edit</span>
              </div>
            </div>
              <!-- <div class="add-new-address-blur" id="add-new-address-blur">
                <div class="add-new-address-container" id="add-new-address-display">
                  <div class="add-new-address-address-label">
                    <label class="add-new-address-address">Add New Address</label>
                  </div>
                  <div class="add-new-address-details">
                    <input class="add-fullname" type="text" placeholder="Full Name">
                    <input class="add-phonenumber" type="text" placeholder="Phone Number">
                    <input class="add-rpcb" type="text" placeholder="Region, Province, City, Barangay">
                    <input class="add-postal" type="text" placeholder="Postal Code">
                    <input class="add-sbh" type="text" placeholder="Street Name, Building, House No.">
                  </div>
                  <div class="add-new-address-container-buttons">
                    <span class="add-new-address-buttons-cancel" id="cancel-add-new-address">Cancel</span>
                    <span class="add-new-address-buttons-submit" id="submit-add-new-address">Submit</span>
                  </div>
                </div>
              </div> -->
              <div class="edit-blur" id="edit-blur">
                <div class="edit-container" id="edit-display">
                  <div class="edit-address-label">
                    <label class="edit-address">Edit Address</label>
                  </div>
                  <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                  <div class="edit-details">
                    <input class="edit-fullname" name="edit-fullname" type="text" placeholder="Full Name" value="<?php echo $user_data['full_name']; ?>">
                    <input class="edit-phonenumber" name="edit-phonenumber" type="text" placeholder="Phone Number" value="<?php echo $user_data['phone_number']; ?>">
                    <input class="edit-rpcb" name="edit-rpcb" type="text" placeholder="Region, Province, City, Barangay" value="<?php echo $user_data['region_province_city_barangay']; ?>">
                    <input class="edit-postal" name="edit-postal" type="text" placeholder="Postal Code" value="<?php echo $user_data['postal']; ?>">
                    <input class="edit-sbh" name="edit-sbh" type="text" placeholder="Street Name, Building, House No." value="<?php echo $user_data['streetname_building_housenum']; ?>">
                  </div>
                  <div class="edit-container-buttons">
                    <button class="edit-buttons-cancel" id="cancel-edit">Cancel</button>
                    <button class="edit-buttons-submit" id="submit-edit-address" name="edit-submit">Submit</button>
                  </div>
                  </form>
                </div>
              </div>
            <div class="my-orders-container" id="orderscontainer">
              <h1 class="my-orders-text"><span>My Orders</span></h1>
              <div class="my-orders-tab">
                <span class="pending" id="pending">Pending</span>
                <span class="approved" id="approved">Approved</span>
                <span class="delivery" id="delivery">Delivery</span>
                <span class="received" id="received">Received</span>
                <span class="refunded" id="refunded">Refunded</span>
                <span class="cancelled" id="cancelled">Cancelled</span>
              </div>
              <div class="pending-page" id="pending-page">
              <?php
// Fetch orders with status "Pending" from the database
$query = "SELECT * FROM orders WHERE status = 'Pending'";
$result = mysqli_query($conn, $query);

// Check if there are any pending orders
if (mysqli_num_rows($result) > 0) {
    // Output each pending order in the desired format
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<div class="pending-container">';
        echo '<div class="pending-head">';
        echo '<span class="product-name">' . $row['product_name'] . '</span>';
        echo '<span class="order-date">Order Placed on ' . date('m/d/Y', strtotime($row['order_date'])) . '</span>';
        echo '</div>';
        echo '<div class="pending-order-card">';
        echo '<img class="product-image" src="data:image/jpeg;base64,' . $row['image'] . '">';
        echo '<div class="pending-order-card-details">';
        echo '<li class="product-qty">Quantity: ' . $row['quantity'] . '</li>';
        echo '<li class="product-price">Price: ₱' . number_format($row['price'], 2) . '</li>';
        echo '<li class="product-status">Status: ' . $row['status'] . '</li>';
        echo '</div>';
        echo '<div class="cancel-order" data-order-id="' . $row['id'] . '">';
        echo '<span class="cancel" id="cancel-order">Cancel Order</span>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
} else {
    // Output a message if there are no pending orders
    echo '<div class="pending-page" id="pending-page">';
    echo '</div>';
}
?>
            </div>
              <div class="approved-page" id="approved-page">
              <?php
// Fetch orders with status "Pending" from the database
$query = "SELECT * FROM orders WHERE status = 'Approved'";
$result = mysqli_query($conn, $query);

// Check if there are any pending orders
if (mysqli_num_rows($result) > 0) {
    // Output each pending order in the desired format
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<div class="approved-container">';
        echo '<div class="approved-head">';
        echo '<span class="product-name">' . $row['product_name'] . '</span>';
        echo '<span class="order-date">Order Placed on ' . date('m/d/Y', strtotime($row['order_date'])) . '</span>';
        echo '</div>';
        echo '<div class="approved-order-card">';
        echo '<img class="product-image" src="data:image/jpeg;base64,' . $row['image'] . '">';
        echo '<div class="approved-order-card-details">';
        echo '<li class="product-qty">Quantity: ' . $row['quantity'] . '</li>';
        echo '<li class="product-price">Price: ₱' . number_format($row['price'], 2) . '</li>';
        echo '<li class="product-status">Status: ' . $row['status'] . '</li>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
} else {
    // Output a message if there are no pending orders
    echo '<div class="approved-page" id="approved-page">';
    echo '</div>';
}
?>
              </div>
              <div class="delivery-page" id="delivery-page">
              <?php
// Fetch orders with status "Pending" from the database
$query = "SELECT * FROM orders WHERE status = 'Delivery'";
$result = mysqli_query($conn, $query);

// Check if there are any pending orders
if (mysqli_num_rows($result) > 0) {
    // Output each pending order in the desired format
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<div class="delivery-container">';
        echo '<div class="delivery-head">';
        echo '<span class="product-name">' . $row['product_name'] . '</span>';
        echo '<span class="order-date">Order Placed on ' . date('m/d/Y', strtotime($row['order_date'])) . '</span>';
        echo '</div>';
        echo '<div class="delivery-order-card">';
        echo '<img class="product-image" src="data:image/jpeg;base64,' . $row['image'] . '">';
        echo '<div class="delivery-order-card-details">';
        echo '<li class="product-qty">Quantity: ' . $row['quantity'] . '</li>';
        echo '<li class="product-price">Price: ₱' . number_format($row['price'], 2) . '</li>';
        echo '<li class="product-status">Status: ' . $row['status'] . '</li>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
} else {
    // Output a message if there are no pending orders
    echo '<div class="delivery-page" id="delivery-page">';
    echo '</div>';
}
?>
              </div>
              <div class="received-page" id="received-page">
              <?php
// Fetch orders with status "Pending" from the database
$query = "SELECT * FROM orders WHERE status = 'Received'";
$result = mysqli_query($conn, $query);

// Check if there are any pending orders
if (mysqli_num_rows($result) > 0) {
    // Output each pending order in the desired format
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<div class="received-container">';
        echo '<div class="received-head">';
        echo '<span class="product-name">' . $row['product_name'] . '</span>';
        echo '<span class="order-date">Order Placed on ' . date('m/d/Y', strtotime($row['order_date'])) . '</span>';
        echo '</div>';
        echo '<div class="received-order-card">';
        echo '<img class="product-image" src="data:image/jpeg;base64,' . $row['image'] . '">';
        echo '<div class="received-order-card-details">';
        echo '<li class="product-qty">Quantity: ' . $row['quantity'] . '</li>';
        echo '<li class="product-price">Price: ₱' . number_format($row['price'], 2) . '</li>';
        echo '<li class="product-status">Status: ' . $row['status'] . '</li>';
        echo '</div>';
        echo '<div class="refund-order" data-order-id="' . $row['id'] . '">';
        echo '<span class="refund" id="refund-order">Refund Order</span>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
} else {
    // Output a message if there are no pending orders
    echo '<div class="received-page" id="received-page">';
    echo '</div>';
}
?>
              </div>
              <div class="refunded-page" id="refunded-page">
              <?php
// Fetch orders with status "Pending" from the database
$query = "SELECT * FROM orders WHERE status = 'Refunded'";
$result = mysqli_query($conn, $query);

// Check if there are any pending orders
if (mysqli_num_rows($result) > 0) {
    // Output each pending order in the desired format
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<div class="refunded-container">';
        echo '<div class="refunded-head">';
        echo '<span class="product-name">' . $row['product_name'] . '</span>';
        echo '<span class="order-date">Order Placed on ' . date('m/d/Y', strtotime($row['order_date'])) . '</span>';
        echo '</div>';
        echo '<div class="refunded-order-card">';
        echo '<img class="product-image" src="data:image/jpeg;base64,' . $row['image'] . '">';
        echo '<div class="refunded-order-card-details">';
        echo '<li class="product-qty">Quantity: ' . $row['quantity'] . '</li>';
        echo '<li class="product-price">Price: ₱' . number_format($row['price'], 2) . '</li>';
        echo '<li class="product-status">Status: ' . $row['status'] . '</li>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
} else {
    // Output a message if there are no pending orders
    echo '<div class="refunded-page" id="refunded-page">';
    echo '</div>';
}
?>
              </div>
              <div class="cancelled-page" id="cancelled-page">
              <?php
// Fetch orders with status "Pending" from the database
$query = "SELECT * FROM orders WHERE status = 'Cancelled'";
$result = mysqli_query($conn, $query);

// Check if there are any pending orders
if (mysqli_num_rows($result) > 0) {
    // Output each pending order in the desired format
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<div class="cancelled-container">';
        echo '<div class="cancelled-head">';
        echo '<span class="product-name">' . $row['product_name'] . '</span>';
        echo '<span class="order-date">Order Placed on ' . date('m/d/Y', strtotime($row['order_date'])) . '</span>';
        echo '</div>';
        echo '<div class="cancelled-order-card">';
        echo '<img class="product-image" src="data:image/jpeg;base64,' . $row['image'] . '">';
        echo '<div class="cancelled-order-card-details">';
        echo '<li class="product-qty">Quantity: ' . $row['quantity'] . '</li>';
        echo '<li class="product-price">Price: ₱' . number_format($row['price'], 2) . '</li>';
        echo '<li class="product-status">Status: ' . $row['status'] . '</li>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }
} else {
    // Output a message if there are no pending orders
    echo '<div class="cancelled-page" id="cancelled-page">';
    echo '</div>';
}
?>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="home-page-temp-footer">
        <div class="website-name-footer">
          <img class="footer-logo" src="public/external/thefraternalorderofeagles14032-c39-200h.png"/>
          <h1>Eagle’s Leisurewear</h1>
          <h4>At Eagle's Leisure, we're more than just a website; <br> we're a virtual for fraternity enthusiasts and like-minded <br> individuals. Dive into 
            a world where camaraderie, fun, <br> and the spirit of brotherhood together.</h4>
        </div>
        <div class="website-contact-info">
          <div class="info-list">
            <a href="contact-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>Contact Us</h3></a>
            <a href="about-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>About us</h3></a>
            <a href="user-shop-page.php" style="color: rgb(255, 255, 255);"><h3>Shop</h3></a>
            <a href="privacy-policy.php" style="color: rgb(255, 255, 255);"><h3>Privacy Policy</h3></a>
            <a href="terms-of-service.php" style="color: rgb(255, 255, 255);"><h3>Terms and Conditions</h3></a>
          </div>
        </div>
        <div class="links">
          <h1>Links</h1>
          <a href="https://www.facebook.com/eaglesleisurewear?mibextid=LQQJ4d" target="_blank"><img src="public/external/facebook4072-vhe-200h.png"/></a>
        </div>
        <div class="website-location">
          <h1>Our Location</h1>
            <img class="location-icon"src="public/external/location4112-y82-200h.png"/>
            <div class="address">
            <a href="https://maps.app.goo.gl/9u7YZqT3BBGyxHJv5" style="color: white;"><h4>1325 Malakas Street Pasig City</h4></a>
            <h4>National Capital Region</h4>
          </div>
        </div>
      </div>
      <script>
    document.addEventListener("DOMContentLoaded", function () {
        var refundButtons = document.querySelectorAll(".refund-order");
        refundButtons.forEach(function (button) {
            button.addEventListener("click", function () {
                var orderId = this.dataset.orderId;
                refundOrder(orderId);
            });
        });
    });

    function refundOrder(orderId) {
        if (confirm("Are you sure you want to refund this order?")) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "refundOrder.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // Handle the response from the server
                    console.log(xhr.responseText);
                    if (xhr.responseText.trim() === "Order refunded successfully") {
                        // Optionally, you can update the UI here to reflect the change in status
                        location.reload(); // Reload the page to reflect the changes
                    }
                }
            };
            xhr.send("id=" + orderId);
        }
    }
</script>
      <script>
    document.addEventListener("DOMContentLoaded", function () {
        var cancelButtons = document.querySelectorAll(".cancel-order");
        cancelButtons.forEach(function (button) {
            button.addEventListener("click", function () {
                var orderId = this.dataset.orderId;
                cancelOrder(orderId);
            });
        });
    });

    function cancelOrder(orderId) {
        if (confirm("Are you sure you want to cancel this order?")) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "cancelOrder.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // Handle the response from the server
                    console.log(xhr.responseText);
                    if (xhr.responseText.trim() === "Order cancelled successfully") {
                        // Optionally, you can update the UI here to reflect the change in status
                        location.reload(); // Reload the page to reflect the changes
                    }
                }
            };
            xhr.send("id=" + orderId);
        }
    }
</script>
      <script>
        document.addEventListener("DOMContentLoaded", function() {
          const editpi = document.getElementById("edit-personal-info");
          const savepi = document.getElementById("save-personal-info");

          const fullnamepi = document.getElementById("fullname-personal-info");
          const phonenumberpi = document.getElementById("phonenumber-personal-info");
          const clubnamepi = document.getElementById("clubname-personal-info");
          const emailpi = document.getElementById("email-personal-info");
          const facebookurlpi = document.getElementById("facebookurl-personal-info");

          editpi.addEventListener("click", (event) => {
            event.preventDefault(); // Prevent form submission
            fullnamepi.style.pointerEvents = "auto";
            phonenumberpi.style.pointerEvents = "auto";
            clubnamepi.style.pointerEvents = "auto";
            emailpi.style.pointerEvents = "auto";
            facebookurlpi.style.pointerEvents = "auto";
          });

          savepi.addEventListener("click", (event) => {
            fullnamepi.style.pointerEvents = "";
            phonenumberpi.style.pointerEvents = "";
            clubnamepi.style.pointerEvents = "";
            emailpi.style.pointerEvents = "";
            facebookurlpi.style.pointerEvents = "";

          });
        });
      </script>
      <script>
        const editblur = document.getElementById("edit-blur");
        const editdisplay = document.getElementById("edit-display");
        const canceledit = document.getElementById("cancel-edit");
        const editaddress = document.getElementById("edit-address");
        const submitaddress = document.getElementById("submit-edit-address");

        // const addnewaddressblur = document.getElementById("add-new-address-blur");
        // const addnewaddressdisplay = document.getElementById("add-new-address-display");
        // const canceladdnewaddress = document.getElementById("cancel-add-new-address");
        // const addnewaddress = document.getElementById("add-new-address-button");

        // addnewaddress.addEventListener("click", () => {
        //   addnewaddressblur.style.display = "block";
        //   addnewaddressdisplay.style.display = "block";
        // })

        // canceladdnewaddress.addEventListener("click", () => {
        //   addnewaddressblur.style.display = "none";
        //   addnewaddressdisplay.style.display- "none";
        // })

        editaddress.addEventListener("click", () => {
          editblur.style.display = "block";
          editdisplay.style.display = "block";
        })

        canceledit.addEventListener("click", () => {
          editblur.style.display = "none";
          editdisplay.style.display- "none";
        })

        submitaddress.addEventListener("click", () => {
          editblur.style.display = "none";
          editdisplay.style.display- "none";
        })

      </script>
      <script>
        const detailscontainer = document.getElementById("detailscontainer");
        const addresscontainer = document.getElementById("addresscontainer");
        const orderscontainer = document.getElementById("orderscontainer");
        const logout = document.getElementById("log-out");
        const detailstab = document.getElementById("details-tab");
        const addresstab = document.getElementById("address-tab");
        const orderstab = document.getElementById("orders-tab");

        detailstab.addEventListener("click", () => {
          detailscontainer.style.display = "block";
          addresscontainer.style.display = "";
          orderscontainer.style.display = "";
        })

        addresstab.addEventListener("click", () => {
          detailscontainer.style.display = "none";
          addresscontainer.style.display = "block";
          orderscontainer.style.display = "";
        })

        orderstab.addEventListener("click", () => {
          pendingbutton.style.backgroundColor = "#dbdbdb";
          pendingbutton.style.borderTopLeftRadius = "10px";
          pendingbutton.style.borderBottomLeftRadius = "10px";
          approvedbutton.style.backgroundColor = "";
          deliverybutton.style.backgroundColor = "";
          receivedbutton.style.backgroundColor = "";
          refundedbutton.style.backgroundColor = "";
          cancelledbutton.style.backgroundColor = "";
          pendingpage.style.display = "block";
          approvedpage.style.display = "";
          deliverypage.style.display = "";
          receivedpage.style.display = "";
          refundedpage.style.display = "";
          cancelledpage.style.display = "";
          detailscontainer.style.display = "none";
          addresscontainer.style.display = "";
          orderscontainer.style.display = "block";
        })

        logout.addEventListener("click", () => {
          window.location.href = 'log-in-page.php';
        });

      </script>
      <script>
        const pendingpage = document.getElementById("pending-page");
        const approvedpage = document.getElementById("approved-page");
        const deliverypage = document.getElementById("delivery-page");
        const receivedpage = document.getElementById("received-page");
        const refundedpage = document.getElementById("refunded-page");
        const cancelledpage = document.getElementById("cancelled-page");
        const pendingbutton = document.getElementById("pending");
        const approvedbutton = document.getElementById("approved");
        const deliverybutton = document.getElementById("delivery");
        const receivedbutton = document.getElementById("received");
        const refundedbutton = document.getElementById("refunded");
        const cancelledbutton = document.getElementById("cancelled");

        pendingbutton.addEventListener("click", () => {
          pendingbutton.style.backgroundColor = "#dbdbdb";
          pendingbutton.style.borderTopLeftRadius = "10px";
          pendingbutton.style.borderBottomLeftRadius = "10px";
          pendingbutton.style.borderTopRightRadius = "0px";
          pendingbutton.style.borderBottomRightRadius = "0px";
          approvedbutton.style.backgroundColor = "";
          deliverybutton.style.backgroundColor = "";
          receivedbutton.style.backgroundColor = "";
          refundedbutton.style.backgroundColor = "";
          cancelledbutton.style.backgroundColor = "";
          pendingpage.style.display = "block";
          approvedpage.style.display = "";
          deliverypage.style.display = "";
          receivedpage.style.display = "";
          refundedpage.style.display = "";
          cancelledpage.style.display = "";
        })

        approvedbutton.addEventListener("click", () => {
          pendingbutton.style.backgroundColor = "";
          approvedbutton.style.backgroundColor = "#dbdbdb";
          deliverybutton.style.backgroundColor = "";
          receivedbutton.style.backgroundColor = "";
          refundedbutton.style.backgroundColor = "";
          cancelledbutton.style.backgroundColor = "";
          pendingpage.style.display = "none";
          approvedpage.style.display = "block";
          deliverypage.style.display = "";
          receivedpage.style.display = "";
          refundedpage.style.display = "";
          cancelledpage.style.display = "";
        })

        deliverybutton.addEventListener("click", () => {
          pendingbutton.style.backgroundColor = "";
          approvedbutton.style.backgroundColor = "";
          deliverybutton.style.backgroundColor = "#dbdbdb";
          receivedbutton.style.backgroundColor = "";
          refundedbutton.style.backgroundColor = "";
          cancelledbutton.style.backgroundColor = "";
          pendingpage.style.display = "none";
          approvedpage.style.display = "";
          deliverypage.style.display = "block";
          receivedpage.style.display = "";
          refundedpage.style.display = "";
          cancelledpage.style.display = "";
        })

        receivedbutton.addEventListener("click", () => {
          pendingbutton.style.backgroundColor = "";
          approvedbutton.style.backgroundColor = "";
          deliverybutton.style.backgroundColor = "";
          receivedbutton.style.backgroundColor = "#dbdbdb";
          refundedbutton.style.backgroundColor = "";
          cancelledbutton.style.backgroundColor = "";
          pendingpage.style.display = "none";
          approvedpage.style.display = "";
          deliverypage.style.display = "";
          receivedpage.style.display = "block";
          refundedpage.style.display = "";
          cancelledpage.style.display = "";
        })

        refundedbutton.addEventListener("click", () => {
          pendingbutton.style.backgroundColor = "";
          approvedbutton.style.backgroundColor = "";
          deliverybutton.style.backgroundColor = "";
          receivedbutton.style.backgroundColor = "";
          refundedbutton.style.backgroundColor = "#dbdbdb";
          cancelledbutton.style.backgroundColor = "";
          pendingpage.style.display = "none";
          approvedpage.style.display = "";
          deliverypage.style.display = "";
          receivedpage.style.display = "";
          refundedpage.style.display = "block";
          cancelledpage.style.display = "";
        })

        cancelledbutton.addEventListener("click", () => {
          pendingbutton.style.backgroundColor = "";
          cancelledbutton.style.borderTopRightRadius = "10px";
          cancelledbutton.style.borderBottomRightRadius = "10px";
          cancelledbutton.style.borderTopLeftRadius = "0px";
          cancelledbutton.style.borderBottomLeftRadius = "0px";
          approvedbutton.style.backgroundColor = "";
          deliverybutton.style.backgroundColor = "";
          receivedbutton.style.backgroundColor = "";
          refundedbutton.style.backgroundColor = "";
          cancelledbutton.style.backgroundColor = "#dbdbdb";
          pendingpage.style.display = "none";
          approvedpage.style.display = "";
          deliverypage.style.display = "";
          receivedpage.style.display = "";
          refundedpage.style.display = "";
          cancelledpage.style.display = "block";
        })
      </script>
      <script>
        function handleSearch(event) {
            if (event.key === 'Enter') {
                searchProducts();
            }
        }

        function searchProducts() {
            var searchInput = document.getElementById('searchInput').value.toLowerCase();

            // Redirect to the results page with the search query as a parameter
            window.location.href = 'user-shop-page.php?query=' + encodeURIComponent(searchInput);
        }
    </script>
  </body>
</html>
