<?php
  include "db_connect.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eagle's Leisurewear Login</title>
    <style>
        body {
            font-family: Arial;
            background-color: #ffff;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            font-size: smaller;
        }

        .login-container {
            background-color: #F4F4F4;
            padding: 20px;
            border-radius: 5px;
            border: 1px solid #686767;
            max-width: 400px;
            width: 100%;
            height: fit-content;
            max-height: fit-content;
            position: relative;
            left: 140px;
        }

        .log-in_logo {
            width: 100px;
            margin-left: 150px;
        }

        .login-container h2 {
            text-align: center;
            font-weight: bolder;
            font-size: x-large;
            position: relative;
        }


        .login-container h1 {
            text-align: center;
            font-weight: bold;
            font-size: 40px;
            margin-bottom: 0px;
        }

        h5 a {
            color: #292929; /* Change the color to #292929 */   
            text-decoration: none; /* Remove underline */
        }

        h5 a:hover {
            text-decoration: underline; /* Add underline on hover */
            color: #FCB900;
        }

        .login-container h5 {
            text-align: center;
        }

        .log-in_info {
            text-align: center;
        }

        .login-container input[type="text"],
        .login-container input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .login-container input[type="submit"] {
            width: 100%;
            background-color: #292929; /* Change background color to #292929 */
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .login-container input[type="submit"]:hover {
            background-color: #FCB900;
        }
  

        .side-container {
            background-color: #292929; /* Set background color to #292929 */
            margin-left: 300px;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .side-container img {
            width: 600px;
        }
        
    </style>
</head>
<body>
    <div class="login-container">
        <h2 class="title">Eagle's Leisurewear</h2>
        <img src="public/external/EaglesLogo.png" class="log-in_logo"> 
        <h2>Login</h2>
        <h1>Welcome!</h1>
        <form action="#" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="submit" value="Login">
        </form>
        <h5 class="with-links"><a href="sign-up-page.php">Sign-up</a></h5>
        <h5 class="with-links"><a href="recover_password.php">Recover Password</a></h5>
        <h5>Information:</h5>
        <p class="log-in_info">At Eagle's Leisure, we're more than just a website; 
            we're a virtual haven for fraternity enthusiasts and like-minded individuals. Dive into a world where camaraderie,
             fun, and the spirit of brotherhood come together.</p>
    </div>
    <?php
    session_start();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $username = $_POST["username"];
        $password = $_POST["password"];

        $query = "SELECT id FROM registered_users WHERE email=? AND confirm_password=?";
        $stmt = $conn->prepare($query);
        $queryadmin = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
        $resultadmin = $conn->query($queryadmin);

        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("ss", $username, $password);

        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows > 0) {

            $user = $result->fetch_assoc();

            $_SESSION['id'] = $user['id'];
            header("Location: index.php");
            exit();
        } else if ($resultadmin->num_rows > 0) {
            // Authentication successful
            echo "Login successful!";
            // You can redirect the user to a dashboard or another page if needed
            echo "<script>window.location.href = 'admin_dashboard.php';</script>";
        } else {
            // Authentication failed
            echo "<script>alert('Invalid username or password!');</script>";
        }

        $stmt->close();

        $conn->close();
    }
    ?>
    <div class="side-container">
        <img src="public/external/LOGO-Ceint-removebg-preview.png" alt="Logo">
    </div>
</body>
</html>
