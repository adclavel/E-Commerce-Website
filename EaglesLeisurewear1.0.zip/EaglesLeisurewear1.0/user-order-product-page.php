<!DOCTYPE php>
<php lang="en">
  <head>
    <title>User-Order-Product-Page - exported project</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="./user-order-product-page.css" />
    <script src="https://kit.fontawesome.com/e0abea836f.js" crossorigin="anonymous"></script>
  </head>
  <?php
include "db_connect.php";

// Check if the product ID is provided in the URL
if(isset($_GET['id']) && is_numeric($_GET['id'])) {
    $productId = $_GET['id'];
    
    // Retrieve product information based on the provided product ID
    $sql = "SELECT * FROM products WHERE id = $productId";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $product_data = $result->fetch_assoc();
        $imageData = base64_encode($product_data["image"]);
    } else {
        echo "Product not found.";
    }
} else {
    echo "Invalid product ID.";
}
?>
<?php
session_start();
// Include database connection code
include "db_connect.php";

// Check if the form is submitted
if (isset($_POST['addtocart'])) {

    $userId = $_SESSION['id']; // Make sure you start the session at the beginning of your script

    // Assuming you have fetched product details from the database
    $productId = $product_data['ID'];
    $image = $imageData;
    $productName = $product_data["ProductName"];
    $productPrice = $product_data["price"];

    // Capture size and quantity selected by the user from the form
    $productSize = @$_POST['productSize']; // Suppress warnings if productSize is not set
    $productQuantity = @$_POST['productQuantity']; // Suppress warnings if productQuantity is not set

    // Check if size and quantity are selected
    if ($productSize == "" || $productQuantity == "") {
        // Display an alert if size or quantity is not selected
        echo "<script>alert('Please select product size and quantity.');</script>";
    } else {
        // Insert product details into the cart_products table
        $sql = "INSERT INTO cart_products (user_id, product_id, image, ProductName, price, size, quantity) 
                VALUES ('$userId', '$productId', '$image', '$productName', '$productPrice', '$productSize', '$productQuantity')";
        if (mysqli_query($conn, $sql)) {
            // Insertion successful
            echo "<script>alert('Product added to cart successfully!');</script>";
        } else {
            // Insertion failed
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    }
}

// Close database connection
mysqli_close($conn);
?>
  <body>
    <div class="home-page-header">
      <img class="header-logo" src="public/external/thefraternalorderofeagles13712-cfl-200h.png" alt="TheFraternalOrderofEagles13712" />
      <span class="website-name">
        <span>Eagle’s Leisurewear</span>
      </span>
      <div class="home-page-iconuser">
        <a href="my-account.php"><img src="public/external/user3812-jwm2-200h.png" ></a>
      </div>
      <div class="home-page-icon-bag">
        <a href="add-to-cart-page.php"><img src="public/external/shoppingbagfull3812-ovvi-200h.png"/></a>
      </div>
      <div class="home-page-search-bar">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" placeholder="Search">
      </div>
      <div class="home-page-dashboard">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li><a href="user-shop-page.php">Shop</a></li>
          <li><a href="about-us-user-page.php">About Us</a></li>
          <li><a href="contact-us-user-page.php">Contact Us</a></li>
        </ul>
      </div>
    </div>
    <div class="user-order-product-page-body">
      <div class="tab">
        <span class="user-order-product-page-text29">All Products</span>
        <span class="greater-than"><i class="fa-solid fa-greater-than"></i></span>
        <span>Blue Bomber - Turtleneck</span>
      </div>
      <div class="product">
        <div class="product-image">
          <?php
          echo "<img src='data:image/png;base64, $imageData'>";
          ?>
        </div>
        <div class="product-details">
          <span class="product-details-website-name">
            <p>Eagle’s Leisurewear</p>
          </span>
          <span class="product-details-product-name">
            <?php
            echo "<h2>" . $product_data["ProductName"] . "</h2>";
            ?>
          </span>
          <span class="product-details-product-price">
              <?php
              echo "<h2>₱" . $product_data["price"] . "</h2>";
              ?>
          </span>
          <form method="post" onsubmit="return myFunctionCheckOut()">
    <span class="product-details-product-size">
        <span>Size: </span>
        <div class="dropdown">
            <select name="productSize"class="dropdown-size">
              <option value="" disabled selected>Select Size</option>
              <option>SMALL</option>
              <option>MEDIUM</option>
              <option>LARGE</option>
            </select>
        </div>
    </span>
    <div class="product-details-product-quantity">
        <span>QTY</span>
        <div class="dropdown">
            <select name="productQuantity" class="dropdown-qty">
            <option value="" disabled selected>Select Quantity</option>
              <option>1</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
              <option>5</option>
            </select>
        </div>
    </div>
    <div class="product-buttons">
    <!-- <button class="check-out-button" onclick="myFunctionCheckOut(event)" id="check-out-button" type="submit" name="checkout">Check Out</button> -->
        <button class="add-to-cart-button" type="submit" name="addtocart">Add to Cart</button>
    </div>
</form>
        </div>
      </div>
    </div>
    <div class="home-page-temp-footer">
      <div class="website-name-footer">
        <img class="footer-logo" src="public/external/thefraternalorderofeagles14032-c39-200h.png"/>
        <h1>Eagle’s Leisurewear</h1>
        <h4>At Eagle's Leisure, we're more than just a website; <br> we're a virtual for fraternity enthusiasts and like-minded <br> individuals. Dive into a world where camaraderie, fun, <br> and the spirit of brotherhood together.</h4>
      </div>
      <div class="website-contact-info">
        <div class="info-list">
          <a href="contact-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>Contact Us</h3></a>
          <a href="about-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>About us</h3></a>
          <a href="user-shop-page.php" style="color: rgb(255, 255, 255);"><h3>Shop</h3></a>
          <a href="privacy-policy.php" style="color: rgb(255, 255, 255);"><h3>Privacy Policy</h3></a>
          <a href="terms-of-service.php" style="color: rgb(255, 255, 255);"><h3>Terms and Conditions</h3></a>
        </div>
      </div>
      <div class="links">
        <h1>Links</h1>
        <a href="https://www.facebook.com/eaglesleisurewear?mibextid=LQQJ4d" target="_blank"><img src="public/external/facebook4072-vhe-200h.png"/></a>
      </div>
      <div class="website-location">
        <h1>Our Location</h1>
        <img class="location-icon" src="public/external/location4112-y82-200h.png"/>
        <div class="address">
          <a href="https://maps.app.goo.gl/9u7YZqT3BBGyxHJv5" style="color: white;"><h4>1325 Malakas Street Pasig City</h4></a>
          <h4>National Capital Region</h4>
        </div>
      </div>
    </div>
    <!-- <script>
function myFunctionCheckOut(event) {
    event.preventDefault(); // Prevent default form submission

    // Get selected size and quantity
    const selectedSize = document.querySelector('[name="productSize"]').value;
    const selectedQty = document.querySelector('[name="productQuantity"]').value;

    // Check if size and quantity are selected
    if (selectedSize === "" || selectedQty === "") {
        alert("Please select product size and quantity.");
    } else {
        // Redirect to delivery-payment-page.php with product details
        const productId = <?php echo $productId; ?>;
        const params = new URLSearchParams();
        params.append('selectedSize', selectedSize);
        params.append('selectedQty', selectedQty);
        window.location.href = `delivery-payment-page.php?id=${productId}&size=${selectedSize}&quantity=${selectedQty}${params.toString()}`;
    }
}
</script> -->

  </body>
</php>
