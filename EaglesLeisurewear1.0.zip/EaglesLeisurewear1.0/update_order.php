<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eagles";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['id']) && isset($_POST['status'])) {
    $orderId = $_POST['id'];
    $newStatus = $_POST['status'];

    $sql = "UPDATE orders SET status='$newStatus' WHERE id=$orderId";

    if ($conn->query($sql) === TRUE) {
        echo "success";
    } else {
        echo "error";
    }
}

$conn->close();
?>
