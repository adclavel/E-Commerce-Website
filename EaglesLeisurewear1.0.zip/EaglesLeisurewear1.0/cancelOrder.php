<?php
include "db_connect.php"; // Include your database connection file

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["id"])) {
    $orderId = $_POST["id"];

    // Retrieve product_id, size, and quantity from the cancelled order
    $orderQuery = "SELECT product_id, size, quantity FROM orders WHERE id = $orderId";
    $orderResult = mysqli_query($conn, $orderQuery);
    if ($orderResult && mysqli_num_rows($orderResult) > 0) {
        while ($orderData = mysqli_fetch_assoc($orderResult)) {
            $productId = $orderData['product_id'];
            $size = $orderData['size'];
            $cancelledQuantity = $orderData['quantity'];

            // Update the status of the order to "Cancelled"
            $updateQuery = "UPDATE orders SET status = 'Cancelled' WHERE id = $orderId";
            if (mysqli_query($conn, $updateQuery)) {
                // Restore the quantity of the cancelled product in sizes_stocks table
                $restoreQuery = "UPDATE sizes_stocks SET stocks = stocks + $cancelledQuantity WHERE product_id = $productId AND size = '$size'";
                if (mysqli_query($conn, $restoreQuery)) {
                    echo "Order cancelled successfully";
                } else {
                    echo "Error restoring product quantity: " . mysqli_error($conn);
                }
            } else {
                echo "Error updating order status: " . mysqli_error($conn);
            }
        }
    } else {
        echo "Order not found or invalid request";
    }
} else {
    echo "Invalid request";
}
?>