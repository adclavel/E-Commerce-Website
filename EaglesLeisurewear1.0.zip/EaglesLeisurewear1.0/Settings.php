<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Metadata for character set and viewport -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Title of the document -->
    <title>Settings</title>
    
    <!-- External stylesheets for Font Awesome icons and Roboto font -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300;400;700&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap">

    <!-- Internal styles for the document -->
    <style>
        /* Reset default margin and padding for the body */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif; /* Use Arial or sans-serif as fallback font */
            background-color: #f4f4f4; /* Light background color */
        }

        /* Header styles */
        header {
            background-color: #292929; /* Dark background color */
            color: #fff; /* Text color */
            padding: 5px; /* Padding around the header */
            border-bottom: 7px solid #FCB900; /* Bottom border with a gold color */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2); /* Shadow for a subtle elevation effect */
            overflow: hidden; /* Hide any content that overflows the header */
            display: flex; /* Use flexbox for layout */
            align-items: center; /* Align items vertically in the center */
        }

        /* Header logo styles */
        .header-logo {
            height: auto; /* Automatically adjust height */
            width: 90px; /* Fixed width */
            margin-right: 15px; /* Right margin for spacing */
        }

        /* Title styles */
        .title {
            font-size: 24px; /* Font size */
            font-weight: bold; /* Bold font weight */
            color: #FCB900; /* Gold color for the title */
            margin-left: 15px; /* Left margin for spacing */
            font-family: 'Roboto Condensed', sans-serif; /* Use Roboto Condensed font */
        }

        /* Navigation categories container styles */
        .nav-categories {
            background: linear-gradient(45deg, #696969, #1a1a1a); /* Gradient background */
            display: flex;
            flex-direction: column; /* Align categories vertically */
            padding: 10px 0;
            position: absolute;
            left: 0;
            top: 100px; /* Adjust top value as needed */
            width: 180px; /* Set a fixed width for the left side */
            border-right: 4px solid #FCB900; /* Add a right border */
            height: calc(100vh - 120px); /* Set the height to fill the remaining viewport height */
        }

        /* Navigation category links styles */
        .nav-categories a {
            text-decoration: none; /* Remove underline from links */
            color: #fff; /* White font color */
            font-size: 18px; /* Font size */
            margin: 10px 20px; /* Margin for spacing */
            display: flex; /* Use flexbox for layout */
            align-items: center; /* Align items vertically in the center */
            position: relative; /* Use relative positioning for pseudo-element */
            transition: color 0.3s; /* Smooth color transition */
            font-weight: normal; /* Regular font weight */
        }

        /* Add space between icon and text */
        .nav-categories a i {
            margin-right: 5px; /* Adjust margin for spacing */
        }

        /* Navigation category link hover styles */
        .nav-categories a:hover {
            color: yellow; /* Yellow font color on hover */
        }

        /* Navigation category link underline styles */
        .nav-categories a::after {
            content: ''; /* Empty content for pseudo-element */
            display: block; /* Block-level element for pseudo-element */
            width: 0; /* Initial width of 0 for pseudo-element */
            height: 2px; /* Underline height */
            background-color: yellow; /* Yellow color for the underline */
            position: absolute; /* Absolute positioning for the underline */
            bottom: 0; /* Align at the bottom of the link */
            left: 50%; /* Center the underline horizontally */
            transition: width 0.3s ease; /* Smooth width transition */
            transform: translateX(-50%); /* Adjust for centering */
        }

        /* Navigation category link hover underline styles */
        .nav-categories a:hover::after {
            width: 100%; /* Full width on hover */
        }

        /* Sub-categories list styles */
        .sub-categories {
            display: none; /* Initially hide sub-categories */
            list-style-type: none; /* Remove default list styles */
            padding-left: 20px; /* Left padding for sub-categories */
        }

        /* Sub-category item styles */
        .nav-categories:hover .sub-categories {
            display: block; /* Show sub-categories on hover */
        }

        /* Sub-category item hover styles */
        .sub-categories li {
            font-size: 14px; /* Font size */
            margin: 5px 0; /* Margin for spacing */
            color: #fff; /* White font color */
            cursor: pointer; /* Cursor style on hover */
        }

        /* Sub-category item hover underline styles */
        .sub-categories li:hover {
            text-decoration: underline; /* Underline text on hover */
        }

        /* Footer styles */
        footer {
            background-color: #FFFFFF; /* White background color */
            color: #292929; /* Dark gray font color */
            padding: 0px; /* No padding */
            text-align: center; /* Center-align text */
            position: fixed; /* Fixed positioning at the bottom */
            bottom: 0; /* Align at the bottom of the viewport */
            width: 100%; /* Full width */
            border-top: 1px solid #848484; /* Top border with a dark gray color */
            font-size: 10px; /* Font size */
        }

  /* Main Content section */
.main-content {
    margin-left: 200px;
    padding: 20px;
    z-index: 2;
    background: white;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Updated styles for the <hr> element */
.main-content hr {
    border: none;
    height: 2px;
    background-color: #FCB900; /* Dark yellow color */
    margin: 20px 0; /* Adjusted margin for spacing */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3); /* Added box shadow */
}
        /* Additional styles for the profile settings form */
        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="file"] {
            display: none;
        }

        .profile-container {
            display: flex;
            align-items: center;
        }

        /* Adjustments for the profile text */
        .profile-text {
            margin-left: 20px; /* Adjust the left margin as needed for spacing */
        }

        /* Additional styling for the profile text paragraphs */
        .profile-text p {
            margin: 5px 0;
        }

        /* Style for the bold name */
        .profile-text .name {
            font-weight: bold;
        }

        /* Style for the Montserrat font */
        .profile-text .fraternity {
            font-family: 'Montserrat', sans-serif;
            font-size: 12px;
        }

        /* Style for the profile picture container */
        .profile-picture-container {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            overflow: hidden;
            margin-bottom: 20px;
            position: relative;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .profile-picture-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .upload-icon {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 24px;
            color: #848484;
            cursor: pointer;
        }

     
        /* Style for the first horizontal line */
/* Style for the first horizontal line */
.yellow-hr {
    border-color: yellow;
}

/* Style for the second horizontal line */
.black-hr {
    border-color: black;
}
/* Additional styles for form groups to display side by side */
.form-group {
    display: inline-block;
    margin-right: 20px; /* Adjust as needed for spacing between the fields */
    width: 500px; /* Increase the width to your preferred value */
}


/* Updated styles for the password containers */
.password-container {
    position: relative;
}

.password-container input {
    width: calc(100% - 40px); /* Adjust the width to your preferred value */
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

/* Updated styles for the password icons */
.password-icon,
.view-password {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    transition: color 0.3s ease; /* Add transition for a smooth effect */
}

.password-icon {
    left: 10px; /* Adjust the left spacing for the key icon */
    color: #848484;
}

.view-password {
    right: 30px; /* Adjust the right spacing for the eye icon */
    color: #848484;
}

/* Adjust the color of the icons on hover */
.password-icon:hover,
.view-password:hover {
    color: #555;
}

.form-group button {
    padding: 10px 20px;
    margin-right: 10px;
    border: 2px solid #000000; /* Border color */
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    color: #000000; /* Initial font color */
    transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
}

.form-group button:hover {
    background-color: #696969; /* Gray color on hover for "Cancel" button */
    color: #fff; /* White text on hover for "Cancel" button */
}

.form-group button.save-changes {
    background-color: #696969; /* Green background for "Save Changes" button */
    color: #FFFFFF; /* Initial font color for "Save Changes" button */
}

.form-group button.save-changes:hover {
    background-color: #fff; /* White color on hover for "Save Changes" button */
    color: #000000; /* Restore initial font color on hover for "Save Changes" button */
}
</style>
</head>
<body>
    <!-- Header section -->
    <header>
        <img src="EaglesLogo.png" class="header-logo">
        <h1 class="title">Eagle's Leisurewear Admin Portal</h1>
    </header>

    <!-- Navigation Categories section -->
    <div class="nav-categories">
        <a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
        <a href="admin_users.php"><i class="fas fa-user"></i> User Registration</a>
        <a href="admin_stocks.php"><i class="fas fa-box"></i> Stocks</a>
        <a href="admin_prices.php"><i class="fas fa-dollar-sign"></i> Prices</a>
        <a href="admin_payment_validation.php"><i class="fas fa-money-bill"></i> Payments > </a>
        <ul class="sub-categories">
            <li><a href="admin_payment_validation.php"><i class="fas fa-check-circle"></i> Validation</a></li>
            <li><a href="admin_payment_process.php"><i class="fas fa-cogs"></i> Process</a></li>
            <li><a href="admin_payment_delivered.php"><i class="fas fa-truck"></i> Delivered</a></li>
        </ul>
        <a href="settings.php"><i class="fas fa-cog"></i>Settings</a>
        <a href="log-in-page.php"><i class="fas fa-sign-out-alt"></i>Log Out</a>
    </div>

    <!-- Main Content section -->
    <div class="main-content">
        <!-- Your main content goes here -->
        <h2>Settings</h2>
        <hr class="yellow-hr">

      <!-- Profile settings form -->
<form id="profile-settings-form">
    <!-- Profile picture upload and text container -->
    <div class="form-group">
        <label for="profile-picture">User Profile:</label>
        <div class="profile-container">
            <div class="profile-picture-container" onclick="document.getElementById('profile-picture').click()">
                <input type="file" id="profile-picture" name="profile-picture">
                <div class="upload-icon"><i class="fas fa-camera"></i></div>
                <!-- You may need additional code for handling file upload on the server -->
            </div>

            <!-- Additional text for name, label, and fraternity chapter -->
            <div class="profile-text">
                <p class="name">Name: John Doe</p>
                <p>Admin</p>
                <p class="fraternity">Fraternity Chapter: Montserrat</p>
                <!-- You can replace "John Doe," "Admin," and "Montserrat" with dynamic content from your data -->
            </div>
        </div>
    </div>

<!-- Horizontal line below the form group -->
<hr class="black-hr">
<!-- Current and New password fields side by side -->
<div class="form-group">
    <label for="current-password">Enter your current password:</label>
    <div class="password-container">
        <input type="password" id="current-password" name="current-password" placeholder="Enter Current Passowrd">
        <div class="view-password" onclick="togglePasswordVisibility('current-password')"><i class="fas fa-eye"></i></div>
    </div>
</div>

<div class="form-group">
    <label for="new-password">Enter your new password:</label>
    <div class="password-container">
        <input type="password" id="new-password" name="new-password" placeholder="Enter New Passowrd">
        <div class="view-password" onclick="togglePasswordVisibility('new-password')"><i class="fas fa-eye"></i></div>
    </div>
</div>

<div class="form-group">
    <label for="confirm-new-password">Confirm New Password:</label>
    <div class="password-container">
        <input type="password" id="confirm-new-password" name="confirm-new-password" placeholder="Confirm New Passowrd">
        <div class="view-password" onclick="togglePasswordVisibility('confirm-new-password')"><i class="fas fa-eye"></i></div>
    </div>
</div>
<!-- Cancel and Save Changes buttons -->
<div class="form-group">
    <button type="button" id="cancel-button">Cancel</button>
    <button type="button" id="save-button" class="save-changes">Save Changes</button>
</div>
        </form>
    </div>

    <!-- Footer section -->
    <footer>
        <p>&copy; 2024 Admin Dashboard. All rights reserved.</p>
    </footer>

    <!-- JavaScript script tag -->
    <script>
document.addEventListener('DOMContentLoaded', function () {
    // Get references to password input elements and corresponding icons
    var currentPasswordInput = document.getElementById('current-password');
    var newPasswordInput = document.getElementById('new-password');
    var confirmNewPasswordInput = document.getElementById('confirm-new-password');

    var currentPasswordIcon = document.getElementById('current-password-icon');
    var newPasswordIcon = document.getElementById('new-password-icon');
    var confirmNewPasswordIcon = document.getElementById('confirm-new-password-icon');

    // Function to handle input visibility icons based on input value
    function handleInput(input, icon) {
        if (input.value) {
            icon.classList.add('hide');
        } else {
            icon.classList.remove('hide');
        }
    }

    // Function to toggle password visibility
    function togglePasswordVisibility(input, icon) {
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    }

    // Event listeners for handling focus, blur, and input events
    function addEventListenersForInput(input, icon) {
        input.addEventListener('focus', function () {
            icon.classList.add('hide');
        });

        input.addEventListener('blur', function () {
            handleInput(input, icon);
        });

        input.addEventListener('input', function () {
            handleInput(input, icon);
        });
    }

    // Add event listeners for each password input
    addEventListenersForInput(currentPasswordInput, currentPasswordIcon);
    addEventListenersForInput(newPasswordInput, newPasswordIcon);
    addEventListenersForInput(confirmNewPasswordInput, confirmNewPasswordIcon);

    // Event listeners for password visibility toggling
    currentPasswordIcon.addEventListener('click', function () {
        togglePasswordVisibility(currentPasswordInput, currentPasswordIcon);
    });

    newPasswordIcon.addEventListener('click', function () {
        togglePasswordVisibility(newPasswordInput, newPasswordIcon);
    });

    confirmNewPasswordIcon.addEventListener('click', function () {
        togglePasswordVisibility(confirmNewPasswordInput, confirmNewPasswordIcon);
    });

    // Initial check for visibility icons on load
    handleInput(currentPasswordInput, currentPasswordIcon);
    handleInput(newPasswordInput, newPasswordIcon);
    handleInput(confirmNewPasswordInput, confirmNewPasswordIcon);

    // Function to cancel changes
    function cancelChanges() {
    console.log('Cancel button clicked');
    // Implement cancel logic here if needed
    alert('Changes canceled!');
}

function saveChanges() {
    console.log('Save button clicked');
    // Implement save changes logic here
    alert('Changes saved!');
}

    // Assign click event handlers to the buttons
    document.getElementById('cancel-button').addEventListener('click', cancelChanges);
    document.getElementById('save-button').addEventListener('click', saveChanges);
});
    </script>
</body>
</html>
