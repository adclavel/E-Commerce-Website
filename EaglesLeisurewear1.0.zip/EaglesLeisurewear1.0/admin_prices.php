<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Metadata for character set and viewport -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Title of the document -->
    <title>Admin Prices - Eagle's Leisurewear Admin Portal</title>

    <!-- External stylesheets for Font Awesome icons and Roboto font -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300;400;700&display=swap">

    <!-- Internal styles for the document -->
    <style>
        /* Reset default margin and padding for the body */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif; /* Use Arial or sans-serif as fallback font */
        }

        /* Header styles */
        header {
            background: linear-gradient(45deg, #292929, #1a1a1a); /* Gradient background */
            color: #fff;
            padding: 5px;
            border-bottom: 7px solid #FCB900;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            display: flex;
            align-items: center;
        }

        /* Header logo styles */
        .header-logo {
            height: auto;
            width: 90px;
            margin-right: 15px;
        }

        /* Title styles */
        .title {
            font-size: 24px; /* Font size */
            font-weight: bold; /* Bold font weight */
            color: #FCB900; /* Gold color for the title */
            margin-left: 15px; /* Left margin for spacing */
            font-family: 'Roboto Condensed', sans-serif; /* Use Roboto Condensed font */
        }

        /* Navigation categories container styles */
        .nav-categories {
            background: linear-gradient(45deg, #696969, #1a1a1a); /* Gradient background */
            display: flex;
            flex-direction: column; /* Align categories vertically */
            padding: 10px 0;
            position: absolute;
            left: 0;
            top: 100px; /* Adjust top value as needed */
            width: 180px; /* Set a fixed width for the left side */
            border-right: 4px solid #FCB900; /* Add a right border */
            height: calc(100vh - 120px); /* Set the height to fill the remaining viewport height */
        }

        /* Navigation category links styles */
        .nav-categories a {
            text-decoration: none;
            color: #fff;
            font-size: 20px;
            margin: 10px 20px;
            position: relative;
            transition: color 0.3s;
        }

        /* Navigation category link hover styles */
        .nav-categories a:hover {
            color: yellow;
        }

        /* Navigation category link underline styles */
        .nav-categories a::after {
            content: '';
            display: block;
            width: 0;
            height: 2px;
            background-color: yellow;
            position: absolute;
            bottom: 0;
            left: 50%;
            transition: width 0.3s ease;
            transform: translateX(-50%);
        }

        /* Navigation category link hover underline styles */
        .nav-categories a:hover::after {
            width: 100%;
        }

        /* Sub-categories list styles */
        .sub-categories {
            display: none;
            list-style-type: none;
            padding-left: 20px;
        }

        /* Sub-category item styles */
        .nav-categories:hover .sub-categories {
            display: block;
        }

        /* Sub-category item hover styles */
        .sub-categories li {
            font-size: 14px;
            margin: 5px 0;
            color: #fff;
            cursor: pointer;
        }

        /* Sub-category item hover underline styles */
        .sub-categories li:hover {
            text-decoration: underline;
        }

        /* Footer styles */
        footer {
            background-color: #FFFFFF;
            color: #292929;
            padding: 0px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
            border-top: 1px solid #848484;
            font-size: 10px;
        }

      /* Main Content section */
.main-content {
    margin-left: 200px;
    padding: 20px;
    z-index: 2;
    background: white;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Updated styles for the <hr> element */
.main-content hr {
    border: none;
    height: 2px;
    background-color: #FCB900; /* Dark yellow color */
    margin: 20px 0; /* Adjusted margin for spacing */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3); /* Added box shadow */
}

        /* Outer frame styles */
        .outer-table-frame {
            border: 2px solid #ddd; /* Set border properties as needed */
            border-radius: 15px; /* Add border-radius for a rounded appearance */
            overflow: hidden;
            margin-bottom: 20px;
            width: 90%; /* Adjusted maximum width, including border width */
            margin: 0 auto; /* Centered the outer frame */
            background-color: #f0f0f0; /* Light grey background color */
            padding: 20px; /* Added padding */
        }

        /* Search, Sort by, and Period container styles */
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        /* Search bar styles */
        .search-bar {
            width: 20%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 25px; /* Added border-radius for a rounded look */
            position: relative;
            display: flex;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Added a subtle box shadow for depth */
            transition: background-color 0.3s; /* Added transition effect for background color */
        }

        /* Input styles */
        .search-bar input {
            flex: 1;
            width: 60%;
            border: none;
            outline: none;
            padding-left: 10px;
            font-size: 14px;
            background-color: #f5f5f5; /* Set background color to a light grey */
            border-radius: 20px; /* Added border-radius for a rounded look */
        }

        /* Adjust background color on hover for a stylish effect */
        .search-bar:hover {
            background-color: #e0e0e0; /* Set a slightly darker grey on hover */
        }

        /* Search icon styles */
        .search-bar i {
            margin-right: 10px;
        }
        /* Sort container styles */
.sort-container {
    display: flex;
    align-items: center;
    margin-right: 20px; /* Adjusted margin for spacing */
}

/* Label for sort options */
.sort-container label {
    margin-right: 10px;
    font-size: 14px;
    color: #333; /* Adjust text color as needed */
}

/* Sort options dropdown styles */
#sortOptions {
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px;
    cursor: pointer;
}

.sort-button {
    background-color: #FCB900; /* Yellow color */
    color: #fff;
    border: 1px solid #FCB900; /* Border color matching the background */
    padding: 8px 16px;
    border-radius: 5px;
    font-size: 14px;
    cursor: pointer;
    transition: background-color 0.3s;
}

/* Hover effect for the sort button */
.sort-button:hover {
    background-color: #2980b9; /* Darker blue on hover */
}

        /* New button for managing pending registrations */
        .manage-pending-button {
            text-align: center;
            margin-top: 10px; /* Adjusted margin-top to move it closer to the sort button */
            margin-bottom: 20px; /* Adjusted margin-bottom for spacing */
        }

        .pending-btn {
            background-color: #FCB900; /* Blue color */
            color: #000000;
            border: 1px solid #000000;
            padding: 4px 12px; /* Increased padding for a better look */
            cursor: pointer;
            border-radius: 5px;
            font-size: 12px; /* Slightly larger font size */
            font-weight: bold;
            transition: background-color 0.3s;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Added a subtle box shadow */
        }

        .pending-btn:hover {
            background-color: #B8860B; /* Darker blue on hover */
        }

        /* Table frame styles */
        .table-frame {
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
            background-color: #f9f9f9;
            margin-bottom: 20px;

            /* Adjust the size of the outer frame here */
            width: 100%; /* Set the width as a percentage or a specific value */
            margin: 5px; /* Adjust the margin as needed */
        }

        /* Main table container styles */
        .table-container {
            background: #f9f9f9;
            padding: 15px; /* Increase or decrease the padding as needed */
        }

        /* Table header styles */
        .table-header {
            display: flex;
            margin-left: 0; /* Adjust the left margin to 0 to move it to the left */
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #FCB900;
            padding-bottom: 10px;
            margin-bottom: 10px;
            font-weight: bold;
        }

        /* Table column styles */
        .table-column {
            flex: 1;
            text-align: left;
            padding: 6px;
            cursor: pointer; /* Add cursor pointer for clickable header */
        }

        /* Table row styles */
        .table-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
            margin-bottom: 10px;
            font-size: 8; /* Adjust the font size as needed */
        }

        /* Table cell styles */
        .table-cell {
            flex: 1;
            text-align: left;
            padding: 10px;
            font-size: 12px;
            font-weight: normal; /* Set font-weight to normal */
            color: #000000; /* Set text color to #E9ECEF */
        }

        /* Edit and Delete button styles */
        .edit-btn,
        .delete-btn,
        .view-btn {
            color: #A9A9A9;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        /* Edit button hover styles */
        .edit-btn:hover {
            background-color: #FFD700;
        }

        /* Delete button hover styles */
        .delete-btn:hover {
            background-color: #FF4500;
        }

        /* View button hover styles */
        .view-btn:hover {
            background-color: #3498db; /* Blue */
        }

        /* Pagination styles */
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
            margin-bottom: 20px; /* Adjusted margin-bottom for spacing */
        }

        /* Pagination button styles */
        .pagination-button {
            background-color: #D3D3D3; /* Change to your preferred color */
            color: #000000;
            border: 1px solid #A9A9A9; /* Adjust border color */
            padding: 8px 16px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            transition: background-color 0.3s;
            margin: 0 5px;
        }

        /* Pagination button hover styles */
        .pagination-button:hover {
            background-color: #A9A9A9; /* Change to your preferred hover color */
        }

        /* Highlight current page */
        .pagination-button.active {
            background-color: #A9A9A9; /* Change to your preferred active color */
            color: #000000;
        }

        @media screen and (max-width: 768px) {
            .nav-categories {
                display: none;
            }

            .main-content {
                margin-left: 10px;
            }

            .outer-table-frame,
            .table-frame,
            .table-container {
                width: 100%;
            }

            .search-bar {
                width: 100%;
            }

            .pagination {
                flex-direction: column;
            }
        }


     /* Overlay styles */
     .modal-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        z-index: 1;
    }

    /* Overlay styles */
    .modal-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        z-index: 1;
    }

    /* Modal styles */
    .editModal {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        z-index: 2;
    }

    .editModal-content {
        max-width: 400px;
        margin: 0 auto;
    }

    .close {
        position: absolute;
        top: 10px;
        right: 10px;
        cursor: pointer;
        font-size: 20px;
        color: #555;
    }

    .editModal h2 {
        color: #333;
    }

    .editModal label {
        display: block;
        margin-top: 10px;
        color: #555;
    }

    .editModal input {
        width: 100%;
        padding: 8px;
        margin-top: 5px;
        margin-bottom: 10px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    .editModal button {
        background-color: #4CAF50;
        color: #fff;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    .editModal button:hover {
        background-color: #45a049;
    }
    </style>
</head>

<body>
    <!-- Header section -->
    <header>
        <img src="public/external/EaglesLogo.png" class="header-logo"> 
        <h1 class="title">Eagle's Leisurewear Admin Portal </h1>
    </header>

    <!-- Navigation Categories section -->
    <div class="nav-categories">
        <a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
        <a href="admin_users.php"><i class="fas fa-user"></i> User Registration</a>
        <a href="admin_stocks.php"><i class="fas fa-box"></i> Stocks</a>
        <a href="admin_prices.php"><i class="fas fa-dollar-sign"></i> Prices</a>
        <a href="admin_payment_validation.php"><i class="fas fa-money-bill"></i> Payments > </a>
        <ul class="sub-categories">
            <li><a href="admin_payment_validation.php"><i class="fas fa-check-circle"></i> Validation</a></li>
           <a href="admin_payment_process.php"><i class="fas fa-cogs"></i> Process</a></li>
            <li><a href="admin_payment_delivered.php"><i class="fas fa-truck"></i> Delivered</a></li>
        </ul>
        <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
        <a href="log-in-page.php"><i class="fas fa-sign-out-alt"></i> Log Out</a>
    </div>

  <!-- Main content section -->
<div class="main-content">
    <h2>Price Management</h2>
    <hr>
    <!-- Outer frame for table -->
    <div class="outer-table-frame">
        <!-- Search, Sort by, and Period container -->
        <div class="action-bar">
            <!-- Search bar -->
            <div class="search-bar">
                <i class="fas fa-search"></i>
                <input type="text" placeholder="Search...">
            </div>
            <!-- Sort button and dropdown -->
            <div class="sort-container">
                <label for="sortOptions">Sort by:</label>
                <select id="sortOptions" onchange="sortTable()">
                    <option value="Default">Default</option>
                    <option value="Product">Product</option>
                    <option value="Size">Size</option>
                    <option value="Price">Price</option>
                    <option value="TotalSales">Total Sales</option>
                    <!-- Add more options as needed -->
                </select>
            </div>
        </div>

        <div class="table-frame">
            <!-- Table header -->
            <div class="table-header">
                <div class="table-column">Product</div>
                <div class="table-column">Size</div>
                <div class="table-column">Price</div>
                <div class="table-column">Total Sales</div>
                <div class="table-column">Actions</div>
            </div>



          

    <!-- Footer section -->
    <footer>
        <p>&copy; 2024 Eagle's Leisurewear. All Rights Reserved.</p>
    </footer>
</div>
 <!-- Edit Product Modal -->
 <div class="modal-overlay" id="overlay"></div>
<div id="editModal" class="editModal">
    <div class="modal-content">
        <span class="close" onclick="closeEditModal()">&times;</span>
        <h2>Edit Product</h2>
        <form id="editForm">
            <label for="productName">Product Name:</label>
            <input type="text" id="productName" name="productName">

            <label for="productSize">Product Size:</label>
            <input type="text" id="productSize" name="productSize">

            <label for="productPrice">Product Price (PHP):</label>
           <div class="input-group">
    <input type="number" id="productPrice" name="productPrice" step="₱1.00" min="₱1.00" value="₱1.00" oninput="formatCurrency(this)">
</div>
            
            <label for="totalSales">Total Sales:</label>
            <input type="text" id="totalSales" name="totalSales">

            <button type="button" onclick="updateProduct()">Save Changes</button>
        </form>
    </div>
</div>
            </div>
        </div>

        <!-- Footer section -->
        <footer>
            <p>&copy; 2024 Eagle's Leisurewear. All Rights Reserved.</p>
        </footer>

                    </tbody>
                </table>
            </div>
        </div>

        <script>
            function sortTable() {
                var table = document.querySelector('.table-container');
                var sortOption = document.getElementById('sortOptions').value;
                var rows = Array.from(table.querySelectorAll('.table-row'));
        
                if (sortOption === 'Default') {
                    // If 'Default' is selected, restore the original order
                    rows.sort(function (a, b) {
                        return a.dataset.index - b.dataset.index;
                    });
                } else {
                    // Sort based on the selected option
                    rows.sort(function (a, b) {
                        var textA = a.querySelector('.table-cell[data-sort="' + sortOption + '"]').textContent.trim();
                        var textB = b.querySelector('.table-cell[data-sort="' + sortOption + '"]').textContent.trim();
        
                        // Convert values to numbers for 'Price' and 'Total Sales'
                        var valueA = sortOption === 'Price' ? parseFloat(textA.replace(/[^\d.-]/g, '')) : textA;
                        var valueB = sortOption === 'Price' ? parseFloat(textB.replace(/[^\d.-]/g, '')) : textB;
        
                        // For 'Total Sales', compare as numbers and sort from highest to lowest
                        if (sortOption === 'TotalSales') {
                            valueA = parseFloat(a.querySelector('.table-cell[data-sort="TotalSales"]').textContent.replace(/[^\d.-]/g, ''));
                            valueB = parseFloat(b.querySelector('.table-cell[data-sort="TotalSales"]').textContent.replace(/[^\d.-]/g, ''));
                            return valueB - valueA;
                        }
        
                        // Perform comparison for other options
                        if (valueA < valueB) return 1;
                        if (valueA > valueB) return -1;
                        return 0;
                    });
                }
        
                // Clear the table
                table.innerHTML = '';
        
                // Append sorted or original rows back to the table
                rows.forEach(function (row) {
                    table.appendChild(row);
                });
            }
        
            // Add a data-index attribute to each row to store its original index
            document.querySelectorAll('.table-row').forEach(function (row, index) {
                row.dataset.index = index;
            });
             // Format the input as currency (00.00)
    function formatCurrency(input) {
        // Ensure a minimum value of 1.00
        if (input.value < 1.00) {
            input.value = 1.00;
        }

        // Format the value as 00.00
        input.value = parseFloat(input.value).toFixed(2);
    }

            function openEditModal(productId) {
        var modal = document.getElementById("editModal");
        modal.style.display = "block";
       // Format the input as currency (00.00)
    

        // Retrieve the product details based on the productId
        var productName = document.querySelector(`.table-row[data-product-id="${productId}"] .table-cell[data-sort="Product"]`).textContent;
        var productSize = document.querySelector(`.table-row[data-product-id="${productId}"] .table-cell[data-sort="Size"]`).textContent;
        var productPrice = document.querySelector(`.table-row[data-product-id="${productId}"] .table-cell[data-sort="Price"]`).textContent;
        var totalSales = document.querySelector(`.table-row[data-product-id="${productId}"] .table-cell[data-sort="TotalSales"]`).textContent;

        // Populate the form fields in the modal with the retrieved values
        document.getElementById('productName').value = productName;
        document.getElementById('productSize').value = productSize;
        document.getElementById('productPrice').value = productPrice;
        document.getElementById('totalSales').value = totalSales;

        // Store the productId in a data attribute in the modal
        modal.setAttribute('data-editing-product-id', productId);
    }

    function closeEditModal() {
        var modal = document.getElementById("editModal");
        modal.style.display = "none";
    }

    function updateProduct() {
        // Retrieve the updated values from the form
        var updatedProductName = document.getElementById('productName').value;
        var updatedProductSize = document.getElementById('productSize').value;
        var updatedProductPrice = document.getElementById('productPrice').value;
        var updatedTotalSales = document.getElementById('totalSales').value;

        // Retrieve the product ID from the modal
        var productId = document.getElementById("editModal").getAttribute('data-editing-product-id');
        
        // Update the table row with the new values
        var tableRow = document.querySelector(`.table-row[data-product-id="${productId}"]`);

        tableRow.querySelector('.table-cell[data-sort="Product"]').textContent = updatedProductName;
        tableRow.querySelector('.table-cell[data-sort="Size"]').textContent = updatedProductSize;
        tableRow.querySelector('.table-cell[data-sort="Price"]').textContent = updatedProductPrice;
        tableRow.querySelector('.table-cell[data-sort="TotalSales"]').textContent = updatedTotalSales;

        // Close the modal
        closeEditModal();
    }
         </script>
    </body>

    </html>