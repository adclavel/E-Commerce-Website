<!DOCTYPE html>
<html lang="english">
  <head>
    <title>Terms-of-Service - exported project</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="./terms-of-service.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/e0abea836f.js" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="home-page-header">
      <img
        class="header-logo"
        src="public/external/thefraternalorderofeagles13712-cfl-200h.png"
        alt="TheFraternalOrderofEagles13712"
      />
      <span class="website-name">
        <span>Eagle’s Leisurewear</span>
      </span>
      <div class="home-page-iconuser">
          <a href="my-account.php"><img src="public/external/user3812-jwm2-200h.png" ></a>
      </div>
      <div class="home-page-icon-bag">
        <a href="add-to-cart-page.php"><img src="public/external/shoppingbagfull3812-ovvi-200h.png"/></a>
      </div>
      <div class="home-page-search-bar">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" id="searchInput" placeholder="Search" onkeydown="handleSearch(event)">
      </div>
      <div class="home-page-dashboard">
        <ul>
          <li> <a href="index.php">Home</a></li>
          <li> <a href="user-shop-page.php">Shop</a></li>
          <li> <a href="about-us-user-page.php">About Us</a></li>
          <li> <a href="contact-us-user-page.php">Contact Us</a></li>
        </ul>
      </div>
    </div>
    <div class="terms-of-service-container">
    <div class="terms-of-service-title">
        <span class="terms-of-service-text28">
            <span>Terms of Service</span>
        </span>
    </div>
    <span class="terms-of-service-text">
        <span>
            <span></span>
            <br />
            <span>
                Welcome to Eagles Leisurewear, the premier destination for modern fraternal apparel. These Terms of Service ("Terms") govern your access to and use of the Eagles Leisurewear website (the "Site") and any services provided through the Site. By accessing or using the Site, you agree to comply with and be bound by these Terms.
            </span>
            <br />
            <span></span>
            <br />

            <h3>1. Acceptance of Terms</h3>
            <span>
                By accessing or using the Site, you agree to be bound by these Terms and all applicable laws and regulations. If you do not agree with any of these Terms, you are prohibited from using or accessing the Site.
            </span>
            <span></span>
            <br/>
            <br>
            <h3>2. Use License</h3>
            <span>
                Permission is granted to temporarily download one copy of the materials (information or software) on Eagles Leisurewear's website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title.
                <br>
                Under this license you may not:
                <ul style="padding-left: 60px;"> <!-- Adjusted padding -->
                    <li>Modify or copy the materials;</li>
                    <li>Use the materials for any commercial purpose, or for any public display (commercial or non-commercial);</li>
                    <li>Attempt to decompile or reverse engineer any software contained on Eagles Leisurewear's website;</li>
                    <li>Remove any copyright or other proprietary notations from the materials; or</li>
                    <li>Transfer the materials to another person or "mirror" the materials on any other server.</li>
                </ul>
                <br>
                This license shall automatically terminate if you violate any of these restrictions and may be terminated by Eagles Leisurewear at any time. Upon terminating your viewing of these materials or upon the termination of this license, you must destroy any downloaded materials in your possession whether in electronic or printed format.
            </span>
            <br />
            <span></span>
            <br />
            
            <h3>3. User Content</h3>
            <span>
                By posting, storing, or transmitting any content on or to the Site, you represent and warrant that you have all necessary rights to distribute such content to Eagles Leisurewear. Eagles Leisurewear may, in its sole discretion, remove any content that violates these Terms or is otherwise objectionable.
            </span>
            <br />
            <span></span>
            <br />

            <h3>4. Intellectual Property Rights</h3>
            <span>
                All content on the Site, including but not limited to text, graphics, logos, button icons, images, audio clips, digital downloads, data compilations, and software, is the property of Eagles Leisurewear or its content suppliers and protected by international copyright laws.
            </span>
            <br />
            <span></span>
            <br />

            <h3>5. Limitations</h3>
            <span>
                In no event shall Eagles Leisurewear or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on Eagles Leisurewear's website.
            </span>
            <br />
            <span></span>
            <br />

            <h3>6. Governing Law</h3>
            <span>
                These Terms shall be governed by and construed in accordance with the laws of [Your Jurisdiction], without regard to its conflict of law provisions.
                <br>
                By accessing or using the Site, you agree to submit to the personal and exclusive jurisdiction of the courts located within [Your Jurisdiction] for the resolution of any disputes arising under these Terms.
            </span>
            <br />
            <span></span>
            <br />

            <h3>7. Changes to Terms</h3>
            <span>
                Eagles Leisurewear reserves the right to revise these Terms at any time without notice. By using this Site, you are agreeing to be bound by the then-current version of these Terms.
            </span>
            <br />
            <span></span>
            <br />

            <span>
                By accessing or using the Eagles Leisurewear website, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use the Site.
            </span>
            <br />
            <span>
                If you have any questions or concerns about these Terms, please contact us at [Contact Email].
            </span>
            <br />
            <br>
            <span>
                Last updated: March 17, 2024,
            </span>
            <br />
            <span></span>
            <br />
            <span></span>
        </span>
    </span>
</div>

      </div>
      <div class="home-page-temp-footer">
        <div class="website-name-footer">
          <img class="footer-logo" src="public/external/thefraternalorderofeagles14032-c39-200h.png"/>
          <h1>Eagle’s Leisurewear</h1>
          <h4>At Eagle's Leisure, we're more than just a website; <br> we're a virtual for fraternity enthusiasts and like-minded <br> individuals. Dive into 
              a world where camaraderie, fun, <br> and the spirit of brotherhood together.</h4>
        </div>
        <div class="website-contact-info">
          <div class="info-list">
            <a href="contact-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>Contact Us</h3></a>
            <a href="about-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>About us</h3></a>
            <a href="user-shop-page.php" style="color: rgb(255, 255, 255);"><h3>Shop</h3></a>
            <a href="privacy-policy.php" style="color: rgb(255, 255, 255);"><h3>Privacy Policy</h3></a>
            <a href="terms-of-service.php" style="color: rgb(255, 255, 255);"><h3>Terms and Conditions</h3></a>
          </div>
        </div>
        <div class="links">
          <h1>Links</h1>
          <a href="https://www.facebook.com/eaglesleisurewear?mibextid=LQQJ4d" target="_blank"><img src="public/external/facebook4072-vhe-200h.png"/></a>
        </div>
        <div class="website-location">
          <h1>Our Location</h1>
            <img class="location-icon"src="public/external/location4112-y82-200h.png"/>
            <div class="address">
            <a href="https://maps.app.goo.gl/9u7YZqT3BBGyxHJv5" style="color: white;"><h4>1325 Malakas Street Pasig City</h4></a>
            <h4>National Capital Region</h4>
          </div>
        </div>
      </div>
      <script>
        function handleSearch(event) {
            if (event.key === 'Enter') {
                searchProducts();
            }
        }
  
        function searchProducts() {
            var searchInput = document.getElementById('searchInput').value.toLowerCase();
  
            // Redirect to the results page with the search query as a parameter
            window.location.href = 'user-shop-page.php?query=' + encodeURIComponent(searchInput);
        }
    </script>
  </body>
</html>
