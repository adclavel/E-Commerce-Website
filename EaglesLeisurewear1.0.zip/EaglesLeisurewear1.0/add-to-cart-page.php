<?php 
  include "db_connect.php";
?>

<!DOCTYPE html>
<html lang="english">
  <head>
    <title>Add-to-Cart-Page - exported project</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="./add-to-cart-page.css" rel="stylesheet" />
    <script src="https://kit.fontawesome.com/e0abea836f.js" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="home-page-header">
      <img
        class="header-logo"
        src="public/external/thefraternalorderofeagles13712-cfl-200h.png"
        alt="TheFraternalOrderofEagles13712"
      />
      <span class="website-name">
        <span>Eagle’s Leisurewear</span>
      </span>
      <div class="home-page-iconuser">
          <a href="my-account.php"><img src="public/external/user3812-jwm2-200h.png" ></a>
      </div>
      <div class="home-page-icon-bag">
        <a href="add-to-cart-page.php"><img src="public/external/shoppingbagfull3812-ovvi-200h.png"/></a>
      </div>
      <div class="home-page-search-bar">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" placeholder="Search">
      </div>
      <div class="home-page-dashboard">
        <ul>
          <li> <a href="index.php">Home</a></li>
          <li> <a href="user-shop-page.php">Shop</a></li>
          <li> <a href="about-us-user-page.php">About Us</a></li>
          <li> <a href="contact-us-user-page.php">Contact Us</a></li>
        </ul>
      </div>
    </div>
      <div class="add-to-cart-page-container">
        <div class="add-to-cart-page-body">
          <div class="tab">
            <span class="add-to-cart-page-text29">All Products</span>
            <span class="greater-than"><i class="fa-solid fa-greater-than"></i></span>
            <span>Your Shopping Cart</span>
          </div>
          <div class="your-shopping-cart-total-items">
            <span class="add-to-cart-page-name-text">
              <span>Your Shopping Cart</span>
            </span>
            <br>
            <span class="add-to-cart-page-total-items">
              <span class="total-items" id="total-items">Total Items (3)</span>
            </span>
          </div>
          <div class="quantity-total">
            <span class="add-to-cart-page-text15"><span>Quantity</span></span>
            <span class="add-to-cart-page-text17"><span>Total</span></span>
          </div>
          <div class="add-to-cart-products" id="add-to-cart-products">
          <?php
          session_start();

          $user_id = $_SESSION['id'];

          $query = "SELECT * FROM cart_products WHERE user_id = $user_id";
          $result = mysqli_query($conn, $query);

                  $total_subtotal = 0;

          if (mysqli_num_rows($result) > 0) {

              while($product_data = $result->fetch_assoc()) {
                $product_total_price = $product_data["price"] * $product_data["quantity"];

                $total_subtotal += $product_total_price;
                  $imageData = base64_encode($product_data["image"]);
                  echo "<div class='add-to-cart-page-product'>";
                      echo "<div class='product-image'>";
                          echo "<img src='data:image/png;base64," . $product_data["image"] ."'>";
                      echo "</div>";
                      echo "<div class='add-to-cart-page-product-details'>";
                          echo "<span class='product-name'>";
                              echo "<span>" . $product_data["ProductName"] . "</span>";
                          echo "</span>";
                          echo "<br>";
                          echo "<span class='product-size'>";
                              echo "<span>" . $product_data["size"] . "</span>";
                          echo "</span>";
                          echo "<br>";
                          echo "<span class='product-price'>";
                          echo "<span>₱" . $product_data["price"] . "</span>";
                          echo "</span>";
                      echo "</div>";
                      echo "<div class='quantity-total-details'>";
                          echo "<span class='product-quantity'>";
                              echo "<span class='minus' onclick='decreaseQuantity(" . $product_data["id"] . ")'><i class='fa-solid fa-minus' style='color: #000000;'></i></span>";
                              echo "<a class='num3' id='quantity_" . $product_data["id"] . "'>" . $product_data["quantity"] . "</a>";
                              echo "<span class='plus' onclick='increaseQuantity(" . $product_data["id"] . ")'><i class='fa-solid fa-plus' style='color: #000000;'></i></span>";
                          echo "</span>";
                          echo "<span class='product-total-price'>";
                              echo "<span>₱" . $product_data["price"] * $product_data["quantity"] . "</span>";
                          echo "</span>";
                          echo "<span class='remove' onclick='removeProduct(" . $product_data["id"] . ")'><i class='fa-solid fa-xmark' style='color: #000000;'></i></span>";
                      echo "</div>";
                  echo "</div>";
              }
          } else {
            echo "<script>document.getElementById('cart-is-empty').style.display = 'block';</script>";
          }

          ?>
          </div>
          <div class="bot-container" id="bot-container">
            <div class="check-out-continue-shopping-buttons">
              <span class="add-to-cart-page-text44">
                <button id="checkout">Check-out</button>
              </span>
              <span class="add-to-cart-page-text38">
                <button id="continueshopping">Continue Shopping</button>
              </span>
            </div>
            <div class="total">
              <span class="add-to-cart-page-text40">
                <span class="subtotal-text">Subtotal:</span>
                <span class="subtotal" id="subtotal">₱<?php echo number_format($total_subtotal, 2); ?></span>
              </span>
            </div>
            </div>
            <div class="cart-is-empty" id="cart-is-empty" style="display: none;">
              <div class="cart-is-empty-text">it appears your shopping cart is currently empty!</div>
              <button class="cart-is-empty-button" id="cart-is-empty-button" onclick="continueShopping()">Continue Shopping</button>
            </div>
        </div>
      </div>
      <div class="home-page-temp-footer">
        <div class="website-name-footer">
          <img class="footer-logo" src="public/external/thefraternalorderofeagles14032-c39-200h.png"/>
          <h1>Eagle’s Leisurewear</h1>
          <h4>At Eagle's Leisure, we're more than just a website; <br> we're a virtual for fraternity enthusiasts and like-minded <br> individuals. Dive into 
              a world where camaraderie, fun, <br> and the spirit of brotherhood together.</h4>
        </div>
        <div class="website-contact-info">
          <div class="info-list">
            <a href="contact-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>Contact Us</h3></a>
            <a href="about-us-user-page.php" style="color: rgb(255, 255, 255);"><h3>About us</h3></a>
            <a href="user-shop-page.php" style="color: rgb(255, 255, 255);"><h3>Shop</h3></a>
            <a href="privacy-policy.php" style="color: rgb(255, 255, 255);"><h3>Privacy Policy</h3></a>
            <a href="terms-of-service.php" style="color: rgb(255, 255, 255);"><h3>Terms and Conditions</h3></a>
          </div>
        </div>
        <div class="links">
          <h1>Links</h1>
          <a href="https://www.facebook.com/eaglesleisurewear?mibextid=LQQJ4d" target="_blank"><img src="public/external/facebook4072-vhe-200h.png"/></a>
        </div>
        <div class="website-location">
          <h1>Our Location</h1>
            <img class="location-icon"src="public/external/location4112-y82-200h.png"/>
            <div class="address">
            <a href="https://maps.app.goo.gl/9u7YZqT3BBGyxHJv5" style="color: white;"><h4>1325 Malakas Street Pasig City</h4></a>
            <h4>National Capital Region</h4>
          </div>
        </div>
      </div>
      <script>
        // Function to count the number of displayed products and update total items
        function updateTotalItems() {
            var totalItemsElement = document.getElementById('total-items');
            var totalItems = document.querySelectorAll('.add-to-cart-page-product').length;
            totalItemsElement.innerText = "Total Items (" + totalItems + ")";
        }

        // Call the function when the page loads
        document.addEventListener("DOMContentLoaded", function() {
            updateTotalItems();
        });
    </script>
      <script>
    // Function to increase product quantity
    function increaseQuantity(productId) {
        var quantityElement = document.getElementById("quantity_" + productId);
        var currentQuantity = parseInt(quantityElement.innerText);
        var newQuantity = currentQuantity + 1;
        quantityElement.innerText = newQuantity;

        // Send AJAX request to update the quantity in the database
        updateQuantity(productId, newQuantity, quantityElement);
        window.location.href = 'add-to-cart-page.php';
    }

    // Function to decrease product quantity
    function decreaseQuantity(productId) {
        var quantityElement = document.getElementById("quantity_" + productId);
        var currentQuantity = parseInt(quantityElement.innerText);
        if (currentQuantity > 1) {
            var newQuantity = currentQuantity - 1;
            quantityElement.innerText = newQuantity;

            // Send AJAX request to update the quantity in the database
            updateQuantity(productId, newQuantity, quantityElement);
            window.location.href = 'add-to-cart-page.php';
        }
    }

    // Function to send AJAX request to update quantity in the database
    function updateQuantity(productId, newQuantity, quantityElement) {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "updateQuantity.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Handle the response from the server
                console.log(xhr.responseText);
                // If the update was successful, update the displayed quantity
                if (xhr.responseText.trim() === "Quantity updated successfully") {
                    quantityElement.innerText = newQuantity;
                }
            }
        };
        xhr.send("product_id=" + productId + "&new_quantity=" + newQuantity);
    }
</script>
      <script>
    function removeProduct(productId) {
        if (confirm("Are you sure you want to remove this product?")) {
            // Send an AJAX request to deleteProduct.php with the product ID
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "deleteProduct.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    // Handle the response from the server
                    if (xhr.responseText.trim() === "Product deleted successfully") {
                        // Reload the page after successful deletion
                        location.reload();
                    } else {
                        // Handle the error message if deletion fails
                        alert(xhr.responseText);
                    }
                }
            };
            xhr.send("product_id=" + productId); // Send the product ID as a parameter
        }
    }
</script>
      <script>
    document.addEventListener("DOMContentLoaded", function() {
        var productContainer = document.getElementById("add-to-cart-products");
        var productElements = document.querySelectorAll(".add-to-cart-page-products");
        
        productElements.forEach(function(element) {
            productContainer.appendChild(element);
        });
    });
    </script>
    <script>
        const continueshopping = document.getElementById("continueshopping");
        const checkout = document.getElementById("checkout");

        continueshopping.addEventListener("click", () => {
            window.location.href = 'user-shop-page.php';
        });

        checkout.addEventListener("click", () => {
        // Get the subtotal value
        const subtotal = <?php echo $total_subtotal; ?>;
        // Redirect to the delivery page with the subtotal as a parameter
        window.location.href = 'delivery-payment-page.php?subtotal=' + subtotal;
    });
    </script>
    <script>
    // JavaScript function to show the empty cart message and button
    function showEmptyCartMessage() {
        var cartIsEmpty = <?php echo mysqli_num_rows($result) == 0 ? 'true' : 'false'; ?>;
        if (cartIsEmpty) {
            document.getElementById('cart-is-empty').style.display = 'block';
            document.getElementById('bot-container').style.display = 'none';
        }
    }

    // Call the function when the page loads
    window.onload = function() {
        showEmptyCartMessage();
    };

    // Function to continue shopping
    function continueShopping() {
        window.location.href = 'user-shop-page.php';
    }
</script>
  </body>
</html>
