<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Metadata for character set and viewport -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Title of the document -->
    <title>Delivered Orders</title>

    <!-- External stylesheets for Font Awesome icons and Roboto font -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300;400;700&display=swap">

    <!-- Internal styles for the document -->
    <style>
        /* Reset default margin and padding for the body */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif; /* Use Arial or sans-serif as fallback font */
        }

        /* Header styles */
        header {
            background: linear-gradient(45deg, #292929, #1a1a1a); /* Gradient background */
            color: #fff;
            padding: 5px;
            border-bottom: 7px solid #FCB900;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            display: flex;
            align-items: center;
        }

        /* Header logo styles */
        .header-logo {
            height: auto;
            width: 90px;
            margin-right: 15px;
        }

        /* Title styles */
        .title {
            font-size: 24px; /* Font size */
            font-weight: bold; /* Bold font weight */
            color: #FCB900; /* Gold color for the title */
            margin-left: 15px; /* Left margin for spacing */
            font-family: 'Roboto Condensed', sans-serif; /* Use Roboto Condensed font */
        }

        /* Navigation categories container styles */
        .nav-categories {
            background: linear-gradient(45deg, #696969, #1a1a1a); /* Gradient background */
            display: flex;
            flex-direction: column; /* Align categories vertically */
            padding: 10px 0;
            position: absolute;
            left: 0;
            top: 100px; /* Adjust top value as needed */
            width: 180px; /* Set a fixed width for the left side */
            border-right: 4px solid #FCB900; /* Add a right border */
            height: calc(100vh - 120px); /* Set the height to fill the remaining viewport height */
        }

        /* Navigation category links styles */
        .nav-categories a {
            text-decoration: none;
            color: #fff;
            font-size: 20px;
            margin: 10px 20px;
            position: relative;
            transition: color 0.3s;
        }

        /* Navigation category link hover styles */
        .nav-categories a:hover {
            color: yellow;
        }

        /* Navigation category link underline styles */
        .nav-categories a::after {
            content: '';
            display: block;
            width: 0;
            height: 2px;
            background-color: yellow;
            position: absolute;
            bottom: 0;
            left: 50%;
            transition: width 0.3s ease;
            transform: translateX(-50%);
        }

        /* Navigation category link hover underline styles */
        .nav-categories a:hover::after {
            width: 100%;
        }

        /* Sub-categories list styles */
        .sub-categories {
            display: none;
            list-style-type: none;
            padding-left: 20px;
        }

        /* Sub-category item styles */
        .nav-categories:hover .sub-categories {
            display: block;
        }

        /* Sub-category item hover styles */
        .sub-categories li {
            font-size: 14px;
            margin: 5px 0;
            color: #fff;
            cursor: pointer;
        }

        /* Sub-category item hover underline styles */
        .sub-categories li:hover {
            text-decoration: underline;
        }

        /* Footer styles */
        footer {
            background-color: #FFFFFF;
            color: #292929;
            padding: 0px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
            border-top: 1px solid #848484;
            font-size: 10px;
        }

      /* Main Content section */
.main-content {
    margin-left: 200px;
    padding: 20px;
    z-index: 2;
    background: white;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Updated styles for the <hr> element */
.main-content hr {
    border: none;
    height: 2px;
    background-color: #FCB900; /* Dark yellow color */
    margin: 20px 0; /* Adjusted margin for spacing */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3); /* Added box shadow */
}

        /* Outer frame styles */
        .outer-table-frame {
            border: 2px solid #ddd; /* Set border properties as needed */
            border-radius: 15px; /* Add border-radius for a rounded appearance */
            overflow: hidden;
            margin-bottom: 20px;
            width: 90%; /* Adjusted maximum width, including border width */
            margin: 0 auto; /* Centered the outer frame */
            background-color: #f0f0f0; /* Light grey background color */
            padding: 20px; /* Added padding */
        }

        /* Search, Sort by, and Period container styles */
        .action-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        /* Search bar styles */
        .search-bar {
            width: 30%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 25px; /* Added border-radius for a rounded look */
            position: relative;
            display: flex;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Added a subtle box shadow for depth */
            transition: background-color 0.3s; /* Added transition effect for background color */
        }

        /* Input styles */
        .search-bar input {
            flex: 1;
            width: 100%;
            border: none;
            outline: none;
            padding-left: 10px;
            font-size: 14px;
            background-color: #f5f5f5; /* Set background color to a light grey */
            border-radius: 20px; /* Added border-radius for a rounded look */
        }

        /* Adjust background color on hover for a stylish effect */
        .search-bar:hover {
            background-color: #e0e0e0; /* Set a slightly darker grey on hover */
        }

        /* Search icon styles */
        .search-bar i {
            margin-right: 10px;
        }
/* Sort options dropdown styles */
#sortOptions {
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px;
    cursor: pointer;
}

.sort-button {
    background-color: #FCB900; /* Yellow color */
    color: #fff;
    border: 1px solid #FCB900; /* Border color matching the background */
    padding: 8px 16px;
    border-radius: 5px;
    font-size: 14px;
    cursor: pointer;
    transition: background-color 0.3s;
}

/* Hover effect for the sort button */
.sort-button:hover {
    background-color: #2980b9; /* Darker blue on hover */
}


        /* Table frame styles */
        .table-frame {
            border: 1px solid #ddd;
            border-radius: 10px;
            overflow: hidden;
            background-color: #f9f9f9;
            margin-bottom: 20px;

            /* Adjust the size of the outer frame here */
            width: 100%; /* Set the width as a percentage or a specific value */
            margin: 5px; /* Adjust the margin as needed */
        }

        /* Main table container styles */
        .table-container {
            background: #f9f9f9;
            padding: 15px; /* Increase or decrease the padding as needed */
        }

        /* Table header styles */
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #FCB900;
            padding-bottom: 10px;
            margin-bottom: 10px;
            font-weight: bold; /* Added font-weight: bold; */
        }

        /* Table column styles */
        .table-column {
            flex: 1;
            text-align: center;
            padding: 10px;
        }

       /* Table row styles */
.table-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
    padding: 8px 0; /* Adjusted padding */
    margin-bottom: 8px; /* Adjusted margin */
}

/* Table cell styles */
.table-cell {
    flex: 1;
    text-align: center;
    padding: 8px;
    font-size: 12px; /* Adjusted font size */
}
        /* Edit and Delete button styles */
        .edit-btn,
        .delete-btn,
        .view-btn {
            color: #A9A9A9;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        /* Edit button hover styles */
        .edit-btn:hover {
            background-color: #FFD700;
        }

        /* Delete button hover styles */
        .delete-btn:hover {
            background-color: #FF4500;
        }

        /* View button hover styles */
        .view-btn:hover {
            background-color: #3498db; /* Blue */
        }

        /* Pagination styles */
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
            margin-bottom: 20px; /* Adjusted margin-bottom for spacing */
        }

        /* Pagination button styles */
        .pagination-button {
            background-color: #D3D3D3; /* Change to your preferred color */
            color: #000000;
            border: 1px solid #A9A9A9; /* Adjust border color */
            padding: 8px 16px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            transition: background-color 0.3s;
            margin: 0 5px;
        }

        /* Pagination button hover styles */
        .pagination-button:hover {
            background-color: #A9A9A9; /* Change to your preferred hover color */
        }

        /* Highlight current page */
        .pagination-button.active {
            background-color: #A9A9A9; /* Change to your preferred active color */
            color: #000000;
        }
    /* Updated status cell styles */
.status-validating {
    color: #191970; /* Blue color for Validating status */
    font-weight: bold;
}

.status-invalid {
    color: #FF0000; /* Red color for Invalid status */
    font-weight: bold;
}
/* Modal styles */
.modal {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 3;
    width: 300px;
    max-width: 80%; /* Set a maximum width for responsiveness */
    max-height: 80vh; /* Set a maximum height for responsiveness */
    background-color: #D3D3D3;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    box-sizing: border-box;
}

/* Close button styles */
.close-btn {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 16px;
    cursor: pointer;
    color: #555;
}

/* Modal content styles */
.modal-content {
    margin-top: 20px;
}

/* Input styles */
.modal-content input {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-sizing: border-box;
}

/* Button styles */
.modal-content button {
    background-color: #3498db;
    color: #fff;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}
/* Add this to your existing styles */
/* Modal content styles */
.modal-content select {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-sizing: border-box;
}

/* Button hover styles */
.modal-content button:hover {
    background-color: #2980b9;
}
        /* Media query for smaller screens */
        @media (max-width: 768px) {
            .nav-categories {
                display: none; /* Hide navigation categories on smaller screens */
            }

            .main-content {
                margin-left: 0; /* Adjust margin for main content on smaller screens */
            }
        }
    </style>
</head>

<body>
    <!-- Header section -->
    <header>
        <img src="public/external/EaglesLogo.png" class="header-logo">
        <h1 class="title">Eagle's Leisurewear Admin Portal </h1>
    </header>

    <!-- Navigation Categories section -->
    <div class="nav-categories">
        <a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
        <a href="admin_users.php"><i class="fas fa-user"></i> User Registration</a>
        <a href="admin_stocks.php"><i class="fas fa-box"></i> Stocks</a>
        <a href="admin_prices.php"><i class="fas fa-dollar-sign"></i> Prices</a>
        <a href="admin_payment_validation.php"><i class="fas fa-money-bill"></i> Payments > </a>
        <ul class="sub-categories">
            <li><a href="admin_payment_validation.php"><i class="fas fa-check-circle"></i> Validation</a></li>
            <li><a href="admin_payment_process.php"><i class="fas fa-cogs"></i> Process</a></li>
            <li><a href="admin_payment_delivered.php"><i class="fas fa-truck"></i> Delivered</a></li>
        </ul>
        <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
        <a href="log-in-page.php"><i class="fas fa-sign-out-alt"></i> Log Out</a>
    </div>

        <!-- Main Content section -->
        <div class="main-content">
            <h2>Order Validation </h2>
                <hr>
            <!-- Outer table frame with adjusted size -->
            <div class="outer-table-frame">
                <!-- Action bar with search, sort by, and period -->
                <div class="action-bar">
                    <!-- Search bar -->
                    <div class="search-bar">
                        <i class="fas fa-search"></i>
                        <!-- Add oninput attribute to trigger searchTable function on input change -->
                        <input type="text" id="searchInput" placeholder="Search" oninput="searchTable()">
                    </div>
                    <!-- Sort by buttons -->
                 <!-- Sort button and dropdown -->
                 <div class="sort-container">
                    <label for="sortOptions">Sort by:</label>
                    <select id="sortOptions" onchange="sortTable()">
                        <option value="Default">Default</option>
                        <option value="Customer">Customer</option>
                        <option value="Product">Product</option>
                        <option value="Price">Price</option>
                        <option value="Payment Receipt">Payment Receipt</option>
                        <!-- Updated option for Validating -->
                        <option value="Validating">Validating</option>
                        <!-- Updated option for Invalid -->
                        <option value="Invalid">Invalid</option>
                        <!-- Add more options as needed -->
                    </select>
                </div>
                </div>
            <!-- Table frame with adjusted size -->
            <div class="table-frame">
                <!-- Table header -->
                <div class="table-header">
                    <div class="table-column">Customer</div>
                    <div class="table-column">Product</div>
                    <div class="table-column">Price</div>
                    <div class="table-column">Payment Receipt</div>
                    <div class="table-column">Status</div>
                    <div class="table-column">Actions</div>
                </div>
              <!-- Table container with added background color -->
<div class="table-container">
<!-- Updated sample table row 1 -->
<div class="table-row">
    <div class="table-cell customer" data-sort="Customer">Steve Johnson</div>
    <div class="table-cell product" data-sort="Product">Logo T-Shirt</div>
    <div class="table-cell price" data-sort="Price">25.00</div>
    <div class="table-cell payment-receipt" data-sort="Payment Receipt">Payment #12345</div>
    <!-- Updated status cell for Validating -->
    <div class="table-cell status-validating" data-sort="Status">Validating</div>
    <div class="table-cell">
        <button class="edit-btn" onclick="editProduct(1)"><i class="fas fa-edit"></i></button>
        <button class="delete-btn" onclick="deleteProduct(1)"><i class="fas fa-trash-alt"></i></button>
        <button class="view-btn" onclick="viewProduct(1)"><i class="fas fa-eye"></i></button>
    </div>
</div>

<!-- Updated sample table row 2 -->
<div class="table-row">
    <div class="table-cell customer" data-sort="Customer">Bob Smith</div>
    <div class="table-cell product" data-sort="Product">Sweatpants</div>
    <div class="table-cell price" data-sort="Price">35.00</div>
    <div class="table-cell payment-receipt" data-sort="Payment Receipt">Payment #67890</div>
    <!-- Updated status cell for Invalid -->
    <div class="table-cell status-invalid" data-sort="Status">Invalid</div>
    <div class="table-cell">
        <button class="edit-btn" onclick="editProduct(2)"><i class="fas fa-edit"></i></button>
        <button class="delete-btn" onclick="deleteProduct(2)"><i class="fas fa-trash-alt"></i></button>
        <button class="view-btn" onclick="viewProduct(2)"><i class="fas fa-eye"></i></button>
    </div>
</div>
    <div class="table-row">
        <div class="table-cell customer" data-sort="Customer">Aron Johnson</div>
        <div class="table-cell product" data-sort="Product">Cap</div>
        <div class="table-cell price" data-sort="Price">11.00</div>
        <div class="table-cell payment-receipt" data-sort="Payment Receipt">Payment #12345</div>
        <!-- Updated status cell for Validating -->
        <div class="table-cell status-validating" data-sort="Status">Validating</div>
        <div class="table-cell">
            <button class="edit-btn" onclick="editProduct(1)"><i class="fas fa-edit"></i></button>
            <button class="delete-btn" onclick="deleteProduct(1)"><i class="fas fa-trash-alt"></i></button>
            <button class="view-btn" onclick="viewProduct(1)"><i class="fas fa-eye"></i></button>
        </div>
    </div>
    
</div>    
                    <!-- Add more table rows as needed -->
                </div>
                <!-- Pagination with adjusted margin -->
                <div class="pagination" id="pagination">
                    <button class="pagination-button">&#60; Prev</button>
                    <button class="pagination-button">1</button>
                    <button class="pagination-button">2</button>
                    <button class="pagination-button">3</button>
                    <button class="pagination-button">Next &#62;</button>
                </div>
            </div>
        </div>
    </div>
<!-- Edit Modal -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <span class="close-btn" onclick="closeEditModal()">&times;</span>
        <h3>Edit Product</h3>
        <label for="editCustomer">Customer:</label>
        <input type="text" id="editCustomer" required>
        <label for="editProduct">Product:</label>
        <input type="text" id="editProduct" required>
        <label for="editPrice">Price:</label>
        <input type="text" id="editPrice" required>
        <label for="editPaymentReceipt">Payment Receipt:</label>
        <input type="text" id="editPaymentReceipt" required>
        <!-- Add the Status input -->
        <label for="editStatus">Status:</label>
        <select id="editStatus" required>
            <option value="Validating">Validating</option>
            <option value="Invalid">Invalid</option>
            <!-- Add more options as needed -->
        </select>
        <button onclick="saveChanges()">Save Changes</button>
    </div>
</div>
    <!-- Footer section -->
    <footer>
        &copy; 2024 Eagle's Leisurewear. All rights reserved.
    </footer>
    <script>
        function sortTable() {
            // Get the selected sorting option
            var sortBy = document.getElementById("sortOptions").value;
        
            // Get all the table rows
            var tableRows = document.querySelectorAll(".table-row");
        
            // Hide all rows initially
            tableRows.forEach(function(row) {
                row.style.display = "none";
            });
        
            // Handle the "Default" case by showing all rows
            if (sortBy === "Default") {
                tableRows.forEach(function(row) {
                    row.style.display = "";
                });
            } else if (sortBy === "Validating" || sortBy === "Invalid") {
                // Show only the rows with the selected status if Validating or Invalid is chosen
                var statusClass = "status-" + sortBy.toLowerCase();
                var filteredRows = document.querySelectorAll(".table-cell[data-sort='Status']." + statusClass);
        
                // Display only the filtered rows
                filteredRows.forEach(function(row) {
                    row.closest(".table-row").style.display = "";
                });
            } else {
                // For other sorting options, show all rows and perform sorting
                tableRows.forEach(function(row) {
                    row.style.display = "";
                });
        
                // Convert the NodeList to an array for easier manipulation
                var rowsArray = Array.from(tableRows);
        
                // Sort the rows based on the selected option
                rowsArray.sort(function (a, b) {
                    var valueA, valueB;
        
                    switch (sortBy) {
                        case "Customer":
                        case "Product":
                        case "Payment Receipt":
                            valueA = a.querySelector(".table-cell[data-sort='" + sortBy + "']").innerText.toLowerCase();
                            valueB = b.querySelector(".table-cell[data-sort='" + sortBy + "']").innerText.toLowerCase();
                            break;
                        case "Price":
                            valueA = parseFloat(a.querySelector(".table-cell[data-sort='" + sortBy + "']").innerText.replace("$", ""));
                            valueB = parseFloat(b.querySelector(".table-cell[data-sort='" + sortBy + "']").innerText.replace("$", ""));
                            break;
                        default:
                            break;
                    }
        
                    if (sortBy === "Price") {
                        return valueA - valueB;
                    } else {
                        return valueA.localeCompare(valueB);
                    }
                });
        
                // Clear the current table content
                var tableContainer = document.querySelector(".table-container");
                tableContainer.innerHTML = "";
        
                // Append the sorted rows back to the table
                rowsArray.forEach(function (row) {
                    tableContainer.appendChild(row);
                });
            }
        }
        function searchTable() {
    // Get the input value from the search bar
    var searchInput = document.getElementById("searchInput").value.toLowerCase();

    // Get all the table rows
    var tableRows = document.querySelectorAll(".table-row");

    // Iterate through each row and check if it matches the search input
    tableRows.forEach(function (row) {
        var customer = row.querySelector(".table-cell.customer").innerText.toLowerCase();
        var product = row.querySelector(".table-cell.product").innerText.toLowerCase();
        var price = row.querySelector(".table-cell.price").innerText.toLowerCase();
        var paymentReceipt = row.querySelector(".table-cell.payment-receipt").innerText.toLowerCase();
        var status = row.querySelector(".table-cell.status-validating, .table-cell.status-invalid").innerText.toLowerCase(); // Updated to include both status classes

        // If any of the row's content contains the search input, display the row; otherwise, hide it
        if (
            customer.includes(searchInput) ||
            product.includes(searchInput) ||
            price.includes(searchInput) ||
            paymentReceipt.includes(searchInput) ||
            status.includes(searchInput)
        ) {
            row.style.display = "";
        } else {
            row.style.display = "none";
        }
    });
}
document.addEventListener("DOMContentLoaded", function() {
    // Get the total number of rows
    var totalRows = document.querySelectorAll(".table-row").length;

    // Set the threshold for displaying pagination
    var paginationThreshold = 10;

    // Get the pagination element
    var pagination = document.getElementById("pagination");

    // Display pagination if the total rows exceed the threshold
    if (totalRows > paginationThreshold) {
        pagination.style.display = "flex";
    } else {
        pagination.style.display = "none";
    }
});
 // Function to open the edit modal
 document.addEventListener("DOMContentLoaded", function() {
        // Get all edit buttons
        var editButtons = document.querySelectorAll(".edit-btn");

        // Add click event listener to each edit button
        editButtons.forEach(function(button, index) {
            button.addEventListener("click", function() {
                openEditModal(index + 1); // Index is zero-based, so add 1 to match row number
            });
        });
    });

  // Updated function to open the edit modal
function openEditModal(rowNumber) {
    var modal = document.getElementById("editModal");
    modal.style.display = "block";
    
    // Set the editedRowIndex variable
    editedRowIndex = rowNumber;

    // Fetch data from the selected row and populate the edit form fields
    var customer = document.querySelector(".table-row:nth-child(" + rowNumber + ") .table-cell.customer").innerText;
    var product = document.querySelector(".table-row:nth-child(" + rowNumber + ") .table-cell.product").innerText;
    var price = document.querySelector(".table-row:nth-child(" + rowNumber + ") .table-cell.price").innerText;
    var paymentReceipt = document.querySelector(".table-row:nth-child(" + rowNumber + ") .table-cell.payment-receipt").innerText;
    var status = document.querySelector(".table-row:nth-child(" + rowNumber + ") .table-cell.status-validating, .table-row:nth-child(" + rowNumber + ") .table-cell.status-invalid").innerText;

    // Populate the edit form fields
    document.getElementById("editCustomer").value = customer;
    document.getElementById("editProduct").value = product;
    document.getElementById("editPrice").value = price;
    document.getElementById("editPaymentReceipt").value = paymentReceipt;
    document.getElementById("editStatus").value = status;
}
// Function to save changes and update the row
function saveChanges() {
    // Get the values from the modal input fields
    var editedCustomer = document.getElementById("editCustomer").value;
    var editedProduct = document.getElementById("editProduct").value;
    var editedPrice = document.getElementById("editPrice").value;
    var editedPaymentReceipt = document.getElementById("editPaymentReceipt").value;

    // Get the selected status from the modal
    var editedStatus = document.getElementById("editStatus").value;

    // Get the row number to update
    var rowNumber = editedRowIndex; // Assuming you have a variable to store the row index being edited

    // Update the row with the new values
    var editedRow = document.querySelector(".table-row:nth-child(" + rowNumber + ")");
    editedRow.querySelector(".table-cell.customer").innerText = editedCustomer;
    editedRow.querySelector(".table-cell.product").innerText = editedProduct;
    editedRow.querySelector(".table-cell.price").innerText = editedPrice;
    editedRow.querySelector(".table-cell.payment-receipt").innerText = editedPaymentReceipt;

    // Update the status cell text
    var statusCell = editedRow.querySelector(".table-cell.status-validating, .table-cell.status-invalid");
    statusCell.innerText = editedStatus;

    // Remove existing status class before adding the new one
    statusCell.classList.remove("status-validating", "status-invalid");

    // Add the new status class
    statusCell.classList.add("status-" + editedStatus.toLowerCase());

    // Close the modal after saving changes
    closeEditModal();
}
    // Variable to store the row index being edited
    var editedRowIndex;

    // Function to open the edit modal
    document.addEventListener("DOMContentLoaded", function() {
        // Get all edit buttons
        var editButtons = document.querySelectorAll(".edit-btn");

        // Add click event listener to each edit button
        editButtons.forEach(function(button, index) {
            button.addEventListener("click", function() {
                // Set the editedRowIndex variable
                editedRowIndex = index + 1; // Index is zero-based, so add 1 to match row number
                openEditModal(editedRowIndex);
            });
        });
    });

    // Function to close the edit modal
    function closeEditModal() {
        var modal = document.getElementById("editModal");
        modal.style.display = "none";
    }
    document.addEventListener("DOMContentLoaded", function() {
    // Get all delete buttons
    var deleteButtons = document.querySelectorAll(".delete-btn");

    // Add click event listener to each delete button
    deleteButtons.forEach(function(button, index) {
        button.addEventListener("click", function() {
            // Set the row index to delete
            var rowIndexToDelete = index + 1; // Index is zero-based, so add 1 to match row number
            
            // Call the deleteProduct function and pass the row index
            deleteProduct(rowIndexToDelete);
        });
    });
});

// Function to delete a product
function deleteProduct(rowNumber) {
    // Confirm deletion with the user
    var confirmation = confirm("Are you sure you want to delete this order?");

    if (confirmation) {
        // Get the table row to delete
        var rowToDelete = document.querySelector(".table-row:nth-child(" + rowNumber + ")");
        
        // Remove the row from the table
        rowToDelete.remove();
    }
}
    
    </script>
   
</body>

</html>