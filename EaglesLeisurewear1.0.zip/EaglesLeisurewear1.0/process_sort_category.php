<?php
// Include your database connection file
include "db_connect.php";

// Default sorting
$orderBy = "ProductName ASC";
$categoryFilter = ""; // Initialize category filter

// Check the sorting type
if ($_GET['sort'] !== 'All') {
    // Sanitize the category value to prevent SQL injection
    $category = mysqli_real_escape_string($conn, $_GET['sort']);
    $orderBy = "ProductName ASC"; // Reset the sorting order for category filter
    $categoryFilter = "WHERE category = '$category'";
}

// Query to fetch sorted products from the database with category filter
$query = "SELECT id, ProductName, price, image FROM products $categoryFilter ORDER BY $orderBy";
$result = mysqli_query($conn, $query);

// Display sorted product list
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $imageData = base64_encode($row["image"]);
        echo "<a href='user-order-product-page.php?id=" . $row['id'] . "'>";
        echo "<div class='product'>";
        echo "<img src='data:image/png;base64, $imageData'>";
        echo "<h3><strong></strong> " . $row['ProductName'] . "</h3>";
        echo "<h4><strong></strong> ₱" . $row["price"] . "</h4>";
        echo "</div>";
        echo "</a>";
        // Display other product details as needed
    }
} else {
    echo "No products found.";
}
?>
