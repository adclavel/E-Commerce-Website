<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eagles";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve product ID from POST request
$id = $_POST['id'];

// Begin transaction
$conn->begin_transaction();

// Delete records from sizes_stocks table
$sql = "DELETE FROM sizes_stocks WHERE ProductID = '$id'";
$result = $conn->query($sql);

// Check if deletion from sizes_stocks was successful
if ($result) {
    // Delete record from products table
    $sql = "DELETE FROM products WHERE ID = '$id'";
    $result = $conn->query($sql);

    // Check if deletion from products table was successful
    if ($result) {
        // Commit transaction
        $conn->commit();
        echo json_encode(array("success" => true, "message" => "Product deleted successfully"));
    } else {
        // Rollback transaction if deletion from products table failed
        $conn->rollback();
        echo json_encode(array("success" => false, "message" => "Error deleting product: " . $conn->error));
    }
} else {
    // Rollback transaction if deletion from sizes_stocks table failed
    $conn->rollback();
    echo json_encode(array("success" => false, "message" => "Error deleting product sizes and stocks: " . $conn->error));
}

// Close connection
$conn->close();
?>
