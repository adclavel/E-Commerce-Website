<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "eagles";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete account function
if (isset($_GET['id'])) {
    // Retrieve ID from the query parameter
    $id = $_GET['id'];

    // Delete the account from the registered_users table
    $sql = "DELETE FROM registered_users WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        // Redirect back to the admin page to refresh the website
        header("Location: admin_users.php");
        exit(); // Stop further execution after redirection
    } else {
        echo "Error deleting account: " . $conn->error;
    }
}

// Close connection
$conn->close();
?>
